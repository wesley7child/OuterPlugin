"use strict";
// ==UserScript==
// @name         DouyuEx-斗鱼直播间增强插件
// @namespace    https://github.com/qianjiachun
// @icon         data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMTA4cHgiIGhlaWdodD0iMTA4cHgiIHZpZXdCb3g9IjAgMCAxMDggMTA4IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPgogICAgPHRpdGxlPueyvueBteeQgzwvdGl0bGU+CiAgICA8ZyBpZD0i6aG16Z2iLTEiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSLnsr7ngbXnkIMiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAuODMwNzY5LCAwLjgzMDc2OSkiIGZpbGwtcnVsZT0ibm9uemVybyI+CiAgICAgICAgICAgIDxwYXRoIGQ9Ik01My4xNjkyMzA3LDEwNi4zMzg0NjEgQzIzLjgyNzY5MjIsMTA2LjMzODQ2MSAwLDgyLjUxMDc2OTIgMCw1My4xNjkyMzA3IEMwLDUxLjAwMzA3NjkgMS43NzIzMDc3NSw0OS4yMzA3NjkyIDMuOTM4NDYxNSw0OS4yMzA3NjkyIEwzMy40NzY5MjMsNDkuMjMwNzY5MiBDMzUuNjQzMDc2OSw0OS4yMzA3NjkyIDM3LjQxNTM4NDUsNTEuMDAzMDc3IDM3LjQxNTM4NDYsNTMuMTY5MjMwNyBDMzcuNDE1Mzg0Niw2MS44MzM4NDYxIDQ0LjUwNDYxNTQsNjguOTIzMDc2OSA1My4xNjkyMzA3LDY4LjkyMzA3NjkgQzYxLjgzMzg0NjEsNjguOTIzMDc2OSA2OC45MjMwNzY5LDYxLjgzMzg0NjEgNjguOTIzMDc2OSw1My4xNjkyMzA3IEM2OC45MjMwNzY5LDUxLjAwMzA3NjkgNzAuNjk1Mzg0Niw0OS4yMzA3NjkyIDcyLjg2MTUzODUsNDkuMjMwNzY5MiBMMTAyLjQsNDkuMjMwNzY5MiBDMTA0LjU2NjE1NCw0OS4yMzA3NjkyIDEwNi4zMzg0NjEsNTEuMDAzMDc3IDEwNi4zMzg0NjEsNTMuMTY5MjMwNyBDMTA2LjMzODQ2MSw4Mi41MTA3NjkyIDgyLjUxMDc2OTIsMTA2LjMzODQ2MSA1My4xNjkyMzA3LDEwNi4zMzg0NjEgWiIgaWQ9Iui3r+W+hCIgZmlsbD0iIzMzMzYzQSI+PC9wYXRoPgogICAgICAgICAgICA8cGF0aCBkPSJNOC4wNzM4NDYxMiw1Ny4xMDc2OTIyIEMxMC4wNDMwNzY5LDgwLjI0NjE1MzcgMjkuNTM4NDYxNSw5OC40NjE1Mzg1IDUzLjE2OTIzMDcsOTguNDYxNTM4NSBDNzYuOCw5OC40NjE1Mzg1IDk2LjI5NTM4NDYsODAuMjQ2MTUzOSA5OC4yNjQ2MTU0LDU3LjEwNzY5MjIgTDc2LjUwNDYxNTQsNTcuMTA3NjkyMiBDNzQuNjMzODQ2MSw2OC4yMzM4NDYxIDY0Ljg4NjE1MzksNzYuOCA1My4xNjkyMzA3LDc2LjggQzQxLjQ1MjMwNzYsNzYuOCAzMS43MDQ2MTU0LDY4LjIzMzg0NjEgMjkuODMzODQ2MSw1Ny4xMDc2OTIyIEw4LjA3Mzg0NjEyLDU3LjEwNzY5MjIgWiIgaWQ9Iui3r+W+hCIgZmlsbD0iI0ZGRkZGRiI+PC9wYXRoPgogICAgICAgICAgICA8cGF0aCBkPSJNNTMuMTY5MjMwOCwzLjkzODQ2MTUgQzI1Ljk5Mzg0NjEsMy45Mzg0NjE1IDMuOTM4NDYxNSwyNS45OTM4NDYxIDMuOTM4NDYxNSw1My4xNjkyMzA3IEwzMy40NzY5MjMsNTMuMTY5MjMwNyBDMzMuNDc2OTIzLDQyLjMzODQ2MTUgNDIuMzM4NDYxNSwzMy40NzY5MjMgNTMuMTY5MjMwOCwzMy40NzY5MjMgQzY0LDMzLjQ3NjkyMyA3Mi44NjE1Mzg1LDQyLjMzODQ2MTUgNzIuODYxNTM4NSw1My4xNjkyMzA3IEwxMDIuNCw1My4xNjkyMzA3IEMxMDIuNCwyNS45OTM4NDYxIDgwLjM0NDYxNTQsMy45Mzg0NjE1IDUzLjE2OTIzMDgsMy45Mzg0NjE1IFoiIGlkPSLot6/lvoQiIGZpbGw9IiNENjA5MDkiPjwvcGF0aD4KICAgICAgICAgICAgPHBhdGggZD0iTTEwMi40LDU3LjEwNzY5MjIgTDcyLjg2MTUzODUsNTcuMTA3NjkyMiBDNzAuNjk1Mzg0Niw1Ny4xMDc2OTIyIDY4LjkyMzA3Nyw1NS4zMzUzODQ1IDY4LjkyMzA3NjksNTMuMTY5MjMwNyBDNjguOTIzMDc2OSw0NC41MDQ2MTU0IDYxLjgzMzg0NjEsMzcuNDE1Mzg0NiA1My4xNjkyMzA3LDM3LjQxNTM4NDYgQzQ0LjUwNDYxNTQsMzcuNDE1Mzg0NiAzNy40MTUzODQ2LDQ0LjUwNDYxNTQgMzcuNDE1Mzg0Niw1My4xNjkyMzA3IEMzNy40MTUzODQ2LDU1LjMzNTM4NDYgMzUuNjQzMDc2OSw1Ny4xMDc2OTIyIDMzLjQ3NjkyMyw1Ny4xMDc2OTIyIEwzLjkzODQ2MTUsNTcuMTA3NjkyMiBDMS43NzIzMDc2Miw1Ny4xMDc2OTIyIDAsNTUuMzM1Mzg0NSAwLDUzLjE2OTIzMDcgQzAsMjMuODI3NjkyMiAyMy44Mjc2OTIzLDAgNTMuMTY5MjMwNywwIEM4Mi41MTA3NjkyLDAgMTA2LjMzODQ2MSwyMy44Mjc2OTIyIDEwNi4zMzg0NjEsNTMuMTY5MjMwNyBDMTA2LjMzODQ2MSw1NS4zMzUzODQ2IDEwNC41NjYxNTQsNTcuMTA3NjkyMiAxMDIuNCw1Ny4xMDc2OTIyIFoiIGlkPSLot6/lvoQiIGZpbGw9IiMzMzM2M0EiPjwvcGF0aD4KICAgICAgICAgICAgPHBhdGggZD0iTTc2LjUwNDYxNTQsNDkuMjMwNzY5MyBMOTguMzYzMDc2OSw0OS4yMzA3NjkzIEM5Ni4yOTUzODQ2LDI2LjA5MjMwNzYgNzYuOCw3Ljg3NjkyMyA1My4xNjkyMzA3LDcuODc2OTIzIEMyOS41Mzg0NjE1LDcuODc2OTIzIDEwLjA0MzA3NjksMjYuMDkyMzA3NiA4LjA3Mzg0NjEyLDQ5LjIzMDc2OTMgTDI5LjkzMjMwNzYsNDkuMjMwNzY5MyBDMzEuNzA0NjE1NCwzOC4xMDQ2MTU0IDQxLjQ1MjMwNzYsMjkuNTM4NDYxNSA1My4xNjkyMzA3LDI5LjUzODQ2MTUgQzY0Ljg4NjE1MzksMjkuNTM4NDYxNSA3NC42MzM4NDYxLDM4LjEwNDYxNTQgNzYuNTA0NjE1NCw0OS4yMzA3NjkzIEw3Ni41MDQ2MTU0LDQ5LjIzMDc2OTMgWiIgaWQ9Iui3r+W+hCIgZmlsbD0iI0Q2MDkwOSI+PC9wYXRoPgogICAgICAgICAgICA8cGF0aCBkPSJNNTMuMTY5MjMwNyw3Ni44IEM0MC4xNzIzMDc2LDc2LjggMjkuNTM4NDYxNSw2Ni4xNjYxNTM5IDI5LjUzODQ2MTUsNTMuMTY5MjMwNyBDMjkuNTM4NDYxNSw0MC4xNzIzMDc2IDQwLjE3MjMwNzYsMjkuNTM4NDYxNSA1My4xNjkyMzA3LDI5LjUzODQ2MTUgQzY2LjE2NjE1MzksMjkuNTM4NDYxNSA3Ni44LDQwLjE3MjMwNzYgNzYuOCw1My4xNjkyMzA3IEM3Ni44LDY2LjE2NjE1MzkgNjYuMTY2MTUzOSw3Ni44IDUzLjE2OTIzMDcsNzYuOCBaIiBpZD0i6Lev5b6EIiBmaWxsPSIjMzMzNjNBIj48L3BhdGg+CiAgICAgICAgICAgIDxwYXRoIGQ9Ik01My4xNjkyMzA3LDM3LjQxNTM4NDYgQzQ0LjUwNDYxNTQsMzcuNDE1Mzg0NiAzNy40MTUzODQ2LDQ0LjUwNDYxNTQgMzcuNDE1Mzg0Niw1My4xNjkyMzA3IEMzNy40MTUzODQ2LDYxLjgzMzg0NjEgNDQuNTA0NjE1NCw2OC45MjMwNzY5IDUzLjE2OTIzMDcsNjguOTIzMDc2OSBDNjEuODMzODQ2MSw2OC45MjMwNzY5IDY4LjkyMzA3NjksNjEuODMzODQ2MSA2OC45MjMwNzY5LDUzLjE2OTIzMDcgQzY4LjkyMzA3NjksNDQuNTA0NjE1NCA2MS44MzM4NDYxLDM3LjQxNTM4NDYgNTMuMTY5MjMwNywzNy40MTUzODQ2IEw1My4xNjkyMzA3LDM3LjQxNTM4NDYgWiIgaWQ9Iui3r+W+hCIgZmlsbD0iI0ZGRkZGRiI+PC9wYXRoPgogICAgICAgICAgICA8cGF0aCBkPSJNNDMuMzIzMDc2OSw1My4xNjkyMzA3IEM0My4zMjMwNzY5LDU4LjYwNzExMTQgNDcuNzMxMzUwMSw2My4wMTUzODQ2IDUzLjE2OTIzMDcsNjMuMDE1Mzg0NiBDNTguNjA3MTExNCw2My4wMTUzODQ2IDYzLjAxNTM4NDYsNTguNjA3MTExNCA2My4wMTUzODQ2LDUzLjE2OTIzMDcgQzYzLjAxNTM4NDYsNDcuNzMxMzUwMSA1OC42MDcxMTE0LDQzLjMyMzA3NjkgNTMuMTY5MjMwNyw0My4zMjMwNzY5IEM0Ny43MzEzNTAxLDQzLjMyMzA3NjkgNDMuMzIzMDc2OSw0Ny43MzEzNTAxIDQzLjMyMzA3NjksNTMuMTY5MjMwNyBaIiBpZD0i6Lev5b6EIiBmaWxsPSIjMzMzNjNBIj48L3BhdGg+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4=
// @version      2026.06.03.01
// @description  斗鱼直播间增强插件，功能：弹幕自动变色防检测循环发送 一键续牌 查看真实人数/查看主播数据 已播时长 一键签到(直播间/车队/鱼吧/客户端) 一键领取鱼粮(宝箱/气泡/任务) 一键寻宝 送出指定数量的礼物 一键清空背包 屏蔽广告 调节弹幕大小 自动更新 同屏画中画/多直播间小窗观看/可在斗鱼看多个平台直播(虎牙/b站) 获取真实直播流地址 自动抢礼物红包 背包信息扩展 简洁模式 夜间模式 开播提醒 幻神模式 关键词回复 关键词禁言 自动谢礼物 自动抢宝箱 弹幕右键信息扩展 防止下播自动跳转 影院模式 直播时间流控制 弹幕投票 直播滤镜 直播音频流 账号多开/切换 显示粉丝牌获取日期 月消费数据显示 弹幕时速 相机截图录制gif 全景播放器 斗鱼视频下载/弹幕ass下载 直播画面局部缩放 全站抽奖信息 直播音效增强 阻止P2P上传 显示贡献榜贡献值 恢复弹幕显示 斗鱼视频弹幕高能进度条 检测弹幕是否发送成功 查看主播配置信息 自动网页全屏 自动最高画质 弹幕无限收藏 收藏弹幕搜索 支持弹幕带图片 屏蔽弹幕背景 弹幕+1 房间VIP到期提醒 自动钓鱼 防止自动暂停直播 恢复已关闭鱼吧 弹幕小尾巴 屏蔽重复弹幕 画质增强 画中画增强
// @author       小淳
// @match			*://*.douyu.com/0*
// @match			*://*.douyu.com/1*
// @match			*://*.douyu.com/2*
// @match			*://*.douyu.com/3*
// @match			*://*.douyu.com/4*
// @match			*://*.douyu.com/5*
// @match			*://*.douyu.com/6*
// @match			*://*.douyu.com/7*
// @match			*://*.douyu.com/8*
// @match			*://*.douyu.com/9*
// @match			*://*.douyu.com/beta/*
// @match			*://*.douyu.com/topic/*
// @match        *://www.douyu.com/member/cp/getFansBadgeList
// @match        *://passport.douyu.com/*
// @match        *://msg.douyu.com/*
// @match        *://yuba.douyu.com/*
// @match        *://v.douyu.com/*
// @match        *://cz.douyu.com/*
// @require      https://registry.npmmirror.com/flv.js/1.6.2/files/dist/flv.min.js
// @require      https://fastly.jsdelivr.net/npm/svgaplayerweb@2.3.1/build/svga.min.js
// @require      https://registry.npmmirror.com/gif.js/0.2.0/files/dist/gif.js
// @require      https://registry.npmmirror.com/three/0.80.0/files/build/three.min.js
// @require      https://registry.npmmirror.com/xlsx/0.16.4/files/dist/xlsx.full.min.js
// @require      https://registry.npmmirror.com/dompurify/2.3.6/files/dist/purify.min.js
// @grant        GM_openInTab
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_listValues
// @grant        GM_deleteValue
// @grant        GM_cookie
// @grant        GM_registerMenuCommand
// @grant        unsafeWindow
// @connect      douyucdn.cn
// @connect      douyu.com
// @connect      122.51.5.63
// @connect      qq.com
// @connect      douyuex.com
// @connect      bojianger.com
// @connect      greasyfork.org
// @connect      bilibili.com
// @connect      huya.com
// @connect      jsdelivr.net
// @connect      shadiao.app
// @connect      shadiao.pro
// @connect      fz996.com
// @connect      toubang.tv
// @connect      doseeing.com
// @antifeature  tracking
// ==/UserScript==
function s(){wl({url:"/firstqueue",callback:e=>{let t=e;return t=t.replace("e.display=new e.renderer(e);","e.display=new e.renderer(e);e.display.raw.comment=e;")}}),wl({inline:!0,callback:ai});{let t=Node.prototype.appendChild,o=Node.prototype.insertBefore;Node.prototype.appendChild=function(e){if("SCRIPT"===e.tagName){if(e.src&&xl(e,t,this))return document.createDocumentFragment();e=vl(e)}return t.call(this,e)},Node.prototype.insertBefore=function(e,t){if("SCRIPT"===e.tagName){if(e.src&&xl(e,o,this))return document.createDocumentFragment();e=vl(e)}return o.call(this,e,t)}}var e;null!=(o=localStorage.getItem("ExSave_Mode"))&&("mode"in(o=JSON.parse(o))==0&&(o.mode=0),1==o.mode)&&mn();{let t=unsafeWindow.XMLHttpRequest.prototype.send,i=(unsafeWindow.XMLHttpRequest.prototype.send=function(e){gl.set(this,e),t.call(this,e)},Object.getOwnPropertyDescriptor(unsafeWindow.XMLHttpRequest.prototype,"responseText"));Object.defineProperty(unsafeWindow.XMLHttpRequest.prototype,"responseText",{get:function(){let e=i.get.call(this);var t,o=gl.get(this);for(t of ul){var n=t(this.responseURL,e,o);void 0!==n&&(e=n)}return gl.delete(this),e},configurable:!0})}{function t(){}hl((e,t)=>-1!==e.indexOf("/betard")?ai(t):t),Ei(),null!=(o=localStorage.getItem("ExSave_P2P"))&&JSON.parse(o).isKillP2P&&["RTCPeerConnection","webkitRTCPeerConnection","mozRTCPeerConnection","msRTCPeerConnectio"].forEach(e=>{void 0===unsafeWindow.RTCPeerConnection&&(unsafeWindow.RTCPeerConnection=unsafeWindow[e]),void 0!==unsafeWindow[e]&&(unsafeWindow[e]=t)})}if(null!=(o=localStorage.getItem("ExSave_FullScreen"))&&JSON.parse(o).isFullScreen){let e=0,t=setInterval(()=>{if(100<++e&&clearInterval(t),k([".wfs-2a8e83",".icon-c8be96"])){clearInterval(t);let e=document.querySelector("div.wfs-2a8e83");e?e.click():2<=(e=document.querySelectorAll(".icon-c8be96")).length&&e[e.length-2].click()}},1e3)}if(null!=(o=localStorage.getItem("ExSave_HighestVideoQuality"))&&JSON.parse(o).isHighestVideoQuality){let t=0,o=setInterval(()=>{100<++t&&clearInterval(o);var e=document.querySelector('[class^="tipItem-"]:has([value^="画质"])')||document.querySelector('[class^="tip-"]:has([value^="画质"])');e&&(clearInterval(o),e=e.querySelector("ul > li:first-child"))&&!e.matches('[class^="selected-"]')&&e.click()},1e3)}var o="rateRecordTime_h5p_room";try{var n=localStorage.getItem(o);let e=n?JSON.parse(n):{};"v"!==(e="object"==typeof e&&null!==e?e:{}).v&&(e.v="v",localStorage.setItem(o,JSON.stringify(e)))}catch(e){}Ln(),(o=document.createElement("script")).src="https://hm.baidu.com/hm.js?4dc4fb0549a56fe03ba53c022b1ff455",(e=document.getElementsByTagName("script")[0]).parentNode.insertBefore(o,e),console.log(`%c
   ______                    _____)
  (, /    )                /
    /    / ___             )__   __/
  _/___ /_(_)(_(_(_/_(_(_/        /(__
(_/___ /        .-/     (_____)  /
               (_/

%cver `+wi,"color:rgb(255,121,35);font-size:20px;font-weight:bold;","color:red;font-size:16px;"),GM_registerMenuCommand("检查更新",()=>{Ei(!0)}),GM_registerMenuCommand("重置所有设置",()=>{(async()=>{if(confirm("确定要清空 DouyuEx 的所有本地设置吗？\n\n包括：油猴存储(GM)与本站 localStorage 中的插件数据。\n此操作不可恢复。")){await(async()=>{if("function"==typeof GM_deleteValue){let t=[];try{var e;"function"==typeof GM_listValues?(e=GM_listValues(),t=e&&"function"==typeof e.then?await e:e||[]):"undefined"!=typeof GM&&GM.listValues&&(t=await GM.listValues())}catch(e){return}Array.isArray(t)||(t=[]);for(let e=0;e<t.length;e++)try{GM_deleteValue(t[e])}catch(e){}}})();try{var t=[];for(let e=0;e<localStorage.length;e++){var o=localStorage.key(e);o&&(e=>e.startsWith("ExSave_")||e.startsWith("Ex_")||"Ex_isJoysound"===e||"freetimed"===e)(o)&&t.push(o)}t.forEach(e=>localStorage.removeItem(e))}catch(e){}alert("已清空。请刷新斗鱼页面以使界面与功能恢复默认状态。")}})()});{let e=setInterval(()=>{k([".Header-follow-content","#js-backpack-enter"])&&(Wt=new G(".Header-follow-content",!1,Yt),clearInterval(e))},1e3)}}function d(){var l=document.createElement("div"),i=(l.className="ChatToolBar-DanmakuTail",l.innerHTML='<div class="ChatToolBar-DanmakuTail-tip" title="弹幕小尾巴" ></div>',document.getElementsByClassName("ChatToolBar__left")[0]);i.appendChild(l),(i=document.createElement("div")).className="ChatToolBar-DanmakuTail-Panel",(l=document.getElementsByClassName("layout-Player-chat")[0]).insertBefore(i,l.childNodes[0]),window.location.href.includes("/beta")||(i.style.bottom="140px"),i.innerHTML=`
        <div class="ChatToolBar-DanmakuTail-title">弹幕小尾巴</div>
        <input type="text" class="DanmakuTail-input" id="DanmakuTail-input" placeholder="请输入小尾巴内容"/>
        <div class="DanmakuTail-option-label">
            <label for="DanmakuTail-option-label1">
                <input type="radio" name="DanmakuTailType" value="1" id="DanmakuTail-option-label1"> 前缀
            </label>
            <label for="DanmakuTail-option-label2">
                <input type="radio" name="DanmakuTailType" value="2" id="DanmakuTail-option-label2" checked> 后缀
            </label>
        </div>
        <label class="DanmakuTail-checkbox-label">
            <input type="checkbox" class="DanmakuTail-checkbox" id="DanmakuTail-checkbox" />
            启用功能
        </label>
    `,null!=(l=localStorage.getItem("ExSave_DanmakuTail"))&&(l=JSON.parse(l),document.getElementById("DanmakuTail-checkbox").checked=l.isTailEnabled,document.getElementById("DanmakuTail-input").value=l.tailContent||"",document.getElementById("DanmakuTail-input").disabled=l.isTailEnabled,document.querySelectorAll('input[name="DanmakuTailType"]')[0].disabled=l.isTailEnabled,document.querySelectorAll('input[name="DanmakuTailType"]')[1].disabled=l.isTailEnabled,l.type?(document.querySelector(`input[name="DanmakuTailType"][value="${l.type}"]`).checked=!0,Ue()):document.querySelector('input[name="DanmakuTailType"][value="2"]').checked=!0,l.isTailEnabled)&&document.querySelector(".ChatToolBar-DanmakuTail-tip").classList.add("ChatToolBar-DanmakuTail-tip-active"),document.getElementsByClassName("ChatToolBar-DanmakuTail")[0].addEventListener("click",function(){ee("弹幕小尾巴")});{var i="#DanmakuTail-checkbox",l="#DanmakuTail-input";let s=null,d=null;function a(i,a){let r=document.querySelector("textarea.ChatSend-txt")||document.querySelector("div.ChatSend-txt"),l=document.querySelector(".ChatSend-button");if(r&&l){c();let t="div"===r.tagName.toLowerCase(),o=()=>t?r.innerText:r.value,n=e=>{t?r.innerText=e:r.value=e};s=function(e){!e.isTrusted||"Enter"!==e.key||e.shiftKey||(e.preventDefault(),e.stopPropagation(),l.click())},d=function(e){var t=o();if(""!=t.trim()){let e=!1;(e="1"===a?!t.startsWith(i):!t.endsWith(i))&&("1"===a?n(i+t):n(t+i),r.dispatchEvent(new Event("input",{bubbles:!0})))}},r.addEventListener("keydown",s,!0),l.addEventListener("click",d,!0)}}function c(){var e=document.querySelector("textarea.ChatSend-txt")||document.querySelector("div.ChatSend-txt"),t=document.querySelector(".ChatSend-button");e&&s&&e.removeEventListener("keydown",s,!0),t&&d&&t.removeEventListener("click",d,!0),s=null,d=null}let e=document.querySelector(i),t=document.querySelector(l),o=document.querySelectorAll('input[name="DanmakuTailType"]'),n=document.querySelector('input[name="DanmakuTailType"]:checked').value;e&&(e.addEventListener("change",function(){""===t.value.trim()?(e.checked=!1,S("【弹幕小尾巴】请输入弹幕小尾巴内容","error")):(t.disabled=e.checked,o[0].disabled=e.checked,o[1].disabled=e.checked,document.querySelector(".ChatToolBar-DanmakuTail-tip").classList.remove("ChatToolBar-DanmakuTail-tip-active"),c(),e.checked&&t&&(document.querySelector(".ChatToolBar-DanmakuTail-tip").classList.add("ChatToolBar-DanmakuTail-tip-active"),a(t.value.trim(),n=document.querySelector('input[name="DanmakuTailType"]:checked').value)))}),e.checked)&&t&&a(t.value.trim(),n)}document.getElementById("DanmakuTail-checkbox").addEventListener("change",function(){Ue()}),document.querySelectorAll('input[name="DanmakuTailType"]').forEach(e=>{e.addEventListener("change",function(){Ue()})}),document.getElementById("DanmakuTail-input").addEventListener("input",function(){Ue()}),(i=!!document.getElementsByClassName("live-next-body")[0])||((i=document.createElement("div")).style="position: absolute;right: -75px;top: 18px;cursor: pointer;",i.id="ex-night",i.innerHTML=dn,i.title="切换夜间模式",document.getElementsByClassName("Header-right")[0].appendChild(i),document.getElementById("ex-night").addEventListener("click",function(){var e,t=document.getElementById("ex-night");0==cn?(cn=1,t.innerHTML=sn,t.title="切换日间模式",mn(),pn(),un()):(cn=0,t.innerHTML=dn,t.title="切换夜间模式",V("Ex_Style_NightMode"),pn(),t=document.getElementsByClassName("BottomGroup")[0].getElementsByTagName("iframe")[0].contentWindow.document,e="Ex_Style_NightModeIframe",null!==t.getElementById(e)&&t.getElementById(e).remove())}),i=localStorage.getItem("ExSave_Mode"),l=document.getElementById("ex-night"),null!=i&&("mode"in(i=JSON.parse(i))==0&&(i.mode=0),1==i.mode)&&(cn=1,l.innerHTML=sn,l.title="切换日间模式"),new G(".BottomGroup",!0,e=>{0!=cn&&1==e.length&&un()}));{let e=document.createElement("div"),t=(e.className="ex-icon",e.innerHTML=`<a title="DouyuEx ver.${wi}">${et}<i id="ex-icon__tip" class="ex-panel__tip"></i></a>`,document.querySelector(".PlayerToolbar-ContentCell .PlayerToolbar-Wealth"));t?t.insertBefore(e,t.childNodes[0]):(e.className+=" ToolbarGiftArea-backpack",e.style.width="52px",(t=document.querySelector(".ToolbarGiftArea-container")).appendChild(e))}document.getElementsByClassName("ex-icon")[0].addEventListener("click",gt);{let e=document.createElement("div"),t=(e.className="ex-panel",e.innerHTML='<button type="button" class="ex-panel__close" title="关闭工具条" aria-label="关闭 DouyuEx 工具条">×</button><div class="ex-panel__wrap"></div>',nt());t?(i=document.querySelector(".PlayerToolbar"),e.style.bottom=i?i.offsetHeight+"px":"76px"):(t=at(),e.classList.add("ex-panel--floating")),t.insertBefore(e,t.childNodes[0]),rt(e),it()&&st()}l=document.querySelector(".ex-panel");l.addEventListener("mouseenter",()=>{clearTimeout(U)}),l.addEventListener("mouseleave",()=>{clearTimeout(U),U=setTimeout(ut,800)}),(l=l.querySelector(".ex-panel__close"))&&l.addEventListener("click",e=>{e.stopPropagation(),mt()}),_l("Ex_Style_RealAudience",`
    .VideoEntry{display:none !important;}
	.layout-Player-rank{top:34px !important;}
    `);{let e=document.getElementsByClassName("VideoEntry")[0];e&&(e.style.display="none"),i="",(l=document.createElement("div")).className="real-audience",i+="<div style='flex: 1;white-space: nowrap'>",l.innerHTML='<div style=\'flex: 1;white-space: nowrap\'><div id=\'real-audience__t\' style=\'display: inline-block;margin-right:3px;\' title=\'今日累计观看人数\'><svg style="width:16px;height:16px" t="1566119680547" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3494" width="128" height="128"><path d="M712.820909 595.224609C807.907642 536.686746 870.40537 437.74751 870.40537 325.549212 870.400378 145.753547 709.943392 0 511.997503 0 314.055363 0 153.599626 145.753547 153.599626 325.549212 153.599626 437.74751 216.092361 536.686746 311.179092 595.219615 149.961841 657.72608 31.268214 793.205446 5.334335 955.968198 1.926253 962.195123 0 969.212275 0 976.638899 0 1002.324352 22.919038 1023.151098 51.198627 1023.151098 79.476967 1023.151098 102.396005 1002.324352 102.396005 976.638899L102.396005 1023.151098C102.396005 817.669984 285.787009 651.099674 511.997503 651.099674 738.212992 651.099674 921.602746 817.669984 921.602746 1023.151098L921.602746 976.638899C921.602746 1002.324352 944.523034 1023.151098 972.801376 1023.151098 1001.07472 1023.151098 1024 1002.324352 1024 976.638899 1024 969.212275 1022.073747 962.195123 1018.659424 955.968198 992.731789 793.205446 874.038157 657.72608 712.820909 595.224609ZM511.997503 558.080262C370.618285 558.080262 256.000624 453.967732 256.000624 325.545467 256.000624 197.121954 370.618285 93.009424 511.997503 93.009424 653.386707 93.009424 767.993133 197.121954 767.993133 325.545467 767.993133 453.972726 653.386707 558.080262 511.997503 558.080262L511.997503 558.080262Z" p-id="3495"></path></svg><span id="real-audience__total" style="color:#ed5a65">****</span></div><div style=\'display: inline-block;margin-right:3px;\' title=\'弹幕人数\'><svg t="1587796804183" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="20780" width="16" height="16"><path d="M811.8272 62.6176H212.1728c-79.9232 0-149.8624 69.9392-149.8624 149.9136v599.6032a150.3232 150.3232 0 0 0 149.8624 149.9136h599.6544a150.3232 150.3232 0 0 0 149.8624-149.9136V212.5312c0-79.9744-69.9392-149.9136-149.8624-149.9136zM263.5264 367.104c30.0032 0 49.9712 19.968 49.9712 49.9712s-19.968 49.92-49.9712 49.92-49.9712-19.968-49.9712-49.92 20.0192-49.9712 49.9712-49.9712z m449.6896 294.8096H263.5264c-24.9856 0-49.9712-24.9856-49.9712-49.9712s24.9856-49.9712 49.9712-49.9712h449.6896c24.9856 0 49.9712 24.9856 49.9712 49.9712s-24.9856 49.9712-49.9712 49.9712z m99.9424-199.68H463.4112c-24.9856 0-49.9712-24.9856-49.9712-49.9712s24.9856-49.9712 49.9712-49.9712h349.7472c24.9856 0 49.9712 24.9856 49.9712 49.9712s-24.9856 49.7664-49.9712 49.7664z" p-id="20781" fill="#1296db"></path></svg><span id="real-audience__barrage">****</span></div><div id=\'real-audience__noble-wrap\' style=\'display: inline-block;margin-right:3px;\' title=\'贵宾数\'><svg t="1779268394045" class="icon" viewBox="0 0 1170 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5245" width="16" height="16"><path d="M270.579175 30.138897S391.031549-36.125391 427.208548 36.176998c36.125391 18.062695 114.46588 463.798407 132.528575 548.176999 18.062695 90.365084 60.226187 120.452374 84.326983 84.326983s114.46588-126.490475 174.692068-265.057152-18.062695-156.629372-42.163492-150.591271c-24.100796 6.038101-150.591271 12.024594-108.427779-42.163491 48.201593-54.188086 156.629372-150.591271 186.716661-162.615866 54.188086-36.125391 138.566677-84.326983 210.817458-6.038101 42.163492 30.138897 144.55317 150.591271 48.201593 319.245238-96.403185 174.692067-475.874609 614.389678-475.87461 614.389678s-138.566677 90.365084-192.754762 0c-54.188086-84.326983-240.956355-554.163492-246.994456-614.389678 0-60.226187-18.062695-72.302389-48.201593-60.226187-30.138897 18.062695-90.365084 102.389678-96.403185 78.288882-5.986493-24.100796-60.174579-60.277795-24.049189-114.465881 30.138897-48.201593 216.855559-216.855559 240.956355-234.918254z" fill="#CCB88F" p-id="5246"></path></svg><span id="real-audience__noble">****</span></div><div id=\'real-audience__money\' style=\'display: inline-block;margin-right:3px;\' title=\'今日累计礼物价值\'><svg t="1579155265981" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="6949" width="16" height="16"><path d="M136.96 67.413h181.76L512 452.693l193.28-385.28h181.76l-245.76 445.44h163.84v84.48h-211.2l-1.28 1.28v106.24h212.48v84.48H592.64v192H431.36v-192h-211.2v-84.48h211.2v-106.24l-1.28-1.28H220.16v-84.48h162.56z" fill="#F54330" p-id="6950"></path></svg><span id="real-audience__money_yc">****</span></div></div><span id="real-audience__time" style="white-space: nowrap;display: block;">已播:****</span><span id="real-audience__watchtime" style="white-space: nowrap;display: none;">已观看:****</span>',(i=k([".layout-Player-announce",".layout-Player-rankAll"])).insertBefore(l,i.childNodes[0])}document.getElementsByClassName("real-audience")[0].addEventListener("click",function(){w("https://www.doseeing.com/room/"+B,!0)});var t,o,l=document.querySelectorAll(".VideoEntry-tabItem>a")[0];null!=l&&(i=l.href+"?type=video",l=l.href+"?type=liveReplay",n=document.createElement("div"),wn=!!document.getElementsByClassName("Title-anchorPic-bottom")[0],n.className=wn?"":"Title-anchorPic-bottom",n.innerHTML=`
	<div id="Ex_VideoReview" class="Title-anchorPic-bottomItem"><span>回看</span></div>
	<i style="top: 28px"></i>
	<div id="Ex_VideoSubmit" class="Title-anchorPic-bottomItem"><span>投稿</span></div>
	`,(r=document.getElementsByClassName("Title-anchorPic-bottom")[0]||document.getElementsByClassName("Title-anchorPicBack")[0]).insertBefore(n,r.childNodes[0]),n=document.createElement("div"),wn=!!document.getElementsByClassName("Title-anchorPic-bottom")[0],n.className=wn?"":"Title-anchorPic-bottom",n.innerHTML=`
	<div id="Ex_EnterYuba" class="Title-anchorPic-bottomItem"><span>打开鱼吧</span></div>
	`,(r=document.getElementsByClassName("Title-anchorPic-bottom")[0]||document.getElementsByClassName("Title-anchorPicBack")[0]).insertBefore(n,r.childNodes[0]),t=i,o=l,document.getElementById("Ex_VideoSubmit").addEventListener("click",()=>{w(t,!0)}),document.getElementById("Ex_VideoReview").addEventListener("click",()=>{w(o,!0)}),document.getElementById("Ex_EnterYuba").addEventListener("click",async()=>{var e;e=B,w((await new Promise((t,o)=>{fetch("https://www.douyu.com/wgapi/yubanc/api/group/getBindGroup?room_id="+e).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{o(e)})})).data.group_url,!0)}),document.getElementsByClassName("Title-anchorPic-bottom")[0].style.display="none",document.getElementsByClassName("Title-anchorPic-bottom")[0].style.height=wn?"66px":"22px",document.getElementsByClassName("Title-anchorPicBack")[0].addEventListener("mouseenter",()=>{document.getElementsByClassName("Title-anchorPic-bottom")[0].style.display="block"}),document.getElementsByClassName("Title-anchorPicBack")[0].addEventListener("mouseleave",()=>{document.getElementsByClassName("Title-anchorPic-bottom")[0].style.display="none"})),fetch("https://www.douyu.com/swf_api/h5room/"+B,{method:"GET",mode:"no-cors",credentials:"include"}).then(e=>e.json()).then(e=>{D.showtime=e.data.show_time,D.isShow=e.data.show_status,kn(),setInterval(kn,15e4),setInterval(En,5e3)}).catch(e=>{console.log("请求失败!",e)});{let e=document.createElement("div"),t=(e.className="Title-blockInline",e.id="copy-real-live",e.innerHTML='<div class="TitleShare"><div class="TitleShare-shareBox "><div class="Title-row-span is-right"><span class="Title-row-icon "><svg t="1585641756842" class="icon" viewBox="0 0 1237 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5646" width="16" height="16"><path d="M648.448 946.347l0.256-1.622-0.256 1.622z m84.31 13.354c-0.769 4.608-0.769 4.608-4.182 13.483-8.533 16.768-8.533 16.768-49.835 22.784-24.149-14.293-24.149-14.293-27.605-22.613-2.475-5.718-2.475-5.718-3.541-9.387L476.416 335.36l-103.083 499.2c-1.109 5.12-1.109 5.12-4.821 13.27-6.827 12.117-6.827 12.117-35.285 22.527-30.294-7.253-30.294-7.253-38.742-19.37-4.522-8.15-4.522-8.15-6.058-13.227l-74.582-262.357H0v-85.334h278.272l45.781 161.11 104.022-503.424c1.024-4.694 1.024-4.694 4.394-12.502 6.102-11.989 6.102-11.989 35.968-23.338 31.83 8.533 31.83 8.533 39.254 20.736 4.053 7.808 4.053 7.808 5.376 12.544l165.888 609.237 113.92-716.885c0.896-5.248 0.896-5.248 4.864-14.592 9.088-15.574 9.088-15.574 44.928-22.4C868.48 12.587 868.48 12.587 873.6 22.443c3.285 6.912 3.285 6.912 4.523 11.52l112 446.549h221.738v85.333H923.563l-78.507-312.917-112.299 706.773z" p-id="5647"></path></svg></span><span class="Title-row-text">复制直播流</span></div></div></div>',document.getElementsByClassName("Title-col")[4]);t&&1<t.childNodes.length?t.insertBefore(e,t.childNodes[1]):(t=k([".subTitleContainer__-vzhr"])).appendChild(e)}document.getElementById("copy-real-live").addEventListener("click",Ge);var n=document.getElementsByClassName("RecommendViewTit-04ebd8");0<n.length&&n[0].innerText;{let e=document.createElement("div"),t=(e.className="Title-blockInline",e.id="ex-audio-line",e.innerHTML='<div class="TitleShare"><div class="TitleShare-shareBox "><div class="Title-row-span  is-right"><span class="Title-row-icon "><svg t="1613808136306" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2829" width="16" height="16"><path d="M496 64A48 48 0 0 1 544 112v800a48 48 0 0 1-96 0v-800A48 48 0 0 1 496 64z m-224 128A48 48 0 0 1 320 240v544a48 48 0 0 1-96 0v-544A48 48 0 0 1 272 192z m448 0A48 48 0 0 1 768 240v544a48 48 0 0 1-96 0v-544A48 48 0 0 1 720 192z m-672 128A48 48 0 0 1 96 368v288a48 48 0 0 1-96 0v-288A48 48 0 0 1 48 320z m896 0a48 48 0 0 1 48 48v288a48 48 0 0 1-96 0v-288a48 48 0 0 1 48-48z" p-id="2830"></path></svg></span><span class="Title-row-text ">切换音频线路</span></div></div></div>',document.getElementsByClassName("Title-col")[4]);t&&1<t.childNodes.length?t.insertBefore(e,t.childNodes[1]):(t=k([".subTitleContainer__-vzhr"])).appendChild(e)}document.getElementById("ex-audio-line").addEventListener("click",se);{let o=setInterval(()=>{if(null!=k([".PlayerToolbar-ContentCell .PlayerToolbar-Wealth","#js-backpack-enter"])){clearInterval(o),document.getElementById("js-barrage-list").parentNode.id="js-barrage-list-parent";var e=document.createElement("div"),t=(e.style="position: absolute;right: 5px;top: 40px;cursor: pointer;",e.id="ex-removeMsgNotice",e.innerHTML='<label id="msg-removeNotice" style="cursor: pointer;"><input type="checkbox" />关闭角标提醒</label>',e.title="关闭角标提醒",document.getElementsByClassName("PrivateLetter-frame")[0]),t=(t&&t.appendChild(e),document.getElementById("msg-removeNotice"));if(t){let e=t.querySelector("input");t.addEventListener("click",()=>{1==e.checked?(An=1,Dn()):(An=0,V("Ex_Style_RemoveMsgNotice")),localStorage.setItem("ExSave_isRemoveMsgNotice",An)})}e=localStorage.getItem("ExSave_isRemoveMsgNotice");e&&"1"==e&&(An=1,Dn(),e=document.getElementById("msg-removeNotice"))&&(e.querySelector("input").checked=!0)}},1e3)}{let e=setInterval(()=>{void 0!==document.getElementsByClassName("BarrageFilter")[0]&&(clearInterval(e),new G(".BarrageFilter",!1,e=>{if(0!==e.length&&(0<e[0].addedNodes.length&&0===e[0].removedNodes.length))if(document.getElementsByClassName("FilterKeywords")[0])ii();else{let e=setInterval(()=>{document.getElementsByClassName("FilterKeywords")[0]&&(clearInterval(e),ii())},50)}}))},1e3)}{let o=k([".BackpackButton","#js-backpack-enter"]);o&&o.addEventListener("click",function(){setTimeout(()=>{ce&&(ce.closeHook(),ce=null);let t=document.querySelectorAll(".ToolbarBackpack-giftItem").length;ce=new G(".BackpackExpandPanel-giftListWrap",!0,e=>{t!=document.querySelectorAll(".ToolbarBackpack-giftItem").length&&(o.click(),o.click())})},500),clearTimeout(de),de=setTimeout(()=>{let p=!!document.getElementsByClassName("BackpackExpandPanel")[0];k([".Backpack.JS_Backpack",".BackpackExpandPanel"])&&Bt(B,n=>{var i=n.data.list.length;if(0<i){let t=0,o=0;for(let e=0;e<i;e++){var a=(e=>{for(var t of e){let e=[];if(0<(e="string"==typeof t?document.querySelectorAll(t):t).length)return e}return[]})([".Backpack-prop",".ToolbarBackpack-giftItem"])[e],r=n.data.list[e].isValuable,l=n.data.list[e].expiry,s=n.data.list[e].price,d=n.data.list[e].intimate,c=n.data.list[e].count,r=("1"==r&&(t+=Number(s)*Number(c)),o+=Number(d)*Number(c),document.createElement("div"));r.className="bag-info",p&&(r.style.left="8px",r.style.bottom="auto"),r.innerHTML=l-1,a.insertBefore(r,a.childNodes[0])}var e=k([".BackpackHeader-extInfo",".BackpackExpandPanel-backpackHeader"]);p?e.innerHTML=e.innerHTML+`<span style="width: 100%;display: flex;justify-content: space-between;align-items: center;flex: 1;margin-left: 12px;">
                                <span>
                                    <span>总价值:</span>
                                    <span>￥${String(Number(t/100).toFixed(2))}</span>
                                    <span>总亲密度:</span>
                                    <span>${String(o)}</span>
                                </span>
                                <span class="bag-button" id="Backpack__clearbag" style="background: rgb(70, 171, 255) !important;color: white !important;">清空背包</span>
                            </span>`:e.innerHTML='<span style="float: left">总价值：'+String(Number(t/100).toFixed(2))+" 总亲密度："+String(o)+'<span class="bag-button" id="Backpack__clearbag">清空背包</span></span>'+e.innerHTML,document.getElementById("Backpack__clearbag").addEventListener("click",()=>{1==confirm("确认清空？")&&(S("【清空背包】执行中...","info"),Bt(B,e=>{(async(n,i)=>{var t=n.data.list.length;if(0<t){for(let e=0;e<t;e++){let t=n.data.list[e].id,o=n.data.list[e].count;if(0<Object.keys(n.data.list[e].batchInfo).length)await b(100).then(()=>{Ut(t,o,i)});else for(let e=0;e<o;e++)await b(100).then(()=>{Ut(t,1,i)})}S("【清空背包】执行完毕！","success")}else S("背包礼物为空","error")})(e,B)}))})}})},500)})}var r=document.createElement("div"),i=(r.className="ex-update",r.innerHTML='<a class="ex-panel__icon" title="版本更新，当前版本'+wi+'"><svg t="1578767541873" style="display:block;" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="23715" width="32" height="32"><path d="M768 810.7H512c-23.6 0-42.7-19.1-42.7-42.7s19.1-42.7 42.7-42.7h256c94.1 0 170.7-76.6 170.7-170.7 0-89.6-70.1-164.3-159.5-170.1L754 383l-10.7-22.7c-42.2-89.3-133-147-231.3-147s-189.1 57.7-231.3 147L270 383l-25.1 1.6c-89.5 5.8-159.5 80.5-159.5 170.1 0 94.1 76.6 170.7 170.7 170.7 23.6 0 42.7 19.1 42.7 42.7s-19.1 42.7-42.7 42.7c-141.2 0-256-114.8-256-256 0-126.1 92.5-232.5 214.7-252.4C274.8 195.7 388.9 128 512 128s237.2 67.7 297.3 174.2C931.5 322.1 1024 428.6 1024 554.7c0 141.1-114.8 256-256 256z" fill="#3688FF" p-id="23716"></path><path d="M554.7 938.7c-10.9 0-21.8-4.2-30.2-12.5l-128-128c-16.7-16.7-16.7-43.7 0-60.3l128-128c16.6-16.7 43.7-16.7 60.3 0 16.7 16.7 16.7 43.7 0 60.3L487 768l97.8 97.8c16.7 16.7 16.7 43.7 0 60.3-8.3 8.4-19.2 12.6-30.1 12.6z" fill="#5F6379" p-id="23717"></path></svg><i id="ex-update__tip" class="ex-panel__tip"></i></a>',document.getElementsByClassName("ex-panel__wrap")[0]),l=(i.insertBefore(r,i.childNodes[0]),document.getElementsByClassName("ex-update")[0].addEventListener("click",Bi),_i&&Ii(!0),document.createElement("div")),i=(l.className="ex-auto-anchor-star",l.innerHTML='<a class="ex-panel__icon" title="全自动代抢星推荐红包"><img style="width:36px;height:36px;" src="https://shark2.douyucdn.cn/front-publish/live-new-anchor-support-master/assets/images/entryIcon_ee486a8.png"/></a>',document.getElementsByClassName("ex-panel__wrap")[0]),l=(i.insertBefore(l,i.childNodes[0]),document.getElementsByClassName("ex-auto-anchor-star")[0].addEventListener("click",function(){w("https://xtj.douyuex.com/")}),document.createElement("div")),i=(l.className="ex-fkbuff",l.innerHTML='<a class="ex-panel__icon" title="FKBUFF - CS饰品议价交流工具"><img style="width:36px;height:36px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAC91BMVEUAAAABAQImIyMzMTASERAbFxUCAgMLDAwVFRUCAgIDAwMDAwQCAgIGBgYEBAQNDg4GBgYdFhMcGhkeHBwKCwsEBAQFBQYICQkUEQ8EBAUFBQUICAkKCgoLCwsTExNVJhIIBwcKCwsGBwcHBwcHBwgICAlSJRMICAhNKRlOJBMJCQlQKBhPJxdLKBsAAAACAgE+Pj0/Pz48PDs8PDz+5Mg6OjpAQD/+5Mb948X94sf948k4OTk5Ojk3ODcxMjEwMDADAwP+4sQzMzMuLi42NjYFBQUKCgr+48b+5Mo0NTQNDQ0sLCwHBwcQEBAaGxoTFBQXGBf/5skqKiokJSUnKCjKfl8dHh3/5cYiIyIgICDJfF3Nf2DGel3/5szBeFz/6Mn83sL+j7D+4sb23sLy2r4JBQT9k7PMgWTQgmK8eWAQCwr+4sH+lK0dEhD/6cz+5si0pI/Gf2I0IhwpGBLFtZ6ml4V6b2JzSjk6NjInHR4gFhX91M7o0bbTimzShWWwcVhoRjhZOixPMyhGLiQYEhL7173s1rn9mbThyrDVwKi8dFeWX0h5Tz5JRD0xLCn+ztD+5sr8oLb8nLbcxq79iaisnoqekH5cVU4+Jx/81MPjzrSLgXKEeGvCfWFvZVmobVX7wcD7vLf9j6bNu6L9haLPh2llXVSdZE2raUyBVUJsQzL93Mn7yrahaFJUTkYYDAn7z73+lbb7sLTkf5r1gJbWfZSTiHiMXEg/OjWWSSwoJiP7ycD8prj/ia/5rK2uZHjYlHW1dVx3R1GzbU5FPzljPzA2Mi3////3xaz6manwiaS8q5b2e4rScYnke4afXXFdOEBUMjn8r7z5hJ/4hobBc4XgoYJOSkSsWzqeVjlILTSLQicxHyRAHg/+4M36lKX3p570lpSvXmaMVGOZX1SCT1BvQEby8vHn6Oevr6/mtaDRsJzarpO7aYDMaHLGjnF8dm7GhWd9SjU8Ky2goKCYe3C3hGp8NxrV1dTpwL/arrGMjIzPooh7AvHQAAAALnRSTlMA+wsGNyHtURv35N3ystZHqi4VEWHOuHU/yL5+bVkm/p1npJaQiOqDYseMmZBTeywgmAAAGAtJREFUeNrEVttO20AQJQ0hARpIKZcWSgWliLdNCvLTeh3LN8nXWLZlJf//I50zS7ZIvCSB0APZrEHJOXNmZnd2NkSXsPOf0O31L26G5+fD0c3Dbf/L4IOFnFyPDjpjsURn7+j87se33qedj0H39KxDtG4YEbJwKeTz4fl9v/cBVny92xcinLWN73ie5/hV3ZZ55movDoYXu1s2ovt7LLI2jQMVBEoybBk46ZxUwIzx3uXF7jZ92N0TYRPHJECB25YA75TTFEkoCHvD297OttDvCDcvmpj4bcuybAN6eLSCaT3LUCCHv7dlQ+9QgKCSEoSPoMWCN72RTj0LYcPoeBvV0PtxAP58KsH4RC9aAV4hgbyQfpugL4bH7+zCp+MbxJ+VTUz8T5PJ04Q46Z1AK0CaOC1xnY9Jwq/d9+y/6/PPVOVJ68cK8U8mfyavAVNYQ8ASDh4G70V/+r2D/kf5KY6fBBgF2PHCidDlQC4gEWf97nuY378EfZkq26aOA7/m/YMFeOEHcoNMSOktqCX273pvb/7RPuh9ZS0L3kSu+Z/3RoCRMC1dMuH4je5fUeW7ZRpQ5+uqNwKebTAbs9MKLClVHVFLXnTfEv4lFVPSBEoidt1xL9wGDGAIv2kPYILtlGPRuTvZ/O6j8MPW4YOPqA0mZvO8fdUOEICGUAtKw2iwYfU9UPbzKgg4fI6dLeDF0ukADwN/XNJjj4OS89BQLV7+3Cj9Ny5l3wmUovSDU1NrTpQjh8k3ga0fGVrPsmJJQZpspuDkF9m/4JtPlx9+rZeAwwEhxuVssqTZIQo77gYoGKzNPxIiqwN8t7ltEC9DxdOqXhTlLM8TIM9nZTtvfA8ywClt7AB8BgpGX9fM/w3xNwgf/Lqi8NUqcCqaP6LQFa8wdrNkVtSppySA3LBu9mB8v17937siq8Cvc8yrJb2mpQnM8IVhFmlkoWsUudFsUWkRrACOpJn4fL2OgNt9ETaK+S36ocglzRtlpFk40nlT0WQYowbimObDtFkUswTyWERZT3F46UJVsnbF0Zc1zp8D4c4DxQnQSce0w2GHSTmvHHSmqUuUm+5KW3k0ICYhD4jZrHa4PZA5VVAZfFq5AIZjUcRagCQD46qMwE7ktR/r8lr2/hPvTW9i4QHRhYaorAKbD+XAy0XndOUEdEQyhQBIUN48d3kSalFe9vJUYtAQYpRgw4Avgd8+f2ruET+1axOKsxV7cXDEw2/AcBbJGLEUVawktwQfvGYUYnr9YE4qflkqbSPkImqnqBOvFOJqNQFXY1F6urymiwjWUzaV7qslmwE/v4a+C+KGZ9So8GPPo044XOlA/HkoopQExLEzT3gMrPQgDnPN5QtMDP5tzX/0sSn9giW0vuMUsGA1A1qH+L0Gg11W+By8vg6YgEmMArN/+cQmcIc8WlMtYZFWkTgarFQBWfWXEWtbaRgIoggq3qpUvIL44AdMBNEXbRNsEqiSCykU/f8f8Uxm97gxie15sWNhz5nZmdmZzhGxOrFJiG3eExC0X178P9RwH31COAlR8VXLzhbd6CKROp7Pv3KRqGpmnIRCdjrt+VsFtKjAgDgsKvUGCfGwuQdcSbKKW/fz1XKm9H7i+EtB00CL4VAJLh/fGk2nSI4PtlhAPz41+ZIyxiSAKcOleXt4jxEGTENfDCsCEtJvTYXDjTPqnUi5zuB+OwiC38P79mgkpKFFdYRXgBhqQi4KKJicb3gGJ5IVCW4/1uQzAbxuHAlrXABNwofBFKTq2eR+0wIcIfzr1NoOBQDm0ZgA/LUr6gpghdqYrJlwefOfgLND0UnIxnB3Ab265+mhwRToCwD8tjKvRI7+q8Vr7RkN+C33CQoIYmB6uhUwfAvsjdhb14nsjyuY3op8LFD83H8CATR4Ji8o+GJEAreVt1U2/iZML0WKGG8eo0+QhdADXZVqtY9rsCRwvyjgNf0WuR7pAeCv3q3zdpj4wcOWH4Cvb0cyu0NYjaYTSHOZDO6LN6eO3zfewFdj5y7UAQckG0x8HPpZ4E55ruT0fMj/45b/+QkCeLWh327C1QYBqKGTjr4WXESCBZplwRrhYbUc7Q28grfgx8AXFj/vGgCFsivn8l1/Iy3rouBS0sTLmdvR/A26pkX89qRS9qcDBRhJwfiHmW5B1tFc2TH2lkXulwMiynL9BTd9BfQQntITAKzlZLffg/EKNqTvCFBy8z1euZlbkf0QZiYvTkRBGEdwwQVF8SLu/8BrwZZe3DrRjBlHZozaOnZ3clBDLxAxiRoVs7aIdqIIogYx5iAxC4Y5xtwShoDgXWYYvHlSQRTUiwer+kmrJOIj5JKE7/eqXn2vqjMmMcxRiAMdBmjPPnli3+9pcueQb1KE02T5sBuuW00OH/yz/j0Dg75qL1WfGmOojpUo5JrFXJR5dPv+7WcXXz/Mv00kLfohjiR7wce9HmLIDnZME2b98BFYSabcOfyvPg/1MfYHxycmqbqVyJcG9XitVmvORJ+eC7OhU6HzZxsL82a19RYh6DgwDmaCx/EPgt9mepwwm0YCeAbkJQKnHUw87W6lmF2qVuL1LMh/zkWtJ2dZQeA4jhX7C/Nybfb7fLtZuBag48A+2I6XBqyC/wAsWQEA+BOv8nfSrhLkj01JuHe7mY3rum5G0ul0Jc/ceCiwPA/yHBv+tNDVas73biUe73fyMULHATcKFOFPgtEAW1aQo3gEqFm4jgLqoD8+cRRbymuDdtaUVV3vpTOZdLZMrl5gWY7nBCBgz3/sdiM1ZWHBiePKpmIBiuBuybMVwPg3wNqlZNLtvT3Po66z7+QRlM9V+81mRFVrb95kMplikrx8FhI5nudZjMH5W/NdJ2N82VpUZVmO65XWwB5zEfwQBc/YaBh2jgZYvAoAKC6VpzPlMWyjYrmq2bFboJ8GfUMuWdKjWyEB9XnhEM+J4XON7qyRSZGyhgSyWiy03xUsAlfr8YOA4F5ZXg4QYPvwRbCcnKQ9EL1nXNfzYw9l5dvmu0Lyi6aqvTe9TMbJS9aTcyEB5c8IgsBzwXvit25Dz9Sj0aLhAjjJRD9etyF40tQEzPLeYQT90QD4b8jpXRgtevbd508HphjCJDpmNhdLFhVZ7fXShlFPkKuXBEg/BfBBDMTg+R/dOV3/fJXYMg1BSbJNPd5J4Gx10g/dNSWgTd1IgO2EHKcBcM0Poj9+4jBsP5c1O4loYVZRZAPkldIMufMs5Omf8fnOCFwwfH9+TtZ7T4lVN2QFVqRM8hpUTCqGM9GEWw/eE+YTo4xoI2FO4OhNA4DFNw0BTML2B9ZMKoK7Ug2jYTPW5Zv0+MESBJ/g8/kEkT3XmJPl3odJYisIoGntGDNQoGirhQAEYZqmgQJABKRhgG1EmgAA+Ba63+6DfujdGLtqtsvRcl2m+pHUDLn7QGDRfCjArwXn8NOcIqdfPSWBpor6Ea0UkFoq5KPSvIaPu/Gep/bmAmweNQ/sp1Xg6Qfy/UonOdNyXH1DLSbI2PP7EH5crj536BAv8gIrsuGPc4qafvXhNIk1UB/WgImm4EQoctWWoNM78Nvnp8miZUPPZTeQMf8ehMT62+uflMiRnFkpxcpFTVMU2H+1ECV3L50NoToFgMiLh0R8Bdnw9VkEePE1QMoO6MPqF0i0pcmKppilGzhqQRZogBFg+CrAyxDrEPuc8ZOgn6pUcomSowCALEMhkGuXH4ddcQoAbwAAECLLBoPCZ80AgPdXCCk4GuZAc2xGyjuYkDiUDglM74UU4zpNFq0ZYYQ/CbXOmKaiKByNMzHGveKKcf65708TWoy2pbZiJ63VUhWKKU7QoqhAcQvGPSKK26jEBaJRHHFg4sIBCIIxMe69Na44/vidd/FZ6QU/UyzlvX7fGffc8857DnRXfCY4DDP2cWnTJq1ImzdhwuhR8ReWL5gisXG5KUsXq50+J9ED4Ifv8aI30XFvR02c8/pb2r1xTFqYdmkBcGA+DN94YfQo6JmHXMT1FsKAtT4S/YDgiiiGpnJUf2igpZu/bduOHSOmzVuetnD6lHFYS9QHZK0q3LoeKnweEoC9APUAAlS0HyXOmRiPDfkQjlWgwyt1xb74MQjI/MlMsg+Seyu7oCNqh7nMwEG887CY4MZJ8csu7E1bBO5aMGZd3rNhqd/pIdM1kRGRkbQonGuWfJi475COCXAI22j8pEkrYNZwubeKEfSEfVCHqN8FP12+TZ+3bN+njZP/stqoAVVG1LrgyuPQQOuBtsShTv+M7asOzl1u5GNasyMmxm6nYXrNGbrUA1jQ+DpzFFnoEHTFrVAGqONGAR4pseDefQdSQ6wxx7pkuId7lecF7IUzZycmJvr9fo0/pdDGxi2fe0JiOjMNkS0Wi8FCcGHUQaAN7WAQUaQBdJQ5/LqgYWdmxUCEHOAyMtOKtFSJKcCoyFADrVZrcY808c+trvT0kycvrswtBAsJSEPdl9kVAeBXkJpFsjF91JpYl4aClhTDQJJnQwA26kKDbrcQMcdgrYFuywqg2x+/0Tbc5bIYOMh+9BKAycoU2DB+dOlYL1FDhuci4ACvhDk3C4EpFvzEzGGIJfslQP7J/orJmu4l62U3yQLcDtkO76tXt41KMLVRw+jiVNSQDSG4TewfSDY3vnFwDRAAu5E+DYWi1Evs8tGyAreNfz7wRcmLX44/AjAxdbAWnQQCbIOHDdParbX8arfIjh8cxfld6BDEAnQON9HTwVwA9xSlyscXJSWv7DXx9BpQZTq3DZsOdkGVGOw2K4bXpFmsYrz8rcP5AVKYAGSfi/P/OVTxFEj3vCwp+VLjWslsE44HmraADUbOrMDshulRCr0BOUUQuN883KLwA9xTfw/JfVnyMpYp6NxMNBxqwYCTs5QY0C1rLfi5AtC7YnRienK/HHyFX/ZU6GG5379w53lXWuu6d9O1AWOFmxNvM4A71SDzcwWUU5Ig+vIPM9wfyu+1hgm1g5/w0b/Bzhp0rGNKf3GzM25zrk1xP/FzAcrqCwVEVjx9+iyIEh/Kb4Cn6looe2Y741Iwn2gtnNLHzPBoVHGa4xQ+h4XYFQFyTkm1wFhlaXV19XPGYsD/J1XcNn6kSMF2P7bvuC0S6yN8SCmXttjA1BQjDarBj6LF+bUWh07Eb3z86OGj6scmTBYhgGeql3tKLOG4UwMBm0+x9uEzon5MN9NHTYZvhpnZUC7AT6AEgFEifpZRXqBWPyyfzqRY+J/KdO06pdOFnAAGZ4QqWuXZw5o0EnTFphlyv+dcZ2cmCgDnh/08/AKLnoE/cLj6GQ0XtWS+28ETUwjkFRgCgQjfVvSE4QLwZx8JUCWmI6v+CtCiPxVHNfhGr1dHqB++n4ITwB+y+sQCTm12qgIB1dQtYW050JtZUyAACGzHqoEAngMWMkoc0+0JevXQiMCV0ufUdWuV1ScGVQPNmjVrVNFTZ4k80JWxrb6IgEqVf3+9FXtGFIdbaBTPgKWwHy1xwiNygddAnhJzKykQd/9+tCo6slA0JevUgqUv9gQiM1ev/rGKSV5eA2OFRvEa8DVJL/fGmuLS8/jVJtXJL2ciFK/LBKKnLvFiFYhuVhmP+wL3VwNbadsUlZTQEnj+SpLMHxF5uKh8I+MI4w095fxNLmCrJPUWVMJuuD7f7YvOhICfGcgCXlLE/EDFo2xcmSMGqkj1w1IEAag/A4LHzmSuzsyfOsMuWoVwQSvG0pf6KAabZkm4axJrqoe/snwnAkAK0J0fLip9nFW/Avzl2a4j+Zn5zt2rGAqhCN0xrHet9zvz8z2vPyOoxnr5ryZgOKPRYBmoNOpiKMhQFIjPuXN012GP0z8T23IHZIAIjTCuNxWmLPZ4sm8FGYfwu6zPy6sKaDpEF8gIgTr7QVFRWaWxnlPY3bK8nf51M2k37tK4zhs2HRgkpM9amlR8TqiAfxS8UVRVnKDXYEDEx1R6fcGuqryiJ3clxiHgv5W3c8PFkUjq5j3ruXnapp/cluxJyn7w7i7jqM1vqijLy7uajSKoxwugGUnCzl05OTlHn9w1shAoZ+kqy/KKsy/iXYPO3ep9uK5139SWzdnJxKSCXccqrCwcpjvnqnJykk9T/kEB/sM/CEjYmTx2LCTcqMySWG0EnxSBf0kGa9Kr6X+eZ+rfY0DjVsy+Tp9U8KDq3J3J7B9YM56/u3b27NhkrAByP3fBULzFu9Nrx49PTk5+cOxGRUZob2/MOF+Wl3MkO+k6v1VUP35Xb3UvTUZhfC2nlX1JX5aVpWVltW4G2/tebRd1RmT13nTsYvgylzeGCm1jwS5zzgvFzTbRiUwFb4TygyRUEkIGKmEIEnTbdRD0D/R7nrPKuzW1oB/7VPT3ez7Oc97zvOdcr77Os4KEgpWx1c33319gfYktS/cann9+vzT7EvTgNzWCR8kQ9IJ22eBGsovRsrr55eP35y8A/iNEbNQ0ZeYPNlBYr1VftVy4ZR+WHk9r5wy8uvpmc2l9fX3p6weQgx3oyiIBCdyjouUx1un01cwuJpOJZBI6pltWZ98As6vIjRWY3+pp/lT41jlSoK7Ceu2JvaeZhljr1MzTsTGo+I2WlpbFKROmK3rqzuhoUwj0aXR8msxuLCaUBISDMLbybrSzFRGS3fd5TVwwBay2utf2h+PSRQrMqZmup2D9helEFvRwgNC4TQ7z80/d6/U1GY7JBWiACKhIJBZnRhc6TTVUfHNue62lEG5U37CUVD+zIwac5hSI7EwiOc3oSmwsMD2H3skNIi+LgP1en5761m+QPyYHFUxw41/wjCUDbykChVPgJryAPlMu6ncJITSS0GoOLmSBhalBE9/9VH+Esh9ux/zOAnx6+q59Qvfq3DcCJat0+VU/UW/q4KZAAdjq6mwQcB1Ny7Qk4cIlQLkFWh7CSbZz5KlJBffHwrh0CZM7kBoOfhf4LUJF/8eLFHRfLLyL9MZVVMPKvWiZRWLCRfdD4AMGjTnOPV2j6oOIex1ETi0qo60tFoqg/vTEhcZNOxYgODvAjkdT6g5dhPz5bjq7e05qLgKY4XZ8ht/BD0KIor5gX1+7wXDGgpnIPVr2DAkN2shwgC5VuImHABhDuSL20gFHDtobu6WLAXrMN6DmzIfNZLa3z9cXiA7Fu4OpzEAvX7j0hgJ+DeAJEkFx5ruo9M0Vxt4RazE7OmuxUA0IpYA8IWAYmS+EDtNIQFswMt/46MFdt6q3vZk4ZwgLcPLAZHL4RHcYqQb7geJOG9iwoy/jEsTMPgepcFLKIcXZQF9bZksXaSAU9fgxPFULWwc9P6CB1Brj6E6fLYqfGxYPOiSNYAqiE1HV0BYFNYD8a+9r6+6Zn5/vjXwayazFTeGnDBVOjRSo0kA+YPj60cCuKfrMyRW3vTEoaSSQGbBcdwoyy6sk+Hy+5mg0Ggs0O6UDYxUDHr6HBnIWxx5v5DMkYA96IrbiN3YfRV5RRSYfYLIhKG568sMhyUjOEioN7C4qkYLZHRD8k//wdo6b7DupFFBDWuMoYMphZtYB88BG4aGBysURQuEEQbzkfahB/vWD/8D2DjnYzmA5uSappOpQwPclsLTMgwRQUPI3b2iYwmgqv/hAYjWCEcxtmx8K4IP7aVPA9zAJVCh/fcoBHGHwQgFe/bh/ly/LeCMB8BdESVcIXdHy7fIjCsiDO+GoZJdy/Dn0gAoC57oGAcSPnysBgt0PHQbPDydKdnLCpH4/WndrLkNTnAywAGqoU2XUyOSf45O+IxkA6Qwuo31/6PwODzjS3p5wXEqNeYnBq5zBLFBB5EwPOUoVTRiOpugwNhKXVh2z7BAVh/ZgNKRjUhIT2a/mO11ZrT6yDq7RGAQ0Xo1AKEctUYR/x7CehRPckTQ6fLCfrVblSUcGMj1RokgLNVMKIY1AavkezK/fpaNe52tLMd3kMv0uw2AJqDU05ZAAzkKMBrwInjuFdMbn3oJ+/6FKy66hsoaWbI8mOqLtTQYPdtjK5RagCZABDVLG1kYa3aA/WWbd1dOmlTWlfJdoItXfbBhSeDD3szfwQnI8EmiOd4zk7vBpw92lZwkl9YeRjjj31BMOjUcDHmk0MdrwlGYgHgyFex6rI5+1laD/C9h3rqYcGkDRML88EM6kUx1AKj03PPIq8lhdmuwpP3rcZvl7sJXVni791QW4TXBvOYV9+tI/OP58rOT4pTPlpfvdSoeiPnjgxNGqsgqr5R/Buq/iyLmLp6ou11+qv1x16nhZie2Y5T/FD20ZaW0SClivAAAAAElFTkSuQmCC"/></a>',document.getElementsByClassName("ex-panel__wrap")[0]),l=(i.insertBefore(l,i.childNodes[0]),document.getElementsByClassName("ex-fkbuff")[0].addEventListener("click",function(){w("https://fkbuff.com/")}),document.createElement("div")),i=(l.className="ex-monitor",l.innerHTML='<a class="ex-panel__icon" title="在线弹幕助手"><svg style="display:block;" t="1638235744961" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="69800" width="32" height="32"><path d="M426.666667 106.666667a21.333333 21.333333 0 0 1 21.333333-21.333334h512a21.333333 21.333333 0 0 1 0 42.666667H448a21.333333 21.333333 0 0 1-21.333333-21.333333z m533.333333 789.333333H448a21.333333 21.333333 0 0 0 0 42.666667h512a21.333333 21.333333 0 0 0 0-42.666667z m0-554.666667H448a21.333333 21.333333 0 0 0 0 42.666667h512a21.333333 21.333333 0 0 0 0-42.666667z m0 298.666667H448a21.333333 21.333333 0 0 0 0 42.666667h512a21.333333 21.333333 0 0 0 0-42.666667zM245.333333 42.666667H96a53.393333 53.393333 0 0 0-53.333333 53.333333v149.333333a53.393333 53.393333 0 0 0 53.333333 53.333334h149.333333a53.393333 53.393333 0 0 0 53.333334-53.333334V96a53.393333 53.393333 0 0 0-53.333334-53.333333z m0 341.333333H96a53.393333 53.393333 0 0 0-53.333333 53.333333v149.333334a53.393333 53.393333 0 0 0 53.333333 53.333333h149.333333a53.393333 53.393333 0 0 0 53.333334-53.333333V437.333333a53.393333 53.393333 0 0 0-53.333334-53.333333z m0 341.333333H96a53.393333 53.393333 0 0 0-53.333333 53.333334v149.333333a53.393333 53.393333 0 0 0 53.333333 53.333333h149.333333a53.393333 53.393333 0 0 0 53.333334-53.333333v-149.333333a53.393333 53.393333 0 0 0-53.333334-53.333334z" fill="#13227a" p-id="69801"></path></svg><i id="Monitor__tip" class="ex-panel__tip"></i></a>',document.getElementsByClassName("ex-panel__wrap")[0]),l=(i.insertBefore(l,i.childNodes[0]),document.getElementsByClassName("ex-monitor")[0].addEventListener("click",function(){w("https://www.douyuex.com/"+String(B))}),(async()=>{var t=[],e=await fetch("https://www.douyu.com/member/cp/getFansBadgeList",{method:"GET",mode:"no-cors",cache:"default",credentials:"include"}).then(e=>e.text()).catch(e=>{console.log("请求失败!",e)}),o=(e=(new DOMParser).parseFromString(e,"text/html")).getElementsByClassName("fans-badge-list")[0].lastElementChild,n=o.children.length;for(let e=0;e<n;e++){var i=o.children[e].getAttribute("data-fans-room");t.push(i)}Fo=t})(),document.createElement("div")),i=(l.className="exlottery",l.innerHTML=`
        <div class="lottery__func">
            <div id="lottery-refresh">
                <svg t="1636115506027" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2454" width="16" height="16"><path d="M927.999436 531.028522a31.998984 31.998984 0 0 0-31.998984 31.998984c0 51.852948-10.147341 102.138098-30.163865 149.461048a385.47252 385.47252 0 0 1-204.377345 204.377345c-47.32295 20.016524-97.6081 30.163865-149.461048 30.163865s-102.138098-10.147341-149.461048-30.163865a385.47252 385.47252 0 0 1-204.377345-204.377345c-20.016524-47.32295-30.163865-97.6081-30.163865-149.461048s10.147341-102.138098 30.163865-149.461048a385.47252 385.47252 0 0 1 204.377345-204.377345c47.32295-20.016524 97.6081-30.163865 149.461048-30.163865a387.379888 387.379888 0 0 1 59.193424 4.533611l-56.538282 22.035878A31.998984 31.998984 0 1 0 537.892156 265.232491l137.041483-53.402685a31.998984 31.998984 0 0 0 18.195855-41.434674L639.723197 33.357261a31.998984 31.998984 0 1 0-59.630529 23.23882l26.695923 68.502679a449.969005 449.969005 0 0 0-94.786785-10.060642c-60.465003 0-119.138236 11.8488-174.390489 35.217667a449.214005 449.214005 0 0 0-238.388457 238.388457c-23.361643 55.252253-35.22128 113.925486-35.22128 174.390489s11.8488 119.138236 35.217668 174.390489a449.214005 449.214005 0 0 0 238.388457 238.388457c55.252253 23.368867 113.925486 35.217667 174.390489 35.217667s119.138236-11.8488 174.390489-35.217667A449.210393 449.210393 0 0 0 924.784365 737.42522c23.368867-55.270316 35.217667-113.925486 35.217667-174.390489a31.998984 31.998984 0 0 0-32.002596-32.006209z" fill="" p-id="2455"></path></svg>
            </div>
            <div class="lottery__notice">
                <label class="lottery__notice"><input class="lottery__notice" id="lottery-notice" type="checkbox">开启提醒</label>
            </div>
        </div>
        <div class="lottery__nodata">暂无数据</div>
        <div class="lottery__wrap"></div>
    `,document.getElementsByClassName("layout-Player-chat")[0]),l=(i.insertBefore(l,i.childNodes[0]),document.createElement("div")),i=(l.className="ex-lottery",l.innerHTML='<a class="ex-panel__icon" title="全站抽奖信息"><svg style="display:block;" t="1636332741708" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="19181" width="32" height="32"><path d="M508.858182 986.042182c-261.748364 0-473.925818-212.177455-473.925818-473.925818S247.109818 38.190545 508.858182 38.190545s473.925818 212.177455 473.925818 473.925819-212.200727 473.925818-473.925818 473.925818m0-981.690182C228.421818 4.352 1.093818 231.703273 1.093818 512.116364s227.351273 507.764364 507.764364 507.764363c280.413091 0 507.787636-227.351273 507.787636-507.764363S789.271273 4.352 508.858182 4.352" fill="#FF4517" p-id="19182"></path><path d="M322.536727 512.302545l0.023273-1.326545-313.064727-1.931636c0 1.093818-0.093091 2.164364-0.093091 3.281454 0 90.88 24.785455 175.918545 67.84 248.925091l270.173091-155.997091a185.274182 185.274182 0 0 1-24.878546-92.951273zM416.791273 350.440727L264.029091 82.013091A492.986182 492.986182 0 0 0 77.498182 262.981818l270.173091 155.997091a186.717091 186.717091 0 0 1 69.12-68.538182zM602.856727 351.697455l151.831273-259.211637A488.261818 488.261818 0 0 0 508.718545 21.690182l0.023273 304.453818c34.350545 0 66.513455 9.355636 94.114909 25.553455zM258.536727 939.450182a488.471273 488.471273 0 0 0 241.710546 63.674182c2.839273 0 5.632-0.139636 8.448-0.186182V698.507636a185.064727 185.064727 0 0 1-94.068364-25.553454l-156.090182 266.496zM927.325091 270.452364l-257.466182 148.666181a185.204364 185.204364 0 0 1 25.041455 93.207273l-0.046546 1.070546 296.168727 1.838545c0.023273-0.977455 0.069818-1.931636 0.069819-2.909091 0-87.994182-23.249455-170.496-63.767273-241.873454zM600.855273 674.094545l148.573091 261.073455a492.776727 492.776727 0 0 0 178.106181-181.387636l-257.466181-148.642909a187.042909 187.042909 0 0 1-69.213091 68.95709z" fill="#FF4517" p-id="19183"></path><path d="M644.142545 512.302545a135.400727 135.400727 0 0 0-135.424-135.400727l-84.619636-160.791273 20.642909 173.824c-42.658909 22.784-71.400727 70.609455-71.400727 122.368a135.447273 135.447273 0 0 0 270.801454 0z m-133.492363 70.097455a68.491636 68.491636 0 1 1 0.023273-136.96 68.491636 68.491636 0 0 1-0.023273 136.96z" fill="#FF4517" p-id="19184"></path></svg><i id="lottery__tip" class="ex-panel__tip"></i></a>',document.getElementsByClassName("ex-panel__wrap")[0]);i.insertBefore(l,i.childNodes[0]);{let t=document.getElementById("lottery-notice");document.getElementsByClassName("ex-lottery")[0].addEventListener("click",()=>{ee("全站抽奖信息");var e=document.getElementsByClassName("lottery__wrap")[0];e&&(e.innerHTML=Go)}),document.getElementById("lottery-refresh").addEventListener("click",((o,n)=>{let i;return function(){var e=arguments,t=(i&&clearTimeout(i),!i);i=setTimeout(()=>{i=null},n),t&&o.apply(this,e)}})(()=>{Uo()},3e3)),t.addEventListener("click",()=>{var e=t.checked;Vo=1==e,e={isNotice:Vo},localStorage.setItem("ExSave_Lottery",JSON.stringify(e))})}l=localStorage.getItem("ExSave_Lottery"),null!=l&&1==JSON.parse(l).isNotice&&document.getElementById("lottery-notice").click(),qo=setInterval(()=>{Uo()},6e4),i=document.createElement("div"),i.className="popup-player",i.innerHTML='<a class="ex-panel__icon" title="同屏播放"><svg style="display:block;" t="1579448049771" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1804" width="30" height="30"><path d="M353.024 900.416H109.952c-57.856 0-109.952-46.336-109.952-98.432V153.6c0-52.096 52.096-98.432 109.952-98.432h810.176c57.856 0 104.192 46.336 104.192 98.496v185.472c0 28.928-23.168 52.096-46.336 52.096s-46.272-23.168-46.272-52.096V159.36H98.368V807.68h248.896c34.688 0 52.032 17.408 52.032 46.336 0 28.928-17.344 46.272-46.272 46.272" fill="#f26b1f" p-id="1805"></path><path d="M619.2 631.488c-5.76 0-5.76 5.76-5.76 11.52v223.04c0 5.76 5.76 11.52 5.76 11.52h289.344c5.76 0 11.584-5.76 11.584-11.52v-222.976c0-5.824-5.76-11.584-11.52-11.584H619.136z m289.344 338.688h-289.28a103.68 103.68 0 0 1-104.192-104.128v-222.976c0-57.92 46.272-109.952 104.128-109.952h289.344c57.856 0 104.128 46.272 104.128 109.952v222.976c5.824 57.856-40.448 104.128-104.128 104.128z" fill="#f26b1f" p-id="1806"></path></svg><i id="popup-player__tip" class="ex-panel__tip"></i></a>',l=document.getElementsByClassName("ex-panel__wrap")[0],l.insertBefore(i,l.childNodes[0]),i=document.createElement("div"),l="",i.className="postbird-box-container",i.id="popup-player__prompt",l+='<div class="postbird-box-dialog">',i.innerHTML='<div class="postbird-box-dialog"><div style="min-height:170px" class="postbird-box-content"><div class="postbird-box-header"><span class="postbird-box-title"><span>请输入直播间/直播流地址：</span><a style="float:right;color:royalblue;" href="http://live.douyuex.com/" target="_blank">DouyuEx联播</a></span></div><div class="postbird-box-text"><input id="popup-player__url" value="https://www.douyu.com/4042402" style="height:30px;box-sizing:border-box" type="text" class="postbird-prompt-input" autofocus="true"><label style="margin-right:30px" title="【直播流模式】&#10;1. 速度快&#10;2. 延迟低&#10;3. 占用少&#10;4. 不会进入直播间&#10;5. 支持斗鱼/虎牙/Bilibili"><input id="popup-player__noiframe" type="radio" name="sex" value="无弹幕" checked="checked">无弹幕(推荐)</label><label title="【框架模式】&#10;1. 速度慢&#10;2. 占用高&#10;3. 会进入直播间&#10;4. 仅支持斗鱼&#10;此模式拖动不是很灵活，请尽量在标题栏小幅度拖动&#10;若拖动无反应请点击页面任意处触发移动"><input id="popup-player__iframe" type="radio" name="sex" value="有弹幕">有弹幕</label></div><div class="postbird-box-footer"><button id="popup-player__cancel" class="btn-footer btn-left-footer btn-footer-cancel" style="color:undefined;">取消</button><button id="popup-player__ok" class="btn-footer btn-right-footer btn-footer-ok" style="color:#0e90d2;">确定</button></div></div>',(l=k([".layout-Main",".playerWrap__8wGvw",".live-next-body"])).insertBefore(i,l.childNodes[0]),document.getElementsByClassName("popup-player")[0].addEventListener("click",function(){document.getElementById("popup-player__prompt").style.display="block"}),document.getElementById("popup-player__cancel").addEventListener("click",function(){document.getElementById("popup-player__prompt").style.display="none"}),document.getElementById("popup-player__ok").addEventListener("click",function(){var a,t=document.getElementById("popup-player__url").value;if(""!=t){var o,n,i,r=document.getElementById("popup-player__noiframe").checked;let e=!1;if(e=150<t.length&&1==window.confirm("你输入的是直播流吗？")?!0:e)xn(A.length,t);else if(1==r)if(-1!=t.indexOf("douyu.com"))a=e=>{gn(A.length,e,"Douyu")},fetch(t,{method:"GET",mode:"no-cors",cache:"default",credentials:"include"}).then(e=>e.text()).then(e=>{var t=(e=(new DOMParser).parseFromString(e,"text/html")).getElementsByTagName("html")[0].innerHTML,o="$ROOM.room_id =".length,n=t.indexOf("$ROOM.room_id =");let i="";0<n?i=(i=t.substring(n+o,t.indexOf(";",n+o))).trim():(i=v(t,"roomID:",","))?i=i.trim():(n=e.querySelector('link[rel="canonical"]'))&&(o=n.getAttribute("href"),i=o.split("/").pop().trim()),1==!!/^[0-9]+$/.test(i)?a(i):S("获取直播间失败，请检查直播间地址是否正确！","error")}).catch(e=>{console.log("请求失败!",e)});else if(-1!=t.indexOf("bilibili.com")){var r=t,l=e=>{gn(A.length,e,"Bilibili")};r=(r=r.split("/"))[r.length-1],GM_xmlhttpRequest({method:"GET",url:"https://api.live.bilibili.com/room/v1/Room/room_init?id="+r,responseType:"json",onload:function(e){e=e.response;l(e.data.room_id)}})}else-1!=t.indexOf("huya.com")?gn(A.length,t,"Huya"):xn(A.length,t);else{r=A.length;if(-1==String(t).indexOf("douyu.com"))S("有弹幕模式仅支持斗鱼直播","error");else{i=String(t).split("/"),i=i[i.length-1],o=document.createElement("div"),n="",o.id="exVideoDiv"+String(r),o.rid=i,o.className="exVideoDiv",n=(n=(n=(n+="<div class='exVideoInfo' id='exVideoInfo"+String(r)+"'><span class='exVideoRID' id='exVideoRID"+String(r)+"' style='color:white'>斗鱼 - "+i+"</span>")+"<a><div class='exVideoClose' id='exVideoClose"+String(r)+"'>X</div></a></div>")+"<iframe class='exVideoPlayer' id='exVideoPlayer"+String(r)+"' src="+t+"?exid=chun></iframe>")+"<div class='exVideoScale' id='exVideoScale"+String(r)+"'></div>",o.innerHTML=n,(i=k([".layout-Main",".playerWrap__8wGvw",".live-next-body"])).insertBefore(o,i.childNodes[0]),yn(r),fn(r),r>A.length-1?A.push("iframe"):A[r]="iframe";{var s=r;let e=document.getElementById("exVideoDiv"+String(s)),t=document.getElementById("exVideoClose"+String(s));t.onclick=function(){A[s].destroy(),e.remove()},e.onclick=function(e){e.stopPropagation(),e.preventDefault();for(let e=0;e<A.length;e++){var t=document.getElementById("exVideoDiv"+String(e));null!=t&&(e==s?t.style.zIndex=1016:t.style.zIndex=1428)}}}}}}else S("请输入地址","error");document.getElementById("popup-player__prompt").style.display="none"}),document.getElementById("popup-player__prompt").addEventListener("keydown",function(t){var o=window.event||e;13==(o.keyCode||o.which||o.charCode)&&document.getElementById("popup-player__ok").click()}),i=document.createElement("div"),i.className="livetool",l=document.getElementsByClassName("layout-Player-chat")[0],l.insertBefore(i,l.childNodes[0]),i=document.createElement("div"),i.className="livetool-icon",i.innerHTML='<a class="ex-panel__icon" title="直播间工具"><svg t="1590294900594" style="display:block;" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="20028" width="36" height="36"><path d="M352.2 245.3c-5.1 0-10.2-2-14.1-5.9L196.6 98c-7.8-7.8-7.8-20.5 0-28.3s20.5-7.8 28.3 0l141.4 141.4c7.8 7.8 7.8 20.5 0 28.3-3.9 3.9-9 5.9-14.1 5.9zM477.1 245.3c-5.1 0-10.2-2-14.1-5.9-7.8-7.8-7.8-20.5 0-28.3L604.3 69.7c7.8-7.8 20.5-7.8 28.3 0 7.8 7.8 7.8 20.5 0 28.3L491.2 239.4c-3.9 3.9-9 5.9-14.1 5.9z" fill="#0C2B4A" p-id="20029"></path><path d="M703.9 194.8H124.2c-33 0-60 27-60 60v453c0 33 27 60 60 60h418c1.7-122.5 99.6-221.8 221.7-225.5V254.8c0-33-27-60-60-60zM533.4 522.9L356.3 625.2c-24 13.9-54-3.5-54-31.2V389.5c0-27.7 30-45 54-31.2l177.1 102.2c24 13.9 24 48.6 0 62.4zM815.2 776.4c0 21.9-17.8 39.7-39.7 39.7-21.9 0-39.7-17.8-39.7-39.7 0-21.9 17.8-39.7 39.7-39.7 21.9 0 39.7 17.8 39.7 39.7z" fill="#0C2B4A" p-id="20030"></path><path d="M775.5 591C673.6 591 591 673.6 591 775.5S673.6 960 775.5 960 960 877.4 960 775.5 877.4 591 775.5 591zM879 819l-15.6 27c-2.1 3.6-6.8 4.9-10.4 2.8l-15.5-8.9c-2.7-1.6-6.1-1.3-8.5 0.6-7.5 5.9-15.9 10.6-25.1 13.8-3 1.1-5.1 4-5.1 7.2v18.7c0 4.2-3.4 7.6-7.6 7.6H760c-4.2 0-7.6-3.4-7.6-7.6v-18.5c0-3.3-2.1-6.2-5.1-7.2-9.3-3.2-17.9-7.8-25.5-13.7-2.4-1.9-5.8-2.2-8.5-0.6l-15.2 8.8c-3.6 2.1-8.3 0.9-10.4-2.8l-15.6-27c-2.1-3.6-0.8-8.3 2.8-10.4l12.2-7.1c3-1.7 4.5-5.2 3.7-8.5-1.7-6.8-2.6-13.8-2.6-21.1 0-4.1 0.3-8.2 0.9-12.2 0.4-3.1-1-6.1-3.7-7.7l-10.5-6.1c-3.6-2.1-4.9-6.8-2.8-10.4l15.6-27c2.1-3.6 6.8-4.9 10.4-2.8l7.8 4.5c2.9 1.7 6.6 1.3 9-1.1 9.1-8.7 20-15.5 32.2-19.7 3.1-1 5.1-4 5.1-7.2v-7.9c0-4.2 3.4-7.6 7.6-7.6H791c4.2 0 7.6 3.4 7.6 7.6v8.1c0 3.2 2 6.1 5.1 7.2 12.1 4.2 22.9 10.9 31.9 19.6 2.4 2.4 6.1 2.8 9.1 1.1l8.2-4.7c3.6-2.1 8.3-0.8 10.4 2.8l15.6 27c2.1 3.6 0.9 8.3-2.8 10.4l-11 6.3c-2.7 1.6-4.1 4.6-3.7 7.7 0.6 3.9 0.8 8 0.8 12.1 0 7.2-0.9 14.1-2.5 20.8-0.8 3.3 0.7 6.7 3.6 8.3l12.8 7.4c3.7 2.1 5 6.8 2.9 10.4z" fill="#0C2B4A" p-id="20031"></path></svg><i id="LiveTool__tip" class="ex-panel__tip"></i></a>',l=document.getElementsByClassName("ex-panel__wrap")[0],l.insertBefore(i,l.childNodes[0]),i=document.createElement("div"),i.className="livetool__cell",i.innerHTML=`
        <div class='livetool__cell_title'>
            <span id='vote__title'>弹幕投票</span><span id='vote__show-result'>面板</span>
        </div>
        <div class='livetool__cell_option'>
            <label style="margin-right:10px;"><input id="vote__repeat" type="checkbox">重复投票</label>
            <div class="onoffswitch livetool__cell_switch">
                <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="vote__switch" tabindex="0" checked>
                <label class="onoffswitch-label" for="vote__switch"></label>
            </div>
        </div>
    `+`
        <div class='vote__panel'>
            <select id='vote__select'>
            </select>
            <input style="width:40px;margin-left:10px;" type="button" id="vote__add" value="添加"/>
            <input style="width:40px;margin-left:10px;" type="button" id="vote__del" value="删除"/>
            <label style="margin-left:5px">限时：<input id="vote__time" type="text" placeholder="秒" /></label>
            <div class="vote__option">
                <label>主题：<input id="vote__theme" type="text"/></label>
                <label>选项：<input id="vote__options" type="text" placeholder="用空格隔开每个选项"/></label>
            </div>
        </div>
    `,l=document.getElementsByClassName("livetool")[0];l.insertBefore(i,l.childNodes[0]);{let e=document.createElement("div"),t=(e.className="vote__result",e.innerHTML=`
        <div id="vote__result-theme">投票主题</div>
        <div id="vote__result-close">X</div>
        <div id="vote__result-options"></div>
    `,k([".layout-Player-main","main"])),a=(t.insertBefore(e,t.childNodes[0]),document.getElementsByClassName("vote__result")[0]);a.onmousedown=function(e){e.stopPropagation();let t=e.clientX-a.offsetLeft,o=e.clientY-a.offsetTop,n,i;document.onmousemove=function(e){e.stopPropagation(),n=e.clientX-t,i=e.clientY-o,a.style.left=n+"px",a.style.top=i+"px"},document.onmouseup=function(e){e.stopPropagation(),document.onmousemove=null,document.onmouseup=null}},document.getElementById("vote__result-close").addEventListener("click",()=>{document.getElementsByClassName("vote__result")[0].style.display="none"})}document.getElementById("vote__switch").addEventListener("click",()=>{var e=document.getElementById("vote__switch").checked,t=document.getElementById("vote__select"),t=t.options[t.selectedIndex].text,o=Lo[t].options,n=Lo[t].time;if(1==e){var i=String(o).split(" ");for(let e=0;e<i.length;e++)Do[i[e]]={num:0,index:e};document.getElementById("vote__repeat").disabled=!0,jo=0,e=t,t=o,document.getElementById("vote__result-theme").innerText=e,document.getElementById("vote__result-options").innerHTML="";var a=t.split(" "),r=document.getElementById("vote__result-options");for(let e=0;e<a.length;e++){var l=document.createElement("div");l.className="vote__option-wrap",l.innerHTML=`
            <div class="vote__option-choice">${a[e]}</div>
            <div class="vote__option-num"></div>
            <div class="vote__progress">
                <div class="vote__progress-bar"></div>
            </div>
        `,r.appendChild(l)}zo=document.getElementById("vote__repeat").checked,Mo=!0,Po=setTimeout(()=>{Ao={},Do={},Mo=!1,document.getElementById("vote__repeat").disabled=!1,document.getElementById("vote__switch").checked=!1},1e3*n),document.getElementsByClassName("vote__result")[0].style.display="block"}else clearTimeout(Po),Ao={},Do={},Mo=!1,document.getElementById("vote__repeat").disabled=!1}),document.getElementById("vote__title").addEventListener("click",()=>{var e=document.getElementsByClassName("vote__panel")[0];"block"!=e.style.display?((e.style.display="block")==document.getElementsByClassName("mute__panel")[0].style.display&&(document.getElementsByClassName("mute__panel")[0].style.display="none"),"block"==document.getElementsByClassName("enter__panel")[0].style.display&&(document.getElementsByClassName("enter__panel")[0].style.display="none"),"block"==document.getElementsByClassName("gift__panel")[0].style.display&&(document.getElementsByClassName("gift__panel")[0].style.display="none"),"block"==document.getElementsByClassName("reply__panel")[0].style.display&&(document.getElementsByClassName("reply__panel")[0].style.display="none")):e.style.display="none"}),document.getElementById("vote__select").onclick=function(){var e,t,o;0!=this.options.length&&(e=this.options[this.selectedIndex].text,t=Lo[e].options,o=Lo[e].time,document.getElementById("vote__theme").value=e,document.getElementById("vote__options").value=t,document.getElementById("vote__time").value=o)},document.getElementById("vote__add").addEventListener("click",()=>{var e=document.getElementById("vote__select"),t=document.getElementById("vote__theme").value,o=document.getElementById("vote__options").value,n=document.getElementById("vote__time").value;""!=t&&""!=o&&""!=n&&(Lo[t]={options:o,time:n},e.options.add(new Option(t,"")),Oo())}),document.getElementById("vote__del").addEventListener("click",()=>{var e=document.getElementById("vote__select"),t=e.options[e.selectedIndex].text;delete Lo[t],e.options.remove(e.selectedIndex),Oo()}),document.getElementById("vote__show-result").addEventListener("click",()=>{var e=document.getElementsByClassName("vote__result")[0];"block"!=e.style.display?e.style.display="block":e.style.display="none"}),document.getElementById("vote__switch").checked=Eo;i=localStorage.getItem("ExSave_Vote");if(null!=i){var s,d=JSON.parse(i),p=(Lo=d,document.getElementById("vote__select"));for(s in d)d.hasOwnProperty(s)&&p.options.add(new Option(s,""))}l=document.createElement("div"),l.className="livetool__cell",l.innerHTML=`
        <div class='livetool__cell_title'>
            <span id='enter__title'>进场欢迎</span>
            <span id='enter__export'>导出</span>
            <span id='enter__import'>导入</span>
        </div>
        <div class='livetool__cell_option'>
            <div class="onoffswitch livetool__cell_switch">
                <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="enter__switch" tabindex="0" checked>
                <label class="onoffswitch-label" for="enter__switch"></label>
            </div>
        </div>
    `+`
        <div class='enter__panel'>
            <select id='enter__select'>
            </select>
            <input style="width:40px;margin-left:10px;" type="button" id="enter__add" value="添加"/>
            <input style="width:40px;margin-left:10px;" type="button" id="enter__del" value="删除"/>
            <div class="enter__option">
                <label>等级≥<input id="enter__level" type="text" value="1"/></label>
                <label>当前欢迎词：<input id="enter__word" type="text" placeholder="欢迎<id>光临直播间"/></label>
            </div>
        </div>
    `,i=document.getElementsByClassName("livetool")[0],i.insertBefore(l,i.childNodes[0]),document.getElementById("enter__export").addEventListener("click",()=>{GM_setClipboard(JSON.stringify(T)),S("【进场欢迎】导出完毕，已复制到剪贴板","success")}),document.getElementById("enter__import").addEventListener("click",()=>{dl.prompt({title:"请输入json文本（会覆盖原来的设置）",okBtn:"确定",onConfirm:function(e){var t=document.getElementById("enter__select"),e=JSON.parse(e||"{}")||{};if("object"==typeof e){for(var o in T={...e},t.options.length=0,T)T.hasOwnProperty(o)&&t.options.add(new Option(o,""));ao()}S("【进场欢迎】导入完毕","success")},onCancel:function(e){}})}),document.getElementById("enter__switch").addEventListener("click",()=>{var o=document.getElementById("enter__switch").checked;io=1==o;{let e=[],t=localStorage.getItem("ExSave_isEnter");var n=(e=null!=t&&"rooms"in(n=JSON.parse(t))==1?n.rooms:e).indexOf(B),o=(1==io?-1==n&&e.push(B):e.splice(n,1),{rooms:e});localStorage.setItem("ExSave_isEnter",JSON.stringify(o))}}),document.getElementById("enter__title").addEventListener("click",()=>{var e=document.getElementsByClassName("enter__panel")[0];"block"!=e.style.display?((e.style.display="block")==document.getElementsByClassName("mute__panel")[0].style.display&&(document.getElementsByClassName("mute__panel")[0].style.display="none"),"block"==document.getElementsByClassName("reply__panel")[0].style.display&&(document.getElementsByClassName("reply__panel")[0].style.display="none"),"block"==document.getElementsByClassName("gift__panel")[0].style.display&&(document.getElementsByClassName("gift__panel")[0].style.display="none"),"block"==document.getElementsByClassName("vote__panel")[0].style.display&&(document.getElementsByClassName("vote__panel")[0].style.display="none")):e.style.display="none"}),document.getElementById("enter__select").onclick=function(){var e,t;0!=this.options.length&&(e=this.options[this.selectedIndex].text,t=T[e].enter,document.getElementById("enter__word").value=e,document.getElementById("enter__level").value=t,localStorage.setItem("ExSave_LastEnterWord",e))},document.getElementById("enter__add").addEventListener("click",()=>{document.getElementById("enter__select");var t=document.getElementById("enter__word").value,o=document.getElementById("enter__level").value;if(""!=t&&""!=o){let e=!1;for(var n of T)if(Number(o)===Number(n.level)){e=!0;break}e?S("【进场欢迎】等级已存在","error"):(T.push({level:o,word:t}),T.sort((e,t)=>t.level-e.level),ro(),ao())}}),document.getElementById("enter__del").addEventListener("click",()=>{var e=document.getElementById("enter__select");e.options[e.selectedIndex].text,T.splice(e.selectedIndex,1),T.sort((e,t)=>t.level-e.level),ro(),ao()}),l=localStorage.getItem("ExSave_Enter");if(""!=l){if(document.getElementById("enter__select"),null!=l){let e=JSON.parse(l);Array.isArray(e)||(e=[],ao()),T=e,ro()}if(null!=(l=localStorage.getItem("ExSave_isEnter"))){l=JSON.parse(l);let e=[];"rooms"in l==1&&(e=l.rooms),io=-1!=e.indexOf(B)}else io=!1;document.getElementById("enter__switch").checked=io}i=document.createElement("div"),i.className="livetool__cell",i.innerHTML=`
        <div class='livetool__cell_title'>
            <span id='mute__title'>关键词禁言</span>
            <span id='mute__idlist'>名单</span>
            <span id='mute__export'>导出</span>
            <span id='mute__import'>导入</span>
        </div>
        <div class='livetool__cell_option'>
            <div class="onoffswitch livetool__cell_switch">
                <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="mute__switch" tabindex="0" checked>
                <label class="onoffswitch-label" for="mute__switch"></label>
            </div>
        </div>
    `+`
        <div class='mute__panel'>
            <select id='mute__select'>
            </select>
            <input style="width:40px;margin-left:10px;" type="button" id="mute__add" value="添加"/>
            <input style="width:40px;margin-left:10px;" type="button" id="mute__del" value="删除"/>
            <input style="width:65px;margin-left:10px;" type="button" id="mute__delmute" value="一键解禁"/>
            <div class="mute__option">
                <label>词：<input id="mute__word" type="text" placeholder="re(式)=结果"/></label>
                <label>次数：<input id="mute__count" type="number" value="5"/></label>
                <label>时间：
                    <select id='mute__time'>
                        <option value="1">1分钟</option>
                        <option value="10">10分钟</option>
                        <option value="30">30分钟</option>
                        <option value="60">1小时</option>
                        <option value="480">8小时</option>
                        <option value="1440">1天</option>
                        <option value="4320">3天</option>
                        <option value="10080">7天</option>
                        <option value="43200">30天</option>
                        <option value="259200">180天</option>
                        <option value="518400">360天</option>
                    </select>
                </label>
            </div>
        </div>
    `,l=document.getElementsByClassName("livetool")[0],l.insertBefore(i,l.childNodes[0]),document.getElementById("mute__export").addEventListener("click",()=>{GM_setClipboard(JSON.stringify(L)),S("【关键词禁言】导出完毕，已复制到剪贴板","success")}),document.getElementById("mute__import").addEventListener("click",()=>{dl.prompt({title:"请输入json文本（会覆盖原来的设置）",okBtn:"确定",onConfirm:function(e){var t=document.getElementById("mute__select"),e=JSON.parse(e||"{}")||{};if("object"==typeof e){for(var o in L={...e},t.options.length=0,L)L.hasOwnProperty(o)&&t.options.add(new Option(o,""));uo()}S("【关键词禁言】导入完毕","success")},onCancel:function(e){}})}),document.getElementById("mute__idlist").addEventListener("click",()=>{if(0==mo.length)S("暂无禁言名单","warning");else{console.log("【禁言名单】");for(let e=0;e<mo.length;e++){var t=mo[e];console.log("id:【"+t.id+"】 | uid:"+t.uid+" | 弹幕:"+t.barrage+" | 检测次数:"+t.count+" | 禁言时长:"+t.time+"分钟 | 禁言时间:"+t.ts)}S("禁言名单已经输出在控制台，请按F12查看","success")}}),document.getElementById("mute__delmute").addEventListener("click",async()=>{if(0==mo.length)S("暂无禁言名单","warning");else if(1==confirm("是否解禁名单上所有的id？")){for(let e=0;e<mo.length;e++){var t=mo[e];await((e,o)=>new Promise(t=>{fetch("https://www.douyu.com/room/roomSetting/deleteMuteUser",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"room_id="+e+"&uid="+o}).then(e=>e.json()).then(e=>{t(e)})}))(B,t.uid)}S("解除禁言完毕","success")}}),document.getElementById("mute__switch").addEventListener("click",()=>{var o=document.getElementById("mute__switch").checked;co=1==o;{let e=[],t=localStorage.getItem("ExSave_isMute");var n=(e=null!=t&&"rooms"in(n=JSON.parse(t))==1?n.rooms:e).indexOf(B),o=(1==co?-1==n&&e.push(B):e.splice(n,1),{rooms:e});localStorage.setItem("ExSave_isMute",JSON.stringify(o))}}),document.getElementById("mute__title").addEventListener("click",()=>{var e=document.getElementsByClassName("mute__panel")[0];"block"!=e.style.display?((e.style.display="block")==document.getElementsByClassName("reply__panel")[0].style.display&&(document.getElementsByClassName("reply__panel")[0].style.display="none"),"block"==document.getElementsByClassName("enter__panel")[0].style.display&&(document.getElementsByClassName("enter__panel")[0].style.display="none"),"block"==document.getElementsByClassName("gift__panel")[0].style.display&&(document.getElementsByClassName("gift__panel")[0].style.display="none"),"block"==document.getElementsByClassName("vote__panel")[0].style.display&&(document.getElementsByClassName("vote__panel")[0].style.display="none")):e.style.display="none"}),document.getElementById("mute__select").onclick=function(){if(0!=this.options.length){var e=this.options[this.selectedIndex].text,t=L[e].count,o=L[e].time,e=(document.getElementById("mute__word").value=e,document.getElementById("mute__count").value=t,"mute__time"),n=o,i=document.getElementById(e);for(let e=0;e<i.options.length;e++)if(i.options[e].value==n){i.options[e].selected=!0;break}}},document.getElementById("mute__add").addEventListener("click",()=>{var e=document.getElementById("mute__time"),t=document.getElementById("mute__select"),o=document.getElementById("mute__word").value,n=document.getElementById("mute__count").value,e=e.options[e.selectedIndex].value;""!=o&&(L[o]={count:n,time:e},t.options.add(new Option(o,"")),uo())}),document.getElementById("mute__del").addEventListener("click",()=>{var e=document.getElementById("mute__select"),t=e.options[e.selectedIndex].text;delete L[t],e.options.remove(e.selectedIndex),uo()}),(async()=>{var t=localStorage.getItem("ExSave_Mute");if(null!=t){var e,o=JSON.parse(t),n=(L=o,document.getElementById("mute__select"));for(e in o)o.hasOwnProperty(e)&&n.options.add(new Option(e,""))}if(null!=(t=localStorage.getItem("ExSave_isMute"))){t=JSON.parse(t);let e=[];"rooms"in t==1&&(e=t.rooms),co=-1!=e.indexOf(B)}else co=!1;document.getElementById("mute__switch").checked=co})(),i=document.createElement("div"),i.className="livetool__cell",i.innerHTML=`
        <div class='livetool__cell_title'>
            <span id='gift__title'>自动谢礼物</span>
            <span id='gift__export'>导出</span>
            <span id='gift__import'>导入</span>
        </div>
        <div class='livetool__cell_option'>
            <div class="onoffswitch livetool__cell_switch">
                <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="gift__switch" tabindex="0" checked>
                <label class="onoffswitch-label" for="gift__switch"></label>
            </div>
        </div>
    `+`
        <div class='gift__panel'>
            <select id='gift__select'>
            </select>
            <input style="width:40px;margin-left:10px;" type="button" id="gift__add" value="添加"/>
            <input style="width:40px;margin-left:10px;" type="button" id="gift__del" value="删除"/>
            <input style="width:64px;margin-left:10px;" type="button" id="gift__template" value="生成模板"/>
            <div class="gift__option">
                <label><a id="reply__show_gid" style="color:blue;" href="javascript:void(0);">礼物id：</a><input id="gift__giftId" type="text"/></label>
                <label>回复：<input id="gift__reply" type="text" placeholder="<id>=用户名 <cnt>个数"/></label>
            </div>
        </div>
    `,l=document.getElementsByClassName("livetool")[0];if(l.insertBefore(i,l.childNodes[0]),document.getElementById("reply__show_gid").addEventListener("click",()=>{console.log(`
背包礼物：http://webconf.douyucdn.cn/resource/common/prop_gift_list/prop_gift_config.json
鱼翅礼物：http://open.douyucdn.cn/api/RoomApi/room/4042402
`),S("请按F12到控制台(console)查看礼物id","success")}),document.getElementById("gift__switch").addEventListener("click",()=>{var o=document.getElementById("gift__switch").checked;lo=1==o;{let e=[],t=localStorage.getItem("ExSave_isGift");var n=(e=null!=t&&"rooms"in(n=JSON.parse(t))==1?n.rooms:e).indexOf(B),o=(1==lo?-1==n&&e.push(B):e.splice(n,1),{rooms:e});localStorage.setItem("ExSave_isGift",JSON.stringify(o))}}),document.getElementById("gift__title").addEventListener("click",()=>{var e=document.getElementsByClassName("gift__panel")[0];"block"!=e.style.display?((e.style.display="block")==document.getElementsByClassName("mute__panel")[0].style.display&&(document.getElementsByClassName("mute__panel")[0].style.display="none"),"block"==document.getElementsByClassName("enter__panel")[0].style.display&&(document.getElementsByClassName("enter__panel")[0].style.display="none"),"block"==document.getElementsByClassName("reply__panel")[0].style.display&&(document.getElementsByClassName("reply__panel")[0].style.display="none"),"block"==document.getElementsByClassName("vote__panel")[0].style.display&&(document.getElementsByClassName("vote__panel")[0].style.display="none")):e.style.display="none"}),document.getElementById("gift__select").onclick=function(){var e,t;0!=this.options.length&&(e=this.options[this.selectedIndex].text,t=N[e].reply,document.getElementById("gift__giftId").value=e,document.getElementById("gift__reply").value=t)},document.getElementById("gift__add").addEventListener("click",()=>{var e=document.getElementById("gift__select"),t=document.getElementById("gift__giftId").value,o=document.getElementById("gift__reply").value;""!=t&&(N[t]={reply:o},e.options.add(new Option(t,"")),so())}),document.getElementById("gift__del").addEventListener("click",()=>{var e=document.getElementById("gift__select"),t=e.options[e.selectedIndex].text;delete N[t],e.options.remove(e.selectedIndex),so()}),document.getElementById("gift__export").addEventListener("click",()=>{GM_setClipboard(JSON.stringify(N)),S("【自动谢礼物】导出完毕，已复制到剪贴板","success")}),document.getElementById("gift__import").addEventListener("click",()=>{dl.prompt({title:"请输入json文本（会覆盖原来的设置）",okBtn:"确定",onConfirm:function(e){var t=document.getElementById("gift__select"),e=JSON.parse(e||"{}")||{};if("object"==typeof e){for(var o in N={...e},t.options.length=0,N)N.hasOwnProperty(o)&&t.options.add(new Option(o,""));so()}S("【自动谢礼物】导入完毕","success")},onCancel:function(e){}})}),document.getElementById("gift__template").addEventListener("click",()=>{(async()=>{var e,t={},o=await new Promise(t=>{GM_xmlhttpRequest({method:"GET",url:"http://open.douyucdn.cn/api/RoomApi/room/"+B,responseType:"json",onload:function(e){e=e.response;t(e)}})});for(let e=0;e<o.data.gift.length;e++){var n=o.data.gift[e];t[n.id]={reply:`感谢<id>赠送的${n.name}x<cnt>`}}let i=await new Promise(t=>{GM_xmlhttpRequest({method:"GET",url:"http://webconf.douyucdn.cn/resource/common/prop_gift_list/prop_gift_config.json",responseType:"text",onload:function(e){e=e.response;t(e)}})}),a={};for(e in i=(i=i.substring(0,i.length-2)).replace("DYConfigCallback(",""),(i=JSON.parse(i||"{}")||{}).data)a[e]={reply:`感谢<id>赠送的${i.data[e].name}x<cnt>`};var r={"开通钻粉":{reply:"感谢<id>开通钻粉"},"续费钻粉":{reply:"感谢<id>续费钻粉"}};r={...t,...a,...r},GM_setClipboard(JSON.stringify(r)),S("【自动谢礼物】礼物模板生成完毕，已复制到剪贴板，可直接导入","success")})()}),null!=(i=localStorage.getItem("ExSave_Gift"))){var m,u=JSON.parse(i),g=(N=u,document.getElementById("gift__select"));for(m in u)u.hasOwnProperty(m)&&g.options.add(new Option(m,""))}if(null!=(i=localStorage.getItem("ExSave_isGift"))){i=JSON.parse(i);let e=[];"rooms"in i==1&&(e=i.rooms),lo=-1!=e.indexOf(B)}else lo=!1;document.getElementById("gift__switch").checked=lo;l=document.createElement("div"),l.className="livetool__cell",l.innerHTML=`
        <div class='livetool__cell_title'>
            <span id='reply__title'>关键词回复</span>
            <span id='reply__export'>导出</span>
            <span id='reply__import'>导入</span>
        </div>
        <div class='livetool__cell_option'>
            <div class="onoffswitch livetool__cell_switch">
                <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="reply__switch" tabindex="0" checked>
                <label class="onoffswitch-label" for="reply__switch"></label>
            </div>
        </div>
    `+`
        <div class='reply__panel'>
            <select id='reply__select'>
            </select>
            <input style="width:40px;margin-left:10px;" type="button" id="reply__add" value="添加"/>
            <input style="width:40px;margin-left:10px;" type="button" id="reply__del" value="删除"/>
            <label style="margin-left:5px">CD：<input id="reply__time" type="text" placeholder="秒" /></label>
            <div class="reply__option">
                <label>词：<input id="reply__word" type="text" placeholder="re(式)=结果"/></label>
                <label>回复：<input id="reply__reply" type="text" placeholder="<id>用户名 <txt>弹幕"/></label>
            </div>
        </div>
    `,i=document.getElementsByClassName("livetool")[0],i.insertBefore(l,i.childNodes[0]),document.getElementById("reply__export").addEventListener("click",()=>{GM_setClipboard(JSON.stringify(Bo)),S("【关键词回复】导出完毕，已复制到剪贴板","success")}),document.getElementById("reply__import").addEventListener("click",()=>{dl.prompt({title:"请输入json文本（会覆盖原来的设置）",okBtn:"确定",onConfirm:function(e){var t=document.getElementById("reply__select"),e=JSON.parse(e||"{}")||{};if("object"==typeof e){for(var o in Bo={...e},t.options.length=0,Bo)Bo.hasOwnProperty(o)&&t.options.add(new Option(o,""));Co()}S("【关键词回复】导入完毕","success")},onCancel:function(e){}})}),document.getElementById("reply__switch").addEventListener("click",()=>{So=String(document.getElementById("reply__time").value)||0;var o=document.getElementById("reply__switch").checked;Eo=1==o;{let e=[],t=localStorage.getItem("ExSave_isReply");var n=(e=null!=t&&"rooms"in(n=JSON.parse(t))==1?n.rooms:e).indexOf(B),o=(1==Eo?-1==n&&e.push(B):e.splice(n,1),{rooms:e});localStorage.setItem("ExSave_isReply",JSON.stringify(o))}o=document.getElementById("reply__time").value,localStorage.setItem("ExSave_ReplyCd",o)}),document.getElementById("reply__title").addEventListener("click",()=>{var e=document.getElementsByClassName("reply__panel")[0];"block"!=e.style.display?((e.style.display="block")==document.getElementsByClassName("mute__panel")[0].style.display&&(document.getElementsByClassName("mute__panel")[0].style.display="none"),"block"==document.getElementsByClassName("enter__panel")[0].style.display&&(document.getElementsByClassName("enter__panel")[0].style.display="none"),"block"==document.getElementsByClassName("gift__panel")[0].style.display&&(document.getElementsByClassName("gift__panel")[0].style.display="none"),"block"==document.getElementsByClassName("vote__panel")[0].style.display&&(document.getElementsByClassName("vote__panel")[0].style.display="none")):e.style.display="none"}),document.getElementById("reply__select").onclick=function(){var e,t;0!=this.options.length&&(e=this.options[this.selectedIndex].text,t=Bo[e].reply,document.getElementById("reply__word").value=e,document.getElementById("reply__reply").value=t)},document.getElementById("reply__add").addEventListener("click",()=>{var e=document.getElementById("reply__select"),t=document.getElementById("reply__word").value,o=document.getElementById("reply__reply").value;""!=t&&(Bo[t]={reply:o},e.options.add(new Option(t,"")),Co())}),document.getElementById("reply__del").addEventListener("click",()=>{var e=document.getElementById("reply__select"),t=e.options[e.selectedIndex].text;delete Bo[t],e.options.remove(e.selectedIndex),Co()}),l=localStorage.getItem("ExSave_Reply");if(null!=l){var h,f=JSON.parse(l),y=(Bo=f,document.getElementById("reply__select"));for(h in f)f.hasOwnProperty(h)&&y.options.add(new Option(h,""))}if(null!=(l=localStorage.getItem("ExSave_isReply"))){i=JSON.parse(l);let e=[];"rooms"in i==1&&(e=i.rooms),Eo=-1!=e.indexOf(B)}else Eo=!1;document.getElementById("reply__switch").checked=Eo,null!=(l=localStorage.getItem("ExSave_ReplyCd"))&&(document.getElementById("reply__time").value=l);i=document.createElement("div"),i.className="livetool__cell",i.innerHTML=`
        <div class='livetool__cell_title'>
            <span id='redpacket__title'>自动抢红包(白胖直播间专属)</span>
        </div>
        <div class='livetool__cell_option'>
            <div class="onoffswitch livetool__cell_switch">
                <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="redpacket__switch" tabindex="0">
                <label class="onoffswitch-label" for="redpacket__switch"></label>
            </div>
        </div>
    `+`
        <div class='redpacket__panel' style='display:none;'>
            <label>回复延迟：<input id="redpacket__delay" type="text" placeholder="秒" /></label>
            <label>冷却时间：<input id="redpacket__cd" type="text" placeholder="秒" /></label>
        </div>
    `,l=document.getElementsByClassName("livetool")[0];l.insertBefore(i,l.childNodes[0]),document.getElementById("redpacket__switch").addEventListener("click",()=>{bo=document.getElementById("redpacket__switch").checked;{let e=[],t=localStorage.getItem("ExSave_isRedPacket");var o=(e=t&&"rooms"in(o=JSON.parse(t))?o.rooms:e).indexOf(B),n=(bo?-1===o&&e.push(B):-1!==o&&e.splice(o,1),{rooms:e});localStorage.setItem("ExSave_isRedPacket",JSON.stringify(n))}}),document.getElementById("redpacket__title").addEventListener("click",()=>{var e=document.getElementsByClassName("redpacket__panel")[0];e.style.display="block"===e.style.display?"none":"block"}),document.getElementById("redpacket__delay").addEventListener("change",()=>{vo=Number(document.getElementById("redpacket__delay").value)||0,ko()}),document.getElementById("redpacket__cd").addEventListener("change",()=>{wo=Number(document.getElementById("redpacket__cd").value)||0,ko()});i=localStorage.getItem("ExSave_isRedPacket"),i?(l=JSON.parse(i).rooms||[],bo=l.includes(B),document.getElementById("redpacket__switch").checked=bo):(bo=!1,document.getElementById("redpacket__switch").checked=!1),(i=localStorage.getItem("ExSave_RedPacketDelay"))?(vo=Number(i),document.getElementById("redpacket__delay").value=i):vo=0,(i=localStorage.getItem("ExSave_RedPacketCd"))?(wo=Number(i),document.getElementById("redpacket__cd").value=i):wo=0,to(),l=document.createElement("div"),l.className="livetool__Treasure",l.id="Ex_Geetest",i=document.getElementsByClassName("Barrage-main")[0];i.insertBefore(l,i.childNodes[0]),setInterval(()=>{var e=Number(Xt/5*60).toFixed(0),t=(Xt=0,document.getElementsByClassName("ChatSend-txt")[0]),e=`弹幕时速：${e}条/分`;t.placeholder=e+" 按↑↓查看历史弹幕 视频ctrl+滚轮缩放",t.setAttribute("data-placeholder",e)},5e3),new G(".layout-Player-rankAll",!1,e=>{0<document.getElementsByClassName("RankAllMain-container").length&&0<Object.keys(ho.all).length&&fo("all",document.querySelectorAll(".layout-Player-rankAll .ChatRankWeek-listItem--nickname"))}),(async()=>{q=await K();let e=setInterval(()=>{void 0!==document.getElementById("js-barrage-list")&&(clearInterval(e),new G("#js-barrage-list",!1,e=>{if(!(e.length<=0||e[0].addedNodes.length<=0)){let n=e[0].addedNodes[0];if(0<n.getElementsByClassName("is-self").length){e=n.getElementsByClassName("Barrage-content");if(e&&0!==e.length){let o=e[0].innerText.trim();clearTimeout(Zt),Zt=setTimeout(()=>{var e,t;""!==Jt&&""!==o&&(e=yl(Jt)).txt&&(e.txt.includes("[DouyuEx图片")&&(e.txt=e.txt.replace(/\[DouyuEx图片[^\]]+\]/g,"").trim()),e.txt.replace(/\s+/g," ")!==o.replace(/\s+/g," "))&&((e=n.getElementsByClassName("Barrage-content")[0]).style.textDecoration="line-through gray 1px",e)&&e.parentNode&&e.parentNode.insertBefore(((t=document.createElement("span")).textContent="(可能发送失败)",t.style.marginLeft="4px",t.style.color="gray",t.style.fontSize="9px",t.style.cursor="point",t.title="该条弹幕发送失败，不会被其他人看到（可能会误判）",t),e.nextSibling)},300)}}}}))},1e3)})(),document.getElementsByClassName("livetool-icon")[0].addEventListener("click",function(){ee("直播间工具")}),new El(B,e=>{if("rss"==M(i=e)){let e=v(i,"rid@=","/");var t=v(i,"ss@=","/"),i=v(i,"ivl@=","/");"1"==t&&"0"==i&&X("开播提醒","直播间："+e+"开播了，点我签到",()=>{ui(e)})}(async t=>{if(0!=co&&"chatmsg"==M(t)){var o=v(t,"uid@=","/");if(o!=I){var n,i=v(t,"nn@=","/"),a=v(t,"txt@=","/");let e=!1;for(n in L)if(""!=n)if(-1!=n.indexOf("re(")?(s=v(n,"re(",")="),1<(d=n.split("=")).length&&(d=d[1],0<(s=new RegExp(s,"g").exec(a)).length)&&(e=s[0]==d)):e=-1!=String(a).indexOf(n),1==e){var r,l,s=L[n].count,d=L[n].time;po.hasOwnProperty(i)?(r=Number(po[i].count)+1,s<=r?(await go(B,i,d),X("禁言信息","【"+i+"】已被禁言"+d+"分钟\n弹幕："+a,()=>{}),l={id:i,uid:o,barrage:a,time:d,count:1,ts:String(_("yyyy年MM月dd日hh时mm分ss秒 ",new Date))},mo.push(l),po[i].count=0):po[i].count=String(r)):s<=1?(await go(B,i,d),X("禁言信息","【"+i+"】已被禁言"+d+"分钟\n弹幕："+a,()=>{}),l={id:i,uid:o,barrage:a,time:d,count:1,ts:String(_("yyyy年MM月dd日hh时mm分ss秒 ",new Date))},mo.push(l)):po[i]={uid:o,count:1};break}}}})(e);t=e;if(0!=Eo&&"chatmsg"==M(t)){i=v(t,"uid@=","/");if(i!=I){var o,n,a=v(t,"nn@=","/"),r=v(t,"txt@=","/");let e=!1;for(o in Bo)if(""!=o)if(-1!=o.indexOf("re(")?(l=v(o,"re(",")="),1<(n=o.split("=")).length&&(n=n[1],0<(l=new RegExp(l,"g").exec(r)).length)&&(e=l[0]==n)):e=-1!=String(r).indexOf(o),1==e){var l=Bo[o].reply;l=String(l).replace(/<id>/g,a),l=String(l).replace(/<txt>/g,r),0==Io&&(E(l),0<So)&&(Io=!0,setTimeout(()=>{Io=!1},1e3*So));break}}}var s,d,c,p,i=e;if(bo&&!xo&&!_o&&"chatmsg"===M(i)){var m=v(i,"uid@=","/");if(m!==I){m=v(i,"txt@=","/");if(m.startsWith("#红包")){i=m.trim().split(/\s+/);let e="#抢 "+(1<i.length?i[1]:"老板大气");0<vo?(_o=!0,setTimeout(()=>{E(e),_o=!1,0<wo&&(xo=!0,setTimeout(()=>{xo=!1},1e3*wo))},1e3*vo)):(E(e),0<wo&&(xo=!0,setTimeout(()=>{xo=!1},1e3*wo)))}}}m=e,0!=lo&&("dgb"===(i=M(m))?v(m,"uid@=","/")!=I&&(s=v(m,"nn@=","/"),c=v(m,"gfid@=","/"),d=v(m,"gfcnt@=","/"),c in N)&&(c=N[c].reply,c=String(c).replace(/<id>/g,s),E(c=String(c).replace(/<cnt>/g,d))):"dfobc"!==i&&"dfrbc"!==i||v(m,"uid@=","/")!=I&&(s=v(m,"nick@=","/"),(d="dfobc"===i?"开通钻粉":"续费钻粉")in N)&&(c=N[d].reply,c=String(c).replace(/<id>/g,s),E(c=String(c).replace(/<cnt>/g,"1"))));var i=e;if(0!=Vt&&"tsboxb"==M(i)){var u=v(i,"ot@=","/");let e=v(i,"rpid@=","/"),t=v(i,"rid@=","/"),o=Q("dy_did");i=1e3*(Number(u)-Math.floor(Date.now()/1e3))+qt(),To++;u=document.createElement("div");let n="Ex_Geetest_no"+String(To);u.id=n,document.getElementById("Ex_Geetest").appendChild(u),setTimeout(()=>{No(t,e,o,n)},i)}u=e;if(0!=io&&"uenter"==M(u)){var i=v(u,"uid@=","/");if(i!=I){var g,h=v(u,"nn@=","/"),f=v(u,"level@=","/");for(g of T)if(Number(f)>=Number(g.level)){E(reply=String(g.word).replace(/<id>/g,h));break}}}i=e,0!=Mo&&"chatmsg"==M(i)&&(p=v(i,"uid@=","/"),i=v(i,"txt@=","/"),zo?Object(Do).hasOwnProperty(i)&&(Do[i].num++,jo++,Ro()):0==Object(Ao).hasOwnProperty(p)&&Object(Do).hasOwnProperty(i)&&(Ao[p]=0,Do[i].num++,jo++,Ro())),"chatmsg"==M(e)&&Xt++,"ranklist"==M(p=e)&&((p=yl(p)).list_day&&(ho.day=yo(p.list_day),fo("day",document.querySelectorAll(".layout-Player-rank .ChatDayRank .ChatRankWeek-listItem--nickname"))),p.list&&(ho.week=yo(p.list),fo("week",document.querySelectorAll(".layout-Player-rank .ChatRankWeek .ChatRankWeek-listItem--nickname"))),p.list_all&&(ho.all=yo(p.list_all)),fo()),"chatmsg"==M(i=e)&&i.includes(q)&&(Jt=i),"oni"==M(i=e)&&(i=v(i,"vn@=","/"))&&(D.noble_count=i,e=document.getElementById("real-audience__noble"))&&(e.innerText=_n(i))});{let s=setInterval(()=>{if(k([".right-e7ea5d",".right-17e251"])){clearInterval(s),H=document.querySelector(".layout-Player-videoEntity video"),document.getElementsByClassName("disable-23f484")[0].innerHTML="DouyuEx_"+wi;var e=document.createElement("div"),t=(e.id="ex-vtoolbar-menu",e.className="vtoolbar-menu",e.innerHTML=`
        <button type="button" class="vtoolbar-menu__trigger" title="DouyuEx Ver${wi}" aria-expanded="false" aria-haspopup="true">
            ${zr}
        </button>
        <div class="vtoolbar-menu__dropdown" role="menu" aria-label="DouyuEx Ver${wi}">
            <button type="button" class="vtoolbar-menu__item" id="vtoolbar-menu-joysound" role="menuitem">
                <span class="vtoolbar-menu__item-icon" id="vtoolbar-joysound-icon"></span>
                <span class="vtoolbar-menu__item-label">Joysound 音效</span>
                <span class="vtoolbar-menu__switch" id="vtoolbar-joysound-switch" aria-hidden="true">
                    <span class="vtoolbar-menu__switch-thumb"></span>
                </span>
            </button>
            <button type="button" class="vtoolbar-menu__item vtoolbar-menu__item--filter" id="vtoolbar-menu-filter" role="menuitem" aria-expanded="false">
                <span class="vtoolbar-menu__item-icon">${Or}</span>
                <span class="vtoolbar-menu__item-label">画面滤镜</span>
                ${Rr}
            </button>
            <button type="button" class="vtoolbar-menu__item" id="vtoolbar-menu-copy-live" role="menuitem">
                <span class="vtoolbar-menu__item-icon">${Fr}</span>
                <span class="vtoolbar-menu__item-label">复制直播流地址</span>
            </button>
            <button type="button" class="vtoolbar-menu__item" id="vtoolbar-menu-audio-line" role="menuitem">
                <span class="vtoolbar-menu__item-icon vtoolbar-menu__item-icon--compact">${Hr}</span>
                <span class="vtoolbar-menu__item-label">切换音频线路</span>
            </button>
            <button type="button" class="vtoolbar-menu__item" id="vtoolbar-menu-enhanced-pip" role="menuitem">
                <span class="vtoolbar-menu__item-icon">${Gr}</span>
                <span class="vtoolbar-menu__item-label">加强版画中画</span>
            </button>
            <div class="vtoolbar-menu__divider" role="separator"></div>
            <button type="button" class="vtoolbar-menu__item" id="vtoolbar-menu-expanel" role="menuitem">
                <span class="vtoolbar-menu__item-icon">${zr}</span>
                <span class="vtoolbar-menu__item-label">DouyuEx 工具条</span>
            </button>
        </div>
        <div class="vtoolbar-menu__filter-host" id="ex-vtoolbar-filter-host"></div>
    `,k([".right-e7ea5d",".right-17e251"])),t=(t&&t.insertBefore(e,t.childNodes[0]),(e=Sr()).querySelector(".vtoolbar-menu__trigger")),e=e.querySelector(".vtoolbar-menu__dropdown"),o=document.getElementById("ex-vtoolbar-filter-host"),n=document.getElementById("vtoolbar-menu-filter"),i=document.getElementById("vtoolbar-menu-copy-live"),a=document.getElementById("vtoolbar-menu-audio-line"),r=document.getElementById("vtoolbar-menu-enhanced-pip"),l=document.getElementById("vtoolbar-menu-expanel"),t=(Mr(t,!0),Mr(e,!1),Mr(o,!1),n.addEventListener("click",e=>{e.stopPropagation(),(Br?jr:()=>{var e=document.getElementById("ex-vtoolbar-filter-host"),t=document.getElementById("vtoolbar-menu-filter");e&&(Br=!0,e.classList.add("is-visible"),t&&(t.classList.add("is-active"),t.setAttribute("aria-expanded","true")),vr())})()}),i.addEventListener("click",e=>{e.stopPropagation(),Ge()}),a.addEventListener("click",e=>{e.stopPropagation(),se()}),r.addEventListener("click",e=>{e.stopPropagation(),Dr(),Ua()}),l.addEventListener("click",e=>{e.stopPropagation(),gt()}),document.addEventListener("keydown",Lr),Zi(),document.getElementById("vtoolbar-menu-joysound")),e=(t&&t.addEventListener("click",e=>{e.stopPropagation(),unsafeWindow.hasInstalledJoysound?(1==localStorage.getItem("Ex_isJoysound")?unsafeWindow.disableJoysound():unsafeWindow.enableJoysound(),Zi()):w("https://src.douyuex.com/src/joysound.user.js")}),document.createElement("li")),o=(e.id="ex-videospeed",e.innerHTML=`
    倍速播放
    <ul class="videospeed__wrap">
        <li id="videospeed__2.0">2.0x</li>
        <li id="videospeed__1.5">1.5x</li>
        <li id="videospeed__1.25">1.25x</li>
        <li id="videospeed__1.0">1.0x</li>
        <li id="videospeed__0.75">0.75x</li>
        <li id="videospeed__0.5">0.5x</li>
    </ul>
    `,document.getElementsByClassName("menu-da2a9e")[0]),n=(o.insertBefore(e,o.childNodes[1]),document.getElementById("videospeed__2.0").addEventListener("click",()=>{H.playbackRate=2}),document.getElementById("videospeed__1.5").addEventListener("click",()=>{H.playbackRate=1.5}),document.getElementById("videospeed__1.25").addEventListener("click",()=>{H.playbackRate=1.25}),document.getElementById("videospeed__1.0").addEventListener("click",()=>{H.playbackRate=1}),document.getElementById("videospeed__0.75").addEventListener("click",()=>{H.playbackRate=.75}),document.getElementById("videospeed__0.5").addEventListener("click",()=>{H.playbackRate=.5}),document.createElement("li")),i=(n.id="ex-cinema",n.innerHTML=`
    影院比例
    <ul class="cinema__wrap">
        <li id="cinema__default">默认</li>
        <li id="cinema__cover">剪裁</li>
        <li id="cinema__fill">拉伸</li>
    </ul>
    `,document.getElementsByClassName("menu-da2a9e")[0]);i.insertBefore(n,i.childNodes[1]),document.getElementById("cinema__default").addEventListener("click",()=>{V("Ex_Style_Cinema")}),document.getElementById("cinema__cover").addEventListener("click",()=>{Yi("cover")}),document.getElementById("cinema__fill").addEventListener("click",()=>{Yi("fill")});{let e=document.createElement("div"),t=(e.id="ex-videosync",e.title="同步时间",e.innerHTML=`
    <svg t="1595680402158" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7532" width="22" height="22"><path d="M938.1888 534.016h-80.7936c0.4096-7.3728 0.6144-14.6432 0.6144-22.016 0-218.624-176.8448-400.7936-389.12-400.7936C257.024 111.2064 80.6912 293.1712 80.6912 512c0 218.7264 176.4352 400.7936 388.1984 400.7936 74.752 0 149.0944-22.016 208.1792-60.0064l42.7008 68.608c-75.0592 48.9472-161.9968 74.8544-250.7776 74.752C209.8176 996.1472 0 779.264 0 512S209.8176 27.8528 468.8896 27.8528C728.3712 27.8528 938.7008 244.736 938.7008 512c0 7.3728-0.2048 14.6432-0.512 22.016z m-261.12 318.7712z m-26.4192-158.1056L426.7008 556.032V291.9424h64v226.5088L689.5616 635.904l-38.912 58.7776z m245.3504-6.656L768 512h256L896 688.0256z" fill="#ffffff" p-id="7533"></path></svg>
    `,document.getElementsByClassName("left-d3671e")[0]);t?(e.style.marginLeft="20px",t.insertBefore(e,t.childNodes[3])):(e.style.marginLeft="8px",(t=k([".left-bfab3b"])).insertBefore(e,t.childNodes[2]))}document.getElementById("ex-videosync").addEventListener("click",()=>{var e;0!=(e=H.buffered).length&&(H.currentTime=e.end(0))});{let e=document.createElement("div"),t=(e.id="ex-framechase-container",e.style.cssText=`
        display: flex;
        align-items: center;
        gap: 4px;
    `,document.createElement("input")),o=(t.type="number",t.step="0.1",t.min="0.1",t.value="1",t.style.cssText=`
        width: 50px;
        height: 24px;
        padding: 2px 6px;
        border: none;
        border-radius: 3px;
        background: rgba(255, 255, 255, 0.1);
        color: #fff;
        font-size: 12px;
        outline: none;
    `,t.addEventListener("change",()=>{var e=parseFloat(t.value);dr=isNaN(e)||e<=0?1:e,t.value=dr.toFixed(1)}),document.createElement("div")),n=(o.className="xg-icon",o.innerHTML=`
        <div class="xgplayer-icon" style="
            cursor: pointer;
            color: #fff;
            padding: 4px 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 3px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 24px;
            transition: all 0.2s;
        ">
            追
        </div>
    `,document.createElement("div")),i=(n.className="status-indicator",n.style.cssText=`
        color: #fff;
        margin-right: 8px;
        font-size: 12px;
        min-width: 40px;
        text-align: center;
    `,e.appendChild(t),e.appendChild(o),e.appendChild(n),document.getElementsByClassName("left-d3671e")[0]||document.getElementsByClassName("left-bfab3b")[0]);i&&i.childNodes[4]?i.insertBefore(e,i.childNodes[4]):i.appendChild(e)}a=document.querySelector("#ex-framechase-container .xg-icon");a&&a.addEventListener("click",cr),kr&&document.removeEventListener("keydown",kr,!0),kr=e=>{Vr||e.target&&(e.target.isContentEditable||/^(input|textarea)$/i.test(e.target.tagName))||37!=e.keyCode&&39!=e.keyCode&&"ArrowLeft"!==e.key&&"ArrowRight"!==e.key||(H=H||document.querySelector(".layout-Player-videoEntity video"))&&(e.preventDefault(),H.currentTime=Math.max(0,(H.currentTime||0)+(37==e.keyCode||"ArrowLeft"===e.key?-3:3)))},document.addEventListener("keydown",kr,!0),O=H.parentNode.className;r=Pr();if(r&&((l=document.createElement("div")).innerHTML=`
    <div class="filter__wrap">
        <div class="filter__panel">
            ${br()?`<div class="filter__enhance">
                <span class="filter__title">画质增强（不掉帧）</span>
                <div class="filter__switch" id="switch__enhance">
                    <div class="filter__switch-slider" id="slider__enhance"></div>
                </div>
            </div>`:""}
            <div class="filter__bright">
                <span class="filter__title">明亮度</span>
                <div class="filter__scroll" id="scroll__bright">
                    <div class="filter__scroll-bar" id="bar__bright"></div>
                    <div class="filter__scroll-mask" id="mask__bright"></div>
                </div>
            </div>
            <div class="filter__contrast">
                <span class="filter__title">对比度</span>
                <div class="filter__scroll" id="scroll__contrast">
                    <div class="filter__scroll-bar" id="bar__contrast"></div>
                    <div class="filter__scroll-mask" id="mask__contrast"></div>
                </div>
            </div>
            <div class="filter__saturate">
                <span class="filter__title">饱和度</span>
                <div class="filter__scroll" id="scroll__saturate">
                    <div class="filter__scroll-bar" id="bar__saturate"></div>
                    <div class="filter__scroll-mask" id="mask__saturate"></div>
                </div>
            </div>
            <div class="filter__filter">
                <p style="color:white;float:left;line-height:20px">滤镜</p>
                <select class="c3-4f78e3" id="filter__select">
                    <option class="option-b5745c" value="default">无</option>
                    <option class="option-b5745c" value="1977">1977</option>
                    <option class="option-b5745c" value="Aden">Aden</option>
                    <option class="option-b5745c" value="Amaro">Amaro</option>
                    <option class="option-b5745c" value="Brannan">Brannan</option>
                    <option class="option-b5745c" value="Brooklyn">Brooklyn</option>
                    <option class="option-b5745c" value="Claredon">Claredon</option>
                    <option class="option-b5745c" value="Earlybird">Earlybird</option>
                    <option class="option-b5745c" value="Gingham">Gingham</option>
                    <option class="option-b5745c" value="Hudson">Hudson</option>
                    <option class="option-b5745c" value="Inkwell">Inkwell</option>
                    <option class="option-b5745c" value="Lofi">Lofi</option>
                    <option class="option-b5745c" value="Maven">Maven</option>
                    <option class="option-b5745c" value="Perpetua">Perpetua</option>
                    <option class="option-b5745c" value="Reyes">Reyes</option>
                    <option class="option-b5745c" value="Stinson">Stinson</option>
                    <option class="option-b5745c" value="Toaster">Toaster</option>
                    <option class="option-b5745c" value="Walden">Walden</option>
                    <option class="option-b5745c" value="Valencia">Valencia</option>
                    <option class="option-b5745c" value="Xpro2">Xpro2</option>
                </select>
            </div>
            <ul style="clear:both">
                <li id="filter__reset2">重置</li>
            </ul>
        </div>
    </div>
    `,r.appendChild(l.firstElementChild),r=document.getElementsByClassName("menu-da2a9e")[0])&&((l=document.createElement("li")).id="filter__panorama",l.innerText="全景",r.insertBefore(l,r.childNodes[1]),(l=document.createElement("li")).id="filter__mirror",l.innerText="镜像画面",r.insertBefore(l,r.childNodes[1]),(l=document.createElement("li")).id="filter__rotate",l.innerText="旋转画面",r.insertBefore(l,r.childNodes[1]),(l=document.createElement("li")).id="filter__reset",l.innerText="重置",r.insertBefore(l,r.childNodes[1]),(l=document.createElement("div")).className="divider-f9d33d",r.insertBefore(l,r.childNodes[1])),br()){let e=document.createElement("div"),t=(e.className="enhance-modal__panel-wrap",e.innerHTML=`
        <div class="enhance-modal__panel">
            <div class="enhance-modal__close">×</div>
            <div class="enhance-modal__content">
                <img class="enhance-modal__img" src="https://c-yuba.douyucdn.cn/yubavod/b/zEqAvQaXrd5L/c16fdac3db1903db3a39a6557c2b5ab5.gif" alt=""/>
                <div class="enhance-modal__text">
                    开启后，弹幕飘屏会被遮挡，请将鼠标移入到直播画面中并点击<img style="width:32px;" src="https://c-yuba.douyucdn.cn/yubavod/b/zEqAvQaXrd5L/2dd9e0d70e39a532a2675717eb054129.png" alt="">
                    <br />
                    完成后，再<b>刷新</b>以恢复弹幕飘屏，该功能会<b>自动保存</b>
                    <br />
                    <a style="color: #ff7700;" href="https://www.microsoft.com/zh-cn/edge/features/enhance-video?form=MT0160" target="_blank">没有增强图标？</a>
                </div>
            </div>
        </div>
    `,document.querySelector("body"));t.insertBefore(e,t.childNodes[0]),e.getElementsByClassName("enhance-modal__close")[0].addEventListener("click",()=>{e.style.display="none"})}document.onmouseup=function(){document.onmousemove=null},br()&&(t=document.getElementById("switch__enhance"))&&t.addEventListener("click",()=>{fr=!fr;var e=document.getElementById("switch__enhance"),t=document.getElementById("slider__enhance"),o=document.getElementsByClassName("enhance-modal__panel-wrap")[0],n=document.querySelector("video");fr?(t.style.left="20px",e.style.background="#369",H.style.imageRendering="crisp-edges",H.style.imageRendering="-webkit-optimize-contrast",H.style.imageRendering="optimize-contrast",o.style.display="flex",n.style.zIndex="10",n.style.cursor="auto"):(t.style.left="0px",e.style.background="#ccc",H.style.imageRendering="",o.style.display="none",n.style.zIndex="0")}),_r(document.getElementById("scroll__bright"),document.getElementById("bar__bright"),document.getElementById("mask__bright"),e=>{pr=`brightness(${e}%)`,H.style.filter=`${pr} ${mr} `+ur}),_r(document.getElementById("scroll__contrast"),document.getElementById("bar__contrast"),document.getElementById("mask__contrast"),e=>{mr=`contrast(${e}%)`,H.style.filter=`${pr} ${mr} `+ur}),_r(document.getElementById("scroll__saturate"),document.getElementById("bar__saturate"),document.getElementById("mask__saturate"),e=>{ur=`saturate(${e}%)`,H.style.filter=`${pr} ${mr} `+ur}),document.getElementById("filter__reset").addEventListener("click",()=>{wr()}),document.getElementById("filter__reset2").addEventListener("click",()=>{wr()}),document.getElementById("filter__mirror").addEventListener("click",()=>{gr?(gr=!1,R.rotateY="rotateY(0deg)"):(gr=!0,R.rotateY="rotateY(180deg)"),H.parentNode.style.transition="all .5s",H.parentNode.style.transform=R.rotateY+" "+R.rotate+" "+R.scale}),document.getElementById("filter__rotate").addEventListener("click",()=>{hr+=90,R.rotate=`rotate(${String(hr)}deg)`,H.parentNode.style.transition="all .5s",hr/90%2!=0?window.innerWidth>window.innerHeight?R.scale="scale("+String(H.videoHeight/H.videoWidth)+")":R.scale="scale("+String(H.videoWidth/H.videoHeight)+")":R.scale="",H.parentNode.style.transform=R.rotateY+" "+R.rotate+" "+R.scale}),document.getElementById("filter__select").onchange=function(){switch(this.options[this.selectedIndex].text){case"default":V("Ex_Style_Filter");break;case"1977":F(`.${O}{position:relative;-webkit-filter:contrast(110%)brightness(110%)saturate(130%);filter:contrast(110%)brightness(110%)saturate(130%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:screen;background:rgba(243,106,188,0.3);z-index:10}`);break;case"Aden":F(`.${O}{position:relative;-webkit-filter:contrast(90%)brightness(120%)saturate(85%)hue-rotate(20deg);filter:contrast(90%)brightness(120%)saturate(85%)hue-rotate(20deg)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:darken;background:-webkit-linear-gradient(to right,rgba(66,10,14,0.2)1,rgba(66,10,14,0));background:linear-gradient(to right,rgba(66,10,14,0.2)1,rgba(66,10,14,0));z-index:10}`);break;case"Amaro":F(`.${O}{position:relative;-webkit-filter:contrast(90%)brightness(110%)saturate(150%)hue-rotate(-10deg);filter:contrast(90%)brightness(110%)saturate(150%)hue-rotate(-10deg)}`);break;case"Brannan":F(`.${O}{position:relative;-webkit-filter:contrast(140%)sepia(50%);filter:contrast(140%)sepia(50%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:lighten;background:rgba(161,44,199,0.31);z-index:10}`);break;case"Brooklyn":F(`.${O}{position:relative;-webkit-filter:contrast(90%)brightness(110%);filter:contrast(90%)brightness(110%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:overlay;background:-webkit-radial-gradient(50%50%,circle closest-corner,rgba(168,223,193,0.4)1,rgba(183,196,200,0.2));background:radial-gradient(50%50%,circle closest-corner,rgba(168,223,193,0.4)1,rgba(183,196,200,0.2));z-index:10}`);break;case"Claredon":F(`.${O}{position:relative;-webkit-filter:contrast(120%)saturate(125%);filter:contrast(120%)saturate(125%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:overlay;background:rgba(127,187,227,0.2);z-index:10}`);break;case"Earlybird":F(`.${O}{position:relative;-webkit-filter:contrast(90%)sepia(20%);filter:contrast(90%)sepia(20%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:overlay;background:-webkit-radial-gradient(50%50%,circle closest-corner,rgba(208,186,142,1)20,rgba(29,2,16,0.2));background:radial-gradient(50%50%,circle closest-corner,rgba(208,186,142,1)20,rgba(29,2,16,0.2));z-index:10}`);break;case"Gingham":F(`.${O}{position:relative;-webkit-filter:brightness(105%)hue-rotate(350deg);filter:brightness(105%)hue-rotate(350deg)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:darken;background:-webkit-linear-gradient(to right,rgba(66,10,14,0.2)1,rgba(0,0,0,0));background:linear-gradient(to right,rgba(66,10,14,0.2)1,rgba(0,0,0,0));z-index:10}`);break;case"Hudson":F(`.${O}{position:relative;-webkit-filter:contrast(90%)brightness(120%)saturate(110%);filter:contrast(90%)brightness(120%)saturate(110%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:multiply;opacity:0.5;background:-webkit-radial-gradient(50%50%,circle closest-corner,rgba(255,177,166,1)50,rgba(52,33,52,1));background:radial-gradient(50%50%,circle closest-corner,rgba(255,177,166,1)50,rgba(52,33,52,1));z-index:10}`);break;case"Inkwell":F(`.${O}{position:relative;-webkit-filter:contrast(110%)brightness(110%)sepia(30%)grayscale(100%);filter:contrast(110%)brightness(110%)sepia(30%)grayscale(100%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;background:rgba(0,0,0,0);z-index:10}`);break;case"Lofi":F(`.${O}{position:relative;-webkit-filter:contrast(150%)saturate(110%);filter:contrast(150%)saturate(110%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:multiply;background:-webkit-radial-gradient(50%50%,circle closest-corner,rgba(0,0,0,0)70,rgba(34,34,34,1));background:radial-gradient(50%50%,circle closest-corner,rgba(0,0,0,0)70,rgba(34,34,34,1));z-index:10}`);break;case"Maven":F(`.${O}{position:relative;-webkit-filter:contrast(95%)brightness(95%)saturate(150%)sepia(25%);filter:contrast(95%)brightness(95%)saturate(150%)sepia(25%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:hue;background:rgba(3,230,26,0.2);z-index:10}`);break;case"Perpetua":F(`.${O}{position:relative}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:soft-light;opacity:0.5;background:-webkit-linear-gradient(to bottom,rgba(0,91,154,1)1,rgba(61,193,230,0));background:linear-gradient(to bottom,rgba(0,91,154,1)1,rgba(61,193,230,0));z-index:10}`);break;case"Reyes":F(`.${O}{position:relative;-webkit-filter:contrast(85%)brightness(110%)saturate(75%)sepia(22%);filter:contrast(85%)brightness(110%)saturate(75%)sepia(22%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:soft-light;opacity:0.5;background:rgba(173,205,239,1);z-index:10}`);break;case"Stinson":F(`.${O}{position:relative;-webkit-filter:contrast(75%)brightness(115%)saturate(85%);filter:contrast(75%)brightness(115%)saturate(85%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:soft-light;background:rgba(240,149,128,0.2);z-index:10}`);break;case"Toaster":F(`.${O}{position:relative;-webkit-filter:contrast(150%)brightness(90%);filter:contrast(150%)brightness(90%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:screen;opacity:0.5;background:-webkit-radial-gradient(50%50%,circle closest-corner,rgba(15,78,128,1)1,rgba(59,0,59,1));background:radial-gradient(50%50%,circle closest-corner,rgba(15,78,128,1)1,rgba(59,0,59,1));z-index:10}`);break;case"Walden":F(`.${O}{position:relative;-webkit-filter:brightness(110%)saturate(160%)sepia(30%)hue-rotate(350deg);filter:brightness(110%)saturate(160%)sepia(30%)hue-rotate(350deg)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:screen;opacity:0.3;background:rgba(204,68,0,1);z-index:10}`);break;case"Valencia":F(`.${O}{position:relative;-webkit-filter:contrast(108%)brightness(108%)sepia(8%);filter:contrast(108%)brightness(108%)sepia(8%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:exclusion;opacity:0.5;background:rgba(58,3,57,1);z-index:10}`);break;case"Xpro2":F(`.${O}{position:relative;-webkit-filter:sepia(30%);filter:sepia(30%)}.${O}::before{content:"";display:block;height:100%;width:100%;top:0;left:0;position:absolute;pointer-events:none;mix-blend-mode:color-burn;background:-webkit-radial-gradient(50%50%,circle closest-corner,rgba(224,231,230,1)40,rgba(43,42,161,0.6));background:radial-gradient(50%50%,circle closest-corner,rgba(224,231,230,1)40,rgba(43,42,161,0.6));z-index:10}`);break;default:V("Ex_Style_Filter")}},document.getElementById("filter__panorama").addEventListener("click",()=>{var e,t=document.getElementById("ex-panorama");t?(t.remove(),yr=null):(t=document.getElementById("__h5player"),(e=document.createElement("div")).id="ex-panorama",e.style="width:100%;height:100%;z-index:1;background:black;",t.insertBefore(e,t.childNodes[0]),function e(t){requestAnimationFrame(()=>{e(t)});t.update()}(yr=new sl(e,H)))}),Vi=k([".Title-anchorName",".anchorName__6NXv9"]).innerText,Hi=.25*H.videoWidth,Gi=.25*H.videoHeight,(Fi=document.createElement("canvas")).width=Hi,Fi.height=Gi,(j=document.createElement("canvas")).width=H.videoWidth,j.height=H.videoHeight;e=document.createElement("div"),o=(e.id="ex-camera",e.title="单击截图 长按录制gif",e.innerHTML=`
    <svg t="1620266708389" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2080" width="38" height="38"><path d="M512 337.371136c-119.543808 0-216.800256 97.255424-216.800256 216.798208 0 119.543808 97.256448 216.800256 216.800256 216.800256s216.800256-97.256448 216.800256-216.800256C728.800256 434.625536 631.543808 337.371136 512 337.371136zM680.479744 554.16832c0 92.911616-75.579392 168.501248-168.479744 168.501248-92.900352 0-168.480768-75.589632-168.480768-168.501248 0-92.923904 75.579392-168.521728 168.480768-168.521728C604.899328 385.646592 680.479744 461.24544 680.479744 554.16832z" p-id="2081" fill="#ffffff"></path><path d="M831.209472 337.349632l-47.167488 0c-13.647872 0-24.751104 11.083776-24.751104 24.707072 0 13.635584 11.103232 24.7296 24.751104 24.7296l47.167488 0c13.646848 0 24.75008-11.094016 24.75008-24.7296C855.959552 348.433408 844.85632 337.349632 831.209472 337.349632z" p-id="2082" fill="#ffffff"></path><path d="M700.505088 171.497472c4.235264 0 6.403072 0.405504 7.232512 0.612352 1.47968 1.514496 4.790272 6.218752 11.717632 20.685824 2.83648 5.910528 8.6272 18.86208 15.888384 35.533824l11.788288 27.063296 29.518848 0 96.535552 0c35.122176 0 63.695872 28.535808 63.695872 63.609856l0 469.933056c0 35.05152-28.573696 63.567872-63.695872 63.567872L150.811648 852.503552c-35.121152 0-63.694848-28.516352-63.694848-63.567872L87.1168 319.0016c0-35.062784 28.573696-63.589376 63.694848-63.589376l99.35872 0 29.110272 0 11.964416-26.537984c4.698112-10.421248 8.416256-19.063808 11.058176-25.70752 9.86112-24.829952 15.207424-30.125056 16.239616-30.974976 0.52736-0.161792 2.64192-0.695296 7.673856-0.695296L700.505088 171.496448M700.505088 126.441472 326.216704 126.441472c-32.519168 0-47.275008 13.479936-65.787904 60.096512-3.180544 7.999488-7.689216 18.122752-10.257408 23.819264l-99.35872 0c-59.96544 0-108.750848 48.738304-108.750848 108.645376l0 469.933056c0 59.894784 48.785408 108.623872 108.750848 108.623872l722.37568 0c59.96544 0 108.751872-48.729088 108.751872-108.623872L981.940224 319.0016c0-59.91936-48.786432-108.665856-108.751872-108.665856l-96.535552 0c-4.458496-10.236928-12.420096-28.372992-16.574464-37.031936C744.823808 141.448192 733.973504 126.441472 700.505088 126.441472L700.505088 126.441472z" p-id="2083" fill="#ffffff"></path></svg>
    <div id="ex-camera-close">×</div>
    `,document.getElementById("js-player-dialog"));o.insertBefore(e,o.childNodes[0]);{let e=k([".layout-Player-video",".layout-Player-videoEntity"]),t=document.getElementsByClassName("room-Player-Box")[0],o=document.getElementById("ex-camera"),n=document.getElementById("ex-camera-close"),i=null,a=0,r=0,l,s=0,d=!1;n.addEventListener("click",e=>{e.stopPropagation(),confirm("是否7天内不再显示？")?localStorage.setItem("ExSave_Camera_Hidden",Date.now()+6048e5):d=!0,o.style.display="none"}),zi()||(e.addEventListener("mouseenter",()=>{d||zi()||(o.style.display="flex",s=setTimeout(()=>{o.style.display="none"},2e3))}),t.addEventListener("mousemove",()=>{d||zi()||(o.style.display="flex",clearTimeout(s),s=setTimeout(()=>{o.style.display="none"},2e3))}),o.addEventListener("mouseenter",()=>{d||zi()||(o.style.display="flex",clearTimeout(s))}),e.addEventListener("mouseleave",()=>{o.style.display="none",clearTimeout(s)}),t.addEventListener("mouseleave",()=>{o.style.display="none",clearTimeout(s)}),o.addEventListener("mousedown",e=>{if("ex-camera-close"!==e.target.id){if(clearInterval(a),i&&"function"==typeof i.abort)try{i.abort()}catch(e){}i=null,r=(new Date).getTime(),j.width=H.videoWidth,j.height=H.videoHeight,j.getContext("2d").drawImage(H,0,0,j.width,j.height),l=j.toDataURL("image/png"),i=new GIF({workers:5,quality:3,width:Hi,height:Gi,workerScript:qi}),Wi(H,Fi,i,Ui),a=setInterval(()=>{Wi(H,Fi,i,Ui)},Ui)}}),o.addEventListener("mouseup",e=>{if("ex-camera-close"!==e.target.id){e=(new Date).getTime();if(clearInterval(a),800<=e-r)S("【录制】正在生成gif...","info"),i.on("finished",e=>{var t=document.createElement("a");let o=URL.createObjectURL(e);t.href=o,t.download=`【${Vi}】`+_("yyyy-MM-dd hh-mm-ss",new Date),document.body.appendChild(t);e=document.createEvent("MouseEvents");e.initEvent("click",!1,!1),t.dispatchEvent(e),document.body.removeChild(t),setTimeout(function(){try{URL.revokeObjectURL(o)}catch(e){}},1500)}),i.render();else{if(i&&"function"==typeof i.abort)try{i.abort()}catch(e){}i=null;var e=document.createElement("a"),t=(e.download=`【${Vi}】`+_("yyyy-MM-dd hh-mm-ss",new Date),e.href=l,document.body.appendChild(e),document.createEvent("MouseEvents"));t.initEvent("click",!1,!1),e.dispatchEvent(t),document.body.removeChild(e)}}}))}{let a=k([".layout-Player-videoEntity",".layout-Player-video"]),r=document.getElementsByClassName("layout-Player-videoEntity")[0],l=0,s=0;a&&r&&(r.style.transformOrigin="0 0",r.style.transition="transform 0.1s",Wr&&window.removeEventListener("wheel",Wr,!0),Wr=t=>{if(t.ctrlKey&&(a=a||k([".layout-Player-videoEntity",".layout-Player-video"]),r=r||document.getElementsByClassName("layout-Player-videoEntity")[0],a)&&r){var o=a.getBoundingClientRect();if(!(t.clientX<o.left||t.clientX>o.right||t.clientY<o.top||t.clientY>o.bottom)){t.preventDefault(),t.stopImmediatePropagation();var n=t.clientX-o.left,o=t.clientY-o.top;let e=Ur+(t.deltaY<0?.1:-.1);e<.1&&(e=.1);var t=(n-l)/Ur,i=(o-s)/Ur;l=n-t*e,s=o-i*e,(Ur=e)<.1&&(Ur=.1),r.style.transform=`translate(${l}px, ${s}px) scale(${Ur})`}}},window.addEventListener("wheel",Wr,{capture:!0,passive:!1}),Yr&&window.removeEventListener("mousemove",Yr,!0),Qr&&window.removeEventListener("mouseup",Qr,!0),window.addEventListener("mousedown",e=>{var t;e.ctrlKey&&0===e.button&&(t=a.getBoundingClientRect(),e.clientX<t.left||e.clientX>t.right||e.clientY<t.top||e.clientY>t.bottom||(e.preventDefault(),r.style.transition="none",Jr={x:e.clientX,y:e.clientY,tx:l,ty:s}))},!0),Yr=e=>{Jr&&(l=Jr.tx+(e.clientX-Jr.x),s=Jr.ty+(e.clientY-Jr.y),r.style.transform=`translate(${l}px, ${s}px) scale(${Ur})`)},Qr=()=>{Jr&&(Jr=null,r.style.transition="transform 0.1s")},window.addEventListener("mousemove",Yr,!0),window.addEventListener("mouseup",Qr,!0))}pl(B,!0,0,"1",e=>{if(""!=e||null!=e)if("None"==e)S("房间未开播或其他错误","error");else{var t=String(e).split("/live");0<t.length&&t[0];let n="Fake";var t=document.createElement("div"),o="",o=(t.id="exVideoDiv"+n,t.className="exVideoDiv",o+="<video controls='controls' class='exVideoPlayer' id='exVideoPlayer"+String(n)+"'></video><div class='exVideoScale' id='exVideoScale"+String(n)+"'></div>",t.innerHTML=o,k([".layout-Main",".playerWrap__8wGvw",".live-next-body"]));if(o.insertBefore(t,o.childNodes[0]),flvjs.isSupported()){t=document.getElementById("exVideoPlayer"+n);let o=flvjs.createPlayer({type:"flv",url:e},{fixAudioTimestampGap:!1});o.on("media_info",e=>{var t;e&&e.metadata&&(P=e.metadata,e=document.getElementById("exVideoDiv"+String(n)),t=document.getElementById("exVideoPlayer"+String(n)),o.destroy(),t.remove(),e.remove(),P)&&(P.dy_cpu_model||P.dy_gpu_model||P.dy_device_model||P.dy_os_version||P.z_canvas_code)&&((t=document.createElement("li")).id="ex-metadata",t.innerHTML=`
    主播配置信息
    <ul class="metadata__wrap">
      ${P.dy_cpu_model?`<li title="${P.dy_cpu_model}">🤖CPU<br/>${P.dy_cpu_model}</li>`:""}
      ${P.dy_gpu_model?`<li title="${P.dy_gpu_model}">🎮显卡<br/>${P.dy_gpu_model}</li>`:""}
      ${P.dy_device_model?`<li title="${P.dy_device_model}">📱设备<br/>${P.dy_device_model}</li>`:""}
      ${P.dy_os_version?`<li title="${P.dy_os_version}">🖥️系统<br/>${P.dy_os_version}</li>`:""}
      ${P.z_canvas_code?`<li title="${P.z_canvas_code}">🎥场景<br/>${P.z_canvas_code}</li>`:""}
    </ul>
    `,(e=document.getElementsByClassName("menu-da2a9e")[0]).insertBefore(t,e.childNodes[1]))}),o.attachMediaElement(t),o.load()}}}),Pa(),Ca(),pa||(pa=!0,document.addEventListener("fullscreenchange",Oa,!0),document.addEventListener("webkitfullscreenchange",Oa,!0),document.addEventListener("mozfullscreenchange",Oa,!0),document.addEventListener("MSFullscreenChange",Oa,!0)),Ba(),Da(),n=()=>{jr()},document.getElementById("js-player-toolbar").addEventListener("mouseover",n),document.getElementById("js-player-asideMain").addEventListener("mouseover",n),k([".inputView-2a65aa",".inputView-620ab7"]).addEventListener("focus",()=>{Vr=!0}),k([".inputView-2a65aa",".inputView-620ab7"]).addEventListener("blur",()=>{Vr=!1}),new G(".app-f0f9c7",!1,e=>{0<e.length&&(0<e[0].addedNodes.length?Vr=!0:0<e[0].removedNodes.length&&(Vr=!1))})}100<=++qr&&clearInterval(s)},1500)}l=document.createElement("div"),l.className="extool",l.innerHTML='<div class="extool__close" title="关闭">×</div>',i=document.getElementsByClassName("layout-Player-chat")[0],i.insertBefore(l,i.childNodes[0]),l=document.createElement("div"),l.className="extool-icon",l.innerHTML='<a class="ex-panel__icon" title="扩展功能"><svg t="1590294700144" style="display:block;" class="icon" viewBox="0 0 1077 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="11915" width="30" height="30"><path d="M152.770257 11.469971l213.048618 206.378138-37.094375 36.931681 159.440737 158.545917-76.95456 73.782015-159.440737-158.545917-38.47728 36.931681L0.244042 159.115348 152.770257 11.469971z" p-id="11916" fill="#d81e06"></path><path d="M1077.851922 217.848109h-105.751509L929.393073 260.311408l-31.644106 31.400063-33.02701 32.538926L776.866857 300.985065l-23.428026-87.204321 33.027009-32.538926 33.02701-32.538926L862.281538 105.751509V0.569431h-8.134732a244.041945 244.041945 0 0 0-178.964092 68.331745 234.768351 234.768351 0 0 0-68.738481 147.645376 250.712425 250.712425 0 0 0 10.981887 95.664443v2.765808a34.165872 34.165872 0 0 1-9.598983 36.931681c-17.896409 16.269463-525.096918 497.520178-525.096918 497.520178-42.625993 35.548777-38.47728 102.497617 0 142.113759 39.860184 38.233238 105.751509 40.673657 142.927233 0 0 0 478.322212-504.353352 498.984429-524.852875A33.677788 33.677788 0 0 1 754.821735 455.544963c5.531617 1.382904 10.981888 4.067366 16.269463 5.450271a242.170956 242.170956 0 0 0 87.936447 9.598983 237.290118 237.290118 0 0 0 148.45885-68.331745 231.677153 231.677153 0 0 0 68.738481-177.662536 14.805211 14.805211 0 0 0 1.626946-6.751827zM178.964093 943.628853a33.352399 33.352399 0 0 1-48.076263 0 32.538926 32.538926 0 0 1 0-47.832221 33.352399 33.352399 0 0 1 48.076263 0 35.467429 35.467429 0 0 1 0 47.832221z" p-id="11917" fill="#d81e06"></path><path d="M981.618049 785.082936L747.988561 567.804258S617.344773 601.97013 526.642517 753.682873c5.531617 1.382904 241.926915 239.161106 241.926914 239.161105a109.98157 109.98157 0 0 0 152.607563 0l60.441055-58.732761a102.823006 102.823006 0 0 0 0-149.028281zM854.146806 951.763584a29.366381 29.366381 0 0 1-38.477279 0l-195.233556-189.94598-1.382905-1.382904a25.543057 25.543057 0 0 1 1.382905-35.548777 29.366381 29.366381 0 0 1 38.47728 0l196.535113 189.94598A28.796949 28.796949 0 0 1 854.146806 951.763584z m86.634891-83.380997a29.366381 29.366381 0 0 1-38.47728 0L705.362568 678.436606l-1.382905-1.382904a25.543057 25.543057 0 0 1 1.382905-35.548777 29.366381 29.366381 0 0 1 38.477279 0l196.535113 189.945981a24.404194 24.404194 0 0 1 0 37.013028z" p-id="11918" fill="#d81e06"></path></svg><i id="extool__tip" class="ex-panel__tip"></i></a>',i=document.getElementsByClassName("ex-panel__wrap")[0],i.insertBefore(l,i.childNodes[0]),document.getElementsByClassName("extool-icon")[0].addEventListener("click",function(){ee("扩展功能")}),l=document.getElementsByClassName("extool__close")[0],l&&l.addEventListener("click",e=>{e.stopPropagation();e=document.getElementsByClassName("extool")[0];e&&(e.style.display="none")}),i="",i+='<label><input style="margin-top:5px" id="extool__treasure_start" type="checkbox">半自动抢宝箱</label>',(i=document.createElement("div")).className="extool__treasure",i.innerHTML='<label><input style="margin-top:5px" id="extool__treasure_start" type="checkbox">半自动抢宝箱</label><label style="margin-left:10px;">延迟(抢得过快请调高)：</label><input id="extool__treasure_delay" type="text" style="width:50px;text-align:center;" value="3200" />ms<div class="extool__hint">说明：遇到验证码会自动弹出验证框，需要手动完成后才能领取。</div>',l=document.getElementsByClassName("extool")[0];l.insertBefore(i,l.childNodes[0]),document.getElementById("extool__treasure_start").addEventListener("click",function(){Y().then(e=>{1==e?(1==document.getElementById("extool__treasure_start").checked?(Vt=!0,unsafeWindow.socketProxy.socketStream.subscribe("tslist",i=>{if(null!=i)for(let n=0;n<i.list.length-1;n++){var a=i.list[n];let e=a.rpid;a=a.ot;let t=Q("dy_did");var a=Number(a)-Math.floor(Date.now()/1e3),r=document.createElement("div");let o="Ex_Geetest_no"+String(To);r.id=o,document.getElementById("Ex_Geetest").appendChild(r),0<=a?(a=1e3*a+qt(),To++,setTimeout(()=>{No(B,e,t,o)},a)):No(B,e,t,o)}})):Vt=!1,Vt=document.getElementById("extool__treasure_start").checked,e=document.getElementById("extool__treasure_delay").value,e={isGetTreasure:Vt,treasureDelay:e},localStorage.setItem("ExSave_Treasure",JSON.stringify(e))):(document.getElementById("extool__treasure_start").checked=!1,S("本功能需拥有9级歆崽粉丝牌(5189167)才可使用","error"))})});null!=(i=localStorage.getItem("ExSave_Treasure"))&&("treasureDelay"in(i=JSON.parse(i))==1?document.getElementById("extool__treasure_delay").value=i.treasureDelay:document.getElementById("extool__treasure_delay").value="3200",1==i.isGetTreasure)&&Y().then(e=>{1==e?document.getElementById("extool__treasure_start").click():(localStorage.setItem("ExSave_Treasure",JSON.stringify({isGetTreasure:!1})),S("本功能需拥有9级歆崽粉丝牌(5189167)才可使用","error"))});l=document.createElement("div"),l.className="extool__gold",l.innerHTML='<label><input id="extool__gold_start" type="checkbox">幻神模式</label><label><input id="extool__goldGift_start" type="checkbox">荧光棒变超火</label>',i=document.getElementsByClassName("extool")[0],i.insertBefore(l,i.childNodes[0]),l=document.createElement("div"),l.className="ex_giftAnimation",i=document.getElementsByClassName("Barrage-main")[0],i.insertBefore(l,i.childNodes[0]),document.getElementById("extool__gold_start").addEventListener("click",async function(){var e;1==document.getElementById("extool__gold_start").checked?(Nt=new G(".danmu-e7f029",!0,Dt),Mt=new G(".Barrage-list",!0,At),document.getElementsByClassName("FansMedalEnter-enterContent")[0].setAttribute("data-medal-level","50")):(Nt.closeHook(),Mt.closeHook()),e={isGold:e=document.getElementById("extool__gold_start").checked},localStorage.setItem("ExSave_Gold",JSON.stringify(e))}),document.getElementById("extool__goldGift_start").addEventListener("click",async function(){var e;Ct=await K(),1==document.getElementById("extool__goldGift_start").checked?Lt=new G(".BarrageBanner",!0,jt):Lt.closeHook(),e={isGoldGift:e=document.getElementById("extool__goldGift_start").checked},localStorage.setItem("ExSave_GoldGift",JSON.stringify(e))}),l=localStorage.getItem("ExSave_Gold"),null!=l&&1==JSON.parse(l).isGold&&document.getElementById("extool__gold_start").click(),null!=(l=localStorage.getItem("ExSave_GoldGift"))&&1==JSON.parse(l).isGoldGift&&document.getElementById("extool__goldGift_start").click(),i=document.createElement("div"),i.className="extool__redpacket_room",i.innerHTML='<label><input id="extool__redpacekt_room_start" type="checkbox">自动抢礼物红包</label>',l=document.getElementsByClassName("extool")[0],l.insertBefore(i,l.childNodes[0]),document.getElementById("extool__redpacekt_room_start").addEventListener("click",function(){Y().then(e=>{1==e?(1==document.getElementById("extool__redpacekt_room_start").checked?Ot=setInterval(()=>{fetch("https://www.douyu.com/japi/interactnc/web/propredpacket/getPrpList?type_id=1&room_id="+B,{method:"GET",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"}}).then(e=>e.json()).then(o=>{if(0<o.data.list.length)for(let t=0;t<o.data.list.length;t++){let e=o.data.list[t].activityid;var n=zt.indexOf(e),i=o.data.list[t].startTime,i=1e3*(Number(i)-Math.round((new Date).getTime()/1e3))-2e3;-1==n&&(zt.push(o.data.list[t].activityid),0<i?setTimeout(()=>{Rt(e),Rt(e),Rt(e),S("【礼物红包】抢红包执行完毕！","success")},i):(Rt(e),Rt(e),Rt(e),S("【礼物红包】抢红包执行完毕！","success")))}}).catch(e=>{console.log("请求失败!",e)})},6e4):clearInterval(Ot),e={isGetRedPacket:e=document.getElementById("extool__redpacekt_room_start").checked},localStorage.setItem("ExSave_RedPacket_Room",JSON.stringify(e))):(document.getElementById("extool__redpacekt_room_start").checked=!1,S("本功能需拥有6级歆崽粉丝牌(5189167)才可使用","error"))})}),i=localStorage.getItem("ExSave_RedPacket_Room"),null!=i&&1==JSON.parse(i).isGetRedPacket&&Y().then(e=>{1==e?document.getElementById("extool__redpacekt_room_start").click():(localStorage.setItem("ExSave_RedPacket_Room",JSON.stringify({isGetRedPacket:!1})),S("本功能需拥有6级歆崽粉丝牌(5189167)才可使用","error"))}),l="",l+='<label><input id="extool__autofish_start" type="checkbox">自动钓鱼</label><br>',(l=document.createElement("div")).className="extool__autofish",l.innerHTML='<label><input id="extool__autofish_start" type="checkbox">自动钓鱼</label><br><label><input name="autofish_mode" type="radio" value="all" checked>全天</label><label style="margin-left:5px;"><input name="autofish_mode" type="radio" value="contest">钓鱼大赛</label>',i=document.getElementsByClassName("extool")[0],i.insertBefore(l,i.childNodes[0]),document.querySelectorAll('input[name="autofish_mode"]').forEach(e=>{e.addEventListener("change",kt)}),document.getElementById("extool__autofish_start").addEventListener("click",async()=>{kt();var e,t=document.getElementById("extool__autofish_start").checked;if(_t(t),t)return S("【自动钓鱼】开始自动钓鱼","info"),ht=await new Promise(t=>{fetch(`https://www.douyu.com/japi/revenuenc/web/actfans/achieve/accList?rid=${B}&type=1&period=1`,{method:"GET",mode:"no-cors",cache:"default",credentials:"include"}).then(e=>e.json()).then(e=>{e.data?t(e.data.accList):t([])}).catch(e=>{console.log("请求失败!",e)})}),(t=await Et()).data?(e=t.data.baits.find(e=>e.inUse))?(ft=e.id,t.data.myCh?(kt(),0==t.data.fishing.stat&&(bt=!1,yt=0),1==t.data.fishing.stat&&(bt=!0,yt=t.data.fishing.fishEtMs),2==t.data.fishing.stat&&(await xt(),await b(1e3)),void(vt=setInterval(async()=>{var e;(()=>{var e,t=(t=document.querySelector('input[name="autofish_mode"]:checked'))?t.value:"all";return"all"===t||(e=(t=new Date).getHours(),t=t.getMinutes(),12<=e&&t<30)||0===e&&t<30})()&&(bt?(new Date).getTime()<=yt||await xt():0!==(e=await new Promise(t=>{fetch("https://www.douyu.com/japi/revenuenc/web/actfans/fishing/fishing",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&rid=${B}&baitId=${ft}&ver=1.1`}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})})).error?(S("【自动钓鱼】"+e.msg,"error"),console.log(e,"钓鱼失败"),1001007==e.error&&await xt(),1005003==e.error&&clearInterval(vt)):(bt=!0,yt=e.data.fishing.fishEtMs))},1500))):(_t(document.getElementById("extool__autofish_start").checked=!1),S("【自动钓鱼】请设置形象","error"))):(_t(document.getElementById("extool__autofish_start").checked=!1),S("【自动钓鱼】请设置鱼饵","error")):(_t(document.getElementById("extool__autofish_start").checked=!1),S("【自动钓鱼】未能获取活动信息","error"));clearInterval(vt)}),l=wt(),l.rids.includes(B)&&(l=l.modes&&l.modes[B]?l.modes[B]:"all",document.querySelector(`input[name="autofish_mode"][value="${l}"]`).checked=!0,document.getElementById("extool__autofish_start").click()),i=document.createElement("div"),i.className="extool__clearbag",i.innerHTML='<label>背包送礼：[速度并不快,间隔>0.1s]</label><a id="extool__clearbag_showid" style="margin-left:10px;color:blue;" href="javascript:void(0);">礼物id示例</a><br /><label>礼物ID：</label><input id="extool__clearbag_id" type="text" style="width:50px;text-align:center;margin-right:10px;" value="268" /><label>数量：</label><input id="extool__clearbag_cnt" type="text" style="width:30px;text-align:center;" value="1" /><input style="margin-left:10px;" type="button" id="extool__clearbag_sendbtn" value="送出" />',l=document.getElementsByClassName("extool")[0],l.insertBefore(i,l.childNodes[0]),document.getElementById("extool__clearbag_sendbtn").addEventListener("click",async function(){if(1==confirm("确认送出？")){let t=document.getElementById("extool__clearbag_id").value;var o=Number(document.getElementById("extool__clearbag_cnt").value);S("【背包送礼】执行中...","info");for(let e=0;e<o;e++)await b(100).then(()=>{Ut(t,1,B).then(e=>{"success"!=e.msg&&(S("【背包送礼】"+B+"赠送失败 "+e.msg,"error"),console.log(B,e))}).catch(e=>{S("【背包送礼】"+B+"赠送失败","error"),console.log(B,e)})});S("【背包送礼】执行完毕！","success")}}),document.getElementById("extool__clearbag_showid").addEventListener("click",function(){Bt(B,t=>{var o=t.data.list.length;if(0<o){for(let e=0;e<o;e++){var n=t.data.list[e].id,i=t.data.list[e].name;console.log("【"+i+"】 id:"+n)}S("请按F12到控制台(console)查看背包礼物id","success")}else S("背包礼物为空","error")})}),i="",i=(i=(i+='<label>送礼：[用于打榜,例如送出999个飞机]</label><a style="margin-left:10px;color:blue;" href="http://open.douyucdn.cn/api/RoomApi/room/'+B+'" target="_blank">礼物id示例</a><br />')+'<label>礼物ID：</label><input id="extool__sendgift_id" type="text" style="width:50px;text-align:center;margin-right:10px;" value="20000" /><label>数量：</label><input id="extool__sendgift_cnt" type="text" style="width:30px;text-align:center;margin-right:10px;" value="1" />')+'<br/><label>间隔ms：</label><input id="extool__sendgift_delay" type="text" style="width:30px;text-align:center;" value="0" /><input style="margin-left:10px;" type="button" id="extool__sendgift_btn" value="送出" />',l=document.createElement("div"),l.className="extool__sendgift",l.innerHTML=i,(i=document.getElementsByClassName("extool")[0]).insertBefore(l,i.childNodes[0]),document.getElementById("extool__sendgift_btn").addEventListener("click",async()=>{if(1==confirm("确认送出？")){let o=document.getElementById("extool__sendgift_id").value,n=document.getElementById("extool__sendgift_cnt").value;var e,r=Number(document.getElementById("extool__sendgift_delay").value);let i=0,a=0;for(let t=0;t<Number(n);t++)e=o,fetch("https://www.douyu.com/japi/gift/donate/mainsite/v1",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"giftId="+e+"&giftCount="+1+"&roomId="+B+"&bizExt=%7B%22yzxq%22%3A%7B%7D%7D"}).then(e=>e.json()).then(e=>{null!=e.data&&"鱼翅不足"!=e.msg?(i+=1,a+=Number(e.data.priceType)):console.log("【送礼】"+o+e.msg),t==Number(n)-1&&(S("【送礼】赠送完毕！详细信息可以在F12控制台查看","success"),console.log("【送礼】赠送完毕！详细信息可以在F12控制台查看"))}).catch(e=>{console.log("请求失败!",e)}),0<r&&await b(r);S("【送礼】执行中...","info")}}),localStorage.setItem("freetimed","1"),l=document.createElement("span"),l.innerHTML='<label title="阻止浏览器页签冻结"><input id="extool__tabSwitch" type="checkbox">防页签冻结</label>',i=document.getElementsByClassName("extool")[0];i.insertBefore(l,i.childNodes[0]),document.getElementById("extool__tabSwitch").addEventListener("click",function(){var e=document.getElementById("extool__tabSwitch").checked;Ht(e),e?Gt():(S("已关闭页面防挂机，请刷新页面生效","info"),window.__pip_is_active__&&ka())});null!=(l=localStorage.getItem("ExSave_TabSwitch"))&&(l=JSON.parse(l)).isEnableTabSwitch&&(document.getElementById("extool__tabSwitch").checked=l.isEnableTabSwitch,Gt());i=document.createElement("span"),i.innerHTML='<label title="阻止p2p在后台占用网速，开启后直播画面会在刚进入页面时卡一下"><input id="extool__p2p" type="checkbox">阻止p2p上传</label>',l=document.getElementsByClassName("extool")[0];l.insertBefore(i,l.childNodes[0]),document.getElementById("extool__p2p").addEventListener("click",function(){var e;e={isKillP2P:Pt()},localStorage.setItem("ExSave_P2P",JSON.stringify(e)),Pt()&&S("阻止p2p上传成功，刷新页面生效","success")});null!=(i=localStorage.getItem("ExSave_P2P"))&&(i=JSON.parse(i)).isKillP2P&&(document.getElementById("extool__p2p").checked=i.isKillP2P);l=document.createElement("span"),l.innerHTML='<label title="自动网页全屏"><input id="extool__fullscreen" type="checkbox">自动网页全屏</label><label title="自动最高画质"><input id="extool__highestvideoquality" type="checkbox">自动最高画质</label>',i=document.getElementsByClassName("extool")[0];i.insertBefore(l,i.childNodes[0]),document.getElementById("extool__fullscreen").addEventListener("click",function(){var e;e={isFullScreen:It()},localStorage.setItem("ExSave_FullScreen",JSON.stringify(e)),It()&&S("刷新页面生效","success")}),document.getElementById("extool__highestvideoquality").addEventListener("click",function(){var e;e={isHighestVideoQuality:St()},localStorage.setItem("ExSave_HighestVideoQuality",JSON.stringify(e)),St()&&S("刷新页面生效","success")}),null!=(l=localStorage.getItem("ExSave_FullScreen"))&&(l=JSON.parse(l)).isFullScreen&&(document.getElementById("extool__fullscreen").checked=l.isFullScreen);null!=(i=localStorage.getItem("ExSave_HighestVideoQuality"))&&(i=JSON.parse(i)).isHighestVideoQuality&&(document.getElementById("extool__highestvideoquality").checked=i.isHighestVideoQuality);l=document.createElement("a"),l.className="refresh-barrage",l.id="refresh-barrage-frame",l.innerHTML='<svg t="1588051109604" id="refresh-barrage-frame__svg" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3095" width="16" height="16"><path d="M512 128 192 448h192v448h256V448h192L512 128z" fill="#AFAFAF" p-id="3096"></path></svg><i class="Barrage-toolbarIcon"></i><span id="refresh-barrage-frame__text" class="Barrage-toolbarText">拉高</span>',i=document.getElementsByClassName("Barrage-toolbar")[0];i.insertBefore(l,i.childNodes[0]),document.getElementById("refresh-barrage-frame").addEventListener("click",function(){let t=document.getElementsByClassName("layout-Player-rank")[0],o=document.getElementById("js-room-activity"),n=document.getElementsByClassName("Barrage")[0];var e;"none"==t.style.display?(t.style.display="block",o.style.display="block",n.className="Barrage",document.getElementById("refresh-barrage-frame__text").innerText="拉高",document.getElementById("refresh-barrage-frame").classList.remove("ex-active"),document.getElementById("refresh-barrage-frame__text").style.color="",(e=document.getElementById("refresh-barrage-frame__svg"))&&(e=e.getElementsByTagName("path")[0])&&e.setAttribute("fill","#AFAFAF"),Bn()):dl.confirm({title:"提示",content:"是否拉高弹幕框，隐藏日榜周榜",okBtn:"确定",cancelBtn:"取消",onConfirm:function(){t.style.display="none",o.style.display="none",n.className="Barrage top-0-important",document.getElementById("refresh-barrage-frame__text").innerText="拉高",document.getElementById("refresh-barrage-frame").classList.add("ex-active"),document.getElementById("refresh-barrage-frame__text").style.color="#fff";var e=document.getElementById("refresh-barrage-frame__svg");e&&(e=e.getElementsByTagName("path")[0])&&e.setAttribute("fill","#ffffff"),Bn()},onCancel:function(){}})});l=localStorage.getItem("ExSave_Refresh");null!=l&&("barrageFrame"in(l=JSON.parse(l))==0&&(l.barrageFrame={status:!1}),1==l.barrageFrame.status)&&(l=document.getElementsByClassName("layout-Player-rank")[0],i=document.getElementById("js-room-activity"),l.style.display="none",i.style.display="none",document.getElementById("refresh-barrage-frame__text").innerText="拉高",document.getElementById("refresh-barrage-frame").classList.add("ex-active"),document.getElementById("refresh-barrage-frame__text").style.color="#fff",l=document.getElementById("refresh-barrage-frame__svg"))&&(i=l.getElementsByTagName("path")[0])&&i.setAttribute("fill","#ffffff");{let d=setInterval(()=>{if(k([".right-e7ea5d",".right-17e251"])){clearInterval(d);{let e=document.createElement("li"),t=(e.id="refresh-video",e.innerText="隐藏礼物栏",document.getElementsByClassName("menu-da2a9e")[0]);t.insertBefore(e,t.childNodes[t.childNodes.length-1]),!document.getElementById("refresh-video3")&&((e=document.createElement("div")).id="refresh-video3",e.title="点击隐藏礼物栏",e.innerHTML=`<div style="display:flex;align-items:center;gap:6px;">
            <div style="font-size:12px;">隐藏礼物栏</div>
            <div id="ex-refresh-switch" style="width:26px;height:14px;background:rgba(255,255,255,0.3);border-radius:7px;position:relative;transition:background 0.3s;">
                <div id="ex-refresh-switch-circle" style="width:10px;height:10px;background:#fff;border-radius:50%;position:absolute;top:2px;left:2px;transition:left 0.3s, background 0.3s;"></div>
            </div>
        </div>`,e.style="position:absolute;left:18px;bottom:58px;padding:0 10px;height:28px;border-radius:14px;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55);color:#fff;z-index:9999;cursor:pointer;user-select:none;opacity:0;transform:scale(.9);transition:opacity .15s ease,transform .15s ease,background-color .15s ease,box-shadow .3s ease;pointer-events:none;",t=document.getElementById("js-player-dialog"))&&t.insertBefore(e,t.childNodes[0])}{function a(){let e=!1;var t=!!(document.fullscreenElement||document.webkitFullscreenElement||document.mozFullScreenElement||document.msFullscreenElement);let o=!1;(document.querySelector(".wfs-2a8e83.removed-9d4c42")||document.querySelector(".toggle__P8TKM"))&&(e=!0),document.querySelector(".shrink__Sd0uK")&&(o=!0);var n=document.getElementById("js-player-toolbar"),i=(n.style=e?"z-index:20":"z-index:30",document.getElementsByClassName("case__f4yex")[0]),i=(i&&(i.style=(t||e&&o)&&Nn()?"bottom: -84px;":"bottom: 0;"),!!document.getElementsByClassName("live-next-body")[0]);i&&(n.parentElement.style="z-index:20")}new G(".right-e7ea5d",!0,()=>{a()}),new G(".right-17e251",!0,()=>{a()}),new G(".video__VfhVg",!0,e=>{for(var t of e)t.target.className.includes("toggle__P8TKM")&&a()});let e=k([".layout-Player-video",".stream__T55I3"]),t=document.getElementsByClassName("room-Player-Box")[0],o=document.getElementById("refresh-video3"),i=0,n=!1;function r(){!o||n||(o.style.transition="opacity .15s ease,transform .15s ease,background-color .15s ease,box-shadow .3s ease",o.style.opacity="0",o.style.transform="scale(.9)",o.style.pointerEvents="none",clearTimeout(i))}function l(){o&&(o.style.transition="opacity .15s ease,transform .15s ease,background-color .15s ease,box-shadow .3s ease",o.style.opacity="1",o.style.transform="scale(1)",o.style.pointerEvents="auto",clearTimeout(i),i=setTimeout(()=>{r()},2e3))}function s(){var e=document.getElementsByClassName("PlayerToolbar-ContentRow")[0],t=k([".layout-Player-video",".stream__T55I3"]),o=document.getElementById("refresh-video");let n=document.getElementById("refresh-video3");e&&t&&o&&("hidden"==e.style.visibility?(e.style.visibility="visible",pt(),t.style="",n&&(n.style.opacity="0",n.style.transform="scale(.9)",n.style.pointerEvents="none",n.title="点击隐藏礼物栏"),Tn(!(o.innerText="隐藏礼物栏")),V("Ex_Style_VideoRefresh")):(e.style.visibility="hidden",ct(),t.style="bottom:0;z-index:25",o.innerText="✓ 隐藏礼物栏",n&&(n.title="点击显示礼物栏"),Tn(!0),n&&(n.style.transition="opacity .3s ease,transform .3s cubic-bezier(0.175, 0.885, 0.32, 1.275),background-color .3s ease,box-shadow .3s ease",n.style.opacity="1",n.style.transform="scale(1.1)",n.style.pointerEvents="auto",n.style.backgroundColor="rgba(0,0,0,.8)",n.style.boxShadow="0 0 15px rgba(255, 102, 0, 0.6)",clearTimeout(i),i=setTimeout(()=>{n.style.transition="opacity .15s ease,transform .15s ease,background-color .15s ease,box-shadow .15s ease",n.style.transform="scale(1)",n.style.backgroundColor="rgba(0,0,0,.55)",n.style.boxShadow="none",i=setTimeout(()=>{r()},1500)},800)),Mn()),a(),Bn(),oe())}e&&o&&(e.addEventListener("mouseenter",()=>{l()}),e.addEventListener("mouseleave",()=>{r()})),t&&o&&t.addEventListener("mousemove",()=>{l()}),o&&(o.addEventListener("mouseenter",()=>{n=!0,o.style.transition="opacity .15s ease,transform .15s ease,background-color .15s ease,box-shadow .3s ease",o.style.opacity="1",o.style.transform="scale(1.08)",o.style.pointerEvents="auto",o.style.backgroundColor="rgba(0,0,0,.7)",clearTimeout(i)}),o.addEventListener("mouseleave",()=>{n=!1,o.style.transform="scale(1)",o.style.backgroundColor="rgba(0,0,0,.55)",l()})),document.getElementById("refresh-video").addEventListener("click",e=>{s()}),o&&o.addEventListener("click",e=>{e.stopPropagation(),s()})}var e,t,o,n,i=localStorage.getItem("ExSave_Refresh");null!=i&&("video"in(i=JSON.parse(i))==0&&(i.video={status:!1}),1==i.video.status)&&(i=document.getElementsByClassName("PlayerToolbar-ContentRow")[0],e=k([".layout-Player-video",".stream__T55I3"]),t=document.getElementById("refresh-video"),o=document.getElementById("refresh-video3"),n=document.getElementById("js-player-toolbar"),i.style.visibility="hidden",e.style="bottom:0;z-index:25",n.style="z-index:30",null!=(i=localStorage.getItem("ExSave_FullScreen"))&&JSON.parse(i).isFullScreen&&(n.style="z-index:20"),document.getElementsByClassName("live-next-body")[0]&&(n.parentElement.style="z-index:20"),o&&(o.style.opacity="0",o.style.transform="scale(.9)",o.style.pointerEvents="none",o.title="点击显示礼物栏"),t.innerText="✓ 隐藏礼物栏",Mn(),oe(),setTimeout(()=>{Tn(!0)},500))}100<=++Cn&&clearInterval(d)},1500)}l=document.createElement("a"),l.className="refresh-barrage",l.id="refresh-barrage",l.innerHTML='<svg t="1588051109604" id="refresh-barrage__svg" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3095" width="16" height="16"><path d="M588.416 516.096L787.2 317.312a54.016 54.016 0 1 0-76.416-76.416L512 439.68 313.216 241.024A54.016 54.016 0 1 0 236.8 317.376l198.784 198.848-198.016 197.888a54.016 54.016 0 1 0 76.416 76.416L512 592.576l197.888 197.952a54.016 54.016 0 1 0 76.416-76.416L588.416 516.096z" fill="#AFAFAF" p-id="3096"></path></svg><i class="Barrage-toolbarIcon"></i><span id="refresh-barrage__text" class="Barrage-toolbarText">前缀</span>',i=document.getElementsByClassName("Barrage-toolbar")[0],i.insertBefore(l,i.childNodes[0]),document.getElementById("refresh-barrage").addEventListener("click",function(){var e;0==In?dl.confirm({title:"提示",content:"是否屏蔽弹幕前缀（如粉丝牌、钻粉、贵族等标志）",okBtn:"确定",cancelBtn:"取消",onConfirm:function(){Sn(),Bn()},onCancel:function(){}}):(V("Ex_Style_RefreshBarrage"),In=0,document.getElementById("refresh-barrage").classList.remove("ex-active"),document.getElementById("refresh-barrage__text").style.color="",document.getElementById("refresh-barrage__text").innerText="前缀",(e=document.getElementById("refresh-barrage__svg"))&&(e=e.getElementsByTagName("path")[0])&&e.setAttribute("fill","#AFAFAF"),Bn())}),l=localStorage.getItem("ExSave_Refresh"),null!=l&&("barrage"in(l=JSON.parse(l))==0&&(l.barrage={status:!1}),1==l.barrage.status)&&Sn(),i="",l=document.createElement("div"),l.className="bloop",i+='<div style="display:inline-block"><label>弹幕：</label></div>',l.innerHTML='<div style="display:inline-block"><label>弹幕：</label></div>\n\t<span style="float:right;margin-right:15px;">\n\t\t<select id="bloop__select"></select>\n\t\t<input style="margin-left:10px;" type="button" id="bloop__save" value="保存"/>\n\t\t<input style="margin-left:10px;" type="button" id="bloop__delete" value="删除"/>\n\t</span>\n\t<textarea placeholder="一行一个，开启舔狗模式后此处不需要输入" id="bloop__textarea" rows="5" cols="50"></textarea><div><label>速度(ms)：</label><input id="bloop__text_speed1" type="text" style="width:50px;text-align:center;" value="2000" />~<input id="bloop__text_speed2" type="text" style="width:50px;text-align:center;" value="3000" /></div><div><label>限时(min)：</label><input id="bloop__text_stoptime" type="text" style="width:50px;text-align:center;" value="1" /></div><div><label><input id="bloop__checkbox_changeColor" type="checkbox" name="checkbox_changeColor" checked>自动变色</label><label><input id="bloop__checkbox_tiangou" type="checkbox">舔狗模式</label><label><input id="bloop__checkbox_random" type="checkbox">随机发送</label></div><div class="bloop__switch"><label><input id="bloop__checkbox_startSend" type="checkbox">开始发送</label></div>',(i=document.getElementsByClassName("layout-Player-chat")[0]).insertBefore(l,i.childNodes[0]),l=document.createElement("div"),l.className="bloop-icon",l.innerHTML='<a class="ex-panel__icon" title="弹幕发送小助手"><svg t="1578572568198" style="display: block;" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="55445" width="32" height="32"><path d="M511.99883605 1020.07740302c-68.78771655 0-135.53209458-13.47788003-198.38074083-40.06106453-60.69004402-25.67037725-115.18953131-62.41203655-161.98371328-109.20738247-46.79418197-46.79301803-83.53700523-101.29366926-109.20621853-161.98371328C15.84497778 645.97776043 2.36709774 579.23105337 2.36709774 510.4445019s13.47904398-135.53209458 40.06106453-198.38074083c25.6692133-60.69004402 62.41203655-115.18953131 109.20621853-161.98371328 46.79534706-46.79418197 101.29366926-83.53700523 161.98371328-109.20621853 62.84864739-26.5831845 129.59418937-40.06106453 198.38074083-40.06106453 68.78771655 0 135.53209458 13.47904398 198.38190592 40.06106453 60.69004402 25.6692133 115.18953131 62.41203655 161.98487723 109.20621853 46.79301803 46.79418197 83.53584128 101.29366926 109.20621853 161.98371328 26.5831845 62.84864739 40.06106453 129.59418937 40.06106453 198.38074083s-13.47788003 135.53325853-40.06106453 198.38074084c-25.67037725 60.69004402-62.41203655 115.19069525-109.20621853 161.98371328-46.79534706 46.79418197-101.29483435 83.53817031-161.98487723 109.20738247C647.53092949 1006.59952413 580.78655147 1020.07740302 511.99883605 1020.07740302zM511.99883605 57.86089358c-249.55500203 0-452.58244437 203.02744235-452.58244437 452.58244437s203.02744235 452.58244437 452.58244437 452.58244438c249.55616597 0 452.58360832-203.02744235 452.58360832-452.58244438C964.58244437 260.88949987 761.55500203 57.86089358 511.99883605 57.86089358z" p-id="55446" fill="#1296db" data-spm-anchor-id="a313x.7781069.0.i24"></path><path d="M322.42598685 461.65355293l-8.51099648 74.46598314 97.86947811 0c-2.85950862 76.59314973-4.9866752 127.6556379-6.38266595 153.18746454-1.42975431 51.06132423-27.65899321 75.16339541-78.72148139 72.33881542-18.45058333 1.39598962-35.47024839 2.12716658-51.06248818 2.12716658-2.85950862-17.02082901-6.38266595-34.77283613-10.63816419-53.19081984 18.41681863 0 35.43764878 0 51.06248817 0 25.53066155 2.82574393 38.99456967-7.77981952 40.42432399-31.9133275 1.39598962-9.9069861 2.12833166-25.53182663 2.12833166-46.80698994 1.39598962-21.27632725 2.12716658-36.86740309 2.12716658-46.80698994l-99.9966447 0 14.89366244-172.33546126 89.3584805 0 0-78.72148138-102.12497636 0 0-48.9353216 151.05913287 0 0 176.5909595L322.42598685 461.65355293zM450.08162475 580.79819435l0-242.54594504 74.46598314 0c-17.0219941-24.10090723-31.91449145-43.25006791-44.67982222-57.44515413l46.80698994-21.27632725c4.25433429 4.25549824 10.63699911 12.06675342 19.14799673 23.40349497 15.5910747 18.45058333 24.79948459 30.51733789 27.65899321 36.16882574l-42.5514917 19.14799673 80.84864796 0c25.53066155-38.29715741 41.8203136-64.5263963 48.93415652-78.72031744l53.19081984 14.89366244c-5.68525255 8.50983253-15.62483939 22.70491762-29.78732487 42.55149169-7.11384291 9.93958685-12.06675342 17.02082901-14.89249849 21.27516331l70.20931982 0 0 242.54594503L620.28991829 580.7970304l0 51.06248818 144.67646806 0 0 48.93415651L620.28991829 680.79367509l0 87.23131392-51.06132423 0 0-87.23131392L428.80646144 680.79367509l0-48.93415651 140.42213376 0 0-51.06248818L450.08162475 580.7970304zM501.14411293 385.0604032l0 53.18965475 68.08331718 0 0-53.18965475L501.14411293 385.0604032zM501.14411293 480.80154965l0 55.31682248 68.08331718 0L569.22743011 480.80154965 501.14411293 480.80154965zM688.37323549 385.0604032l-68.0833172 0 0 53.18965475 68.0833172 0L688.37323549 385.0604032zM620.28991829 480.80154965l0 55.31682248 68.0833172 0L688.37323549 480.80154965 620.28991829 480.80154965z" p-id="55447" fill="#1296db"></path></svg><i id="bloop__tip" class="ex-panel__tip"></i></a>',i=document.getElementsByClassName("ex-panel__wrap")[0],i.insertBefore(l,i.childNodes[0]),document.getElementsByClassName("bloop-icon")[0].addEventListener("click",function(){ee("弹幕发送小助手")}),document.getElementById("bloop__checkbox_changeColor").addEventListener("click",function(){be=document.getElementById("bloop__checkbox_changeColor").checked}),document.getElementById("bloop__checkbox_startSend").addEventListener("click",function(){var n;if(1==document.getElementById("bloop__checkbox_startSend").checked){me.length=0,ge=0,n=document.getElementById("bloop__textarea").value,me=n.split("\n"),ge=me.length-1;{pe.length=0,ue=0;let t=document.getElementsByClassName("FansBarrageSwitcher"),e=document.getElementsByClassName("NobleBarrageSwitcher is-active"),o=!1;0<e.length&&(o=!0),0==t.length?(ve=!0,null!=(n=document.getElementsByClassName("MatchSystemFansBarrageSwitcher")[0])?(n.click(),t=document.getElementsByClassName("MatchSystemFansBarrageColor-item")):ve=!1):(t[0].click(),t=document.getElementsByClassName("FansBarrageColor-item"),ve=!1);for(let e=0;e<t.length;e++)-1==t[e].className.indexOf("is-lock")&&(pe.push(e),ue++);--ue,1==o&&document.getElementsByClassName("NobleBarrageSwitcher")[0].click()}ye=1==document.getElementById("bloop__checkbox_random").checked?(fe=Math.floor(Math.random()*me.length),Math.floor(Math.random()*pe.length)):fe=0,ke(),he=setTimeout(Ee,_e()),xe=setTimeout(()=>{document.getElementById("bloop__checkbox_startSend").checked=!1,clearTimeout(he)},(n=document.getElementById("bloop__text_stoptime").value,60*Number(n)*1e3))}else clearTimeout(he),clearTimeout(xe)}),document.getElementById("bloop__checkbox_tiangou").addEventListener("click",function(){var e=document.getElementById("bloop__checkbox_tiangou").checked;document.getElementById("bloop__textarea").disabled=1==e,ke()}),document.getElementById("bloop__select").onclick=function(){var e,t;0!=this.options.length&&(e=document.getElementById("bloop__textarea"),t=this.options[this.selectedIndex].text,e.value=t,e.value=e.value.replace(/\\r/g,"\r"))},document.getElementById("bloop__save").addEventListener("click",()=>{var e=document.getElementById("bloop__select"),t=document.getElementById("bloop__textarea").value;""!=t&&(we.push(t),e.options.add(new Option(t.replace(/\n/g,"\\r"),!0)),ke())}),document.getElementById("bloop__delete").addEventListener("click",()=>{var e=document.getElementById("bloop__select"),o=e.options[e.selectedIndex];if(o){let t=o.text;we=we.filter(e=>e===t),e.options.remove(e.selectedIndex),ke()}}),l=localStorage.getItem("ExSave_BarrageLoopOptions");if(null!=l){l=JSON.parse(l);"speed1"in l==0&&(l.speed1=2e3),"speed2"in l==0&&(l.speed2=3e3),"stopTime"in l==0&&(l.stopTime=5),"isTiangouMode"in l==0&&(l.isTiangouMode=!1);let t=document.getElementById("bloop__select");l.text.forEach(e=>{t.options.add(new Option(e.replace(/\r/g,"\\r"),""))}),we=l.text,document.getElementById("bloop__checkbox_changeColor").checked=l.isChangeColor,be=Boolean(l.isChangeColor),document.getElementById("bloop__text_speed1").value=l.speed1,document.getElementById("bloop__text_speed2").value=l.speed2,document.getElementById("bloop__text_stoptime").value=l.stopTime,1==l.isTiangouMode&&(document.getElementById("bloop__checkbox_tiangou").checked=l.isTiangouMode,document.getElementById("bloop__textarea").disabled=!0)}i=document.createElement("div"),i.className="fans-continue",i.innerHTML='<a class="ex-panel__icon" title="一键续牌"><img style="width: 32px;height: 32px;" src="https://gfs-op.douyucdn.cn/dygift/1705/7db9beee246848252f1c7fe916259f4e.png"/><i id="fans-continue__tip" class="ex-panel__tip"></i></a>',l=document.getElementsByClassName("ex-panel__wrap")[0],l.insertBefore(i,l.childNodes[0]),document.getElementsByClassName("fans-continue")[0].addEventListener("click",function(){var e=localStorage.getItem("ExSave_FansContinue");dl.prompt({title:"每个直播间赠送几根荧光棒？(输入0则平均赠送)",okBtn:"确定",cancelBtn:"取消",defaultValue:null!=e?e:"1",contentColor:"rgb(51,51,51)",onConfirm:function(e){if(null!=e){var t=Number(e);if(!(Number.isNaN(t)||t<0)){localStorage.setItem("ExSave_FansContinue",String(e));{var i=t;let n=0;Bt(B,t=>{var o=t.data?.list?.length||0;if(0==o)S("背包礼物为空","error");else{for(let e=0;e<o;e++)if(268==t.data.list[e].id||2358==t.data.list[e].id){n=t.data.list[e].id,count=t.data.list[e].count;break}0==n?S("没有足够的道具","error"):fetch("https://www.douyu.com/member/cp/getFansBadgeList",{method:"GET",mode:"no-cors",cache:"default",credentials:"include"}).then(e=>e.text()).then(async e=>{var o=(e=(new DOMParser).parseFromString(e,"text/html")).getElementsByClassName("fans-badge-list")[0].lastElementChild,t=o.children.length;0==i&&(i=Math.floor(count/t));for(let e=0;e<t;e++){let t=o.children[e].getAttribute("data-fans-room");await b(250).then(()=>{Ut(n,i,t).then(e=>{"success"==e.msg?S("【续牌】"+t+"赠送荧光棒成功","success"):(S("【续牌】"+t+"赠送失败 "+e.msg,"error"),console.log(t,e))}).catch(e=>{S("【续牌】"+t+"赠送失败","error"),console.log(t,e)})})}}).catch(e=>{console.log("请求失败!",e)})}})}}}},onCancel:function(){}})}),i=document.createElement("div"),i.className="ex-sign",i.innerHTML='<a class="ex-panel__icon" title="一键签到(所有关注的直播间/鱼吧/客户端/车队/活动)"><svg style="display: block;" t="1578566545259" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="12959" width="32" height="32"><path d="M698.368 80.896v114.688c0 23.552 19.968 43.008 44.032 43.008s44.032-19.456 44.032-43.008V80.896c0-23.552-19.968-43.008-44.032-43.008s-44.032 18.944-44.032 43.008zM227.328 80.896v114.688c0 23.552 19.968 43.008 44.032 43.008 24.576 0 44.032-19.456 44.032-43.008V80.896c0-23.552-19.968-43.008-44.032-43.008-24.576 0-44.032 18.944-44.032 43.008z" fill="#F96C5D" p-id="12960"></path><path d="M977.92 195.584c0-23.552-19.968-43.008-44.032-43.008h-88.576v43.008c0 55.296-46.08 100.352-102.912 100.352s-102.912-45.056-102.912-100.352v-43.008H374.272v43.008c0 55.296-46.08 100.352-102.912 100.352-56.832 0-102.912-45.056-102.912-100.352v-43.008H79.872c-24.576 0-44.032 19.456-44.032 43.008v611.328l252.928-145.92-8.192-8.192c-10.24-9.728-16.384-23.552-16.384-38.4 0-29.696 25.088-54.272 55.808-54.272 15.36 0 29.184 6.144 39.424 15.872l28.16 27.648L977.92 263.168V195.584z" fill="#F96C5D" p-id="12961"></path><path d="M329.216 278.528c-5.632 3.584-11.264 6.656-17.408 9.216 5.632-2.56 11.776-5.632 17.408-9.216zM344.064 266.24c4.608-4.608 8.704-9.728 12.8-14.848-3.584 5.632-8.192 10.24-12.8 14.848zM329.216 278.528c5.632-3.584 10.752-7.68 15.36-12.288-5.12 4.608-10.24 8.704-15.36 12.288zM449.536 664.064l220.16-214.016c10.24-9.728 24.064-15.872 39.424-15.872 30.72 0 55.808 24.064 55.808 54.272 0 14.848-6.144 28.672-16.384 38.4l-259.072 252.416c-10.24 9.728-24.064 15.872-39.424 15.872s-29.184-6.144-39.424-15.872l-121.344-118.272L35.84 806.912v104.96c0 23.552 19.968 43.008 44.032 43.008h854.016c24.576 0 44.032-19.456 44.032-43.008V263.168L387.584 603.648l61.952 60.416zM350.72 569.856c-4.608-3.072-9.216-5.12-14.336-6.656 5.12 1.024 10.24 3.584 14.336 6.656zM271.36 295.936c14.336 0 27.648-2.56 39.936-7.68-12.288 4.608-25.6 7.68-39.936 7.68z" fill="#F15A4A" p-id="12962"></path></svg><i id="ex-sign__tip" class="ex-panel__tip"></i></a>',l=document.getElementsByClassName("ex-panel__wrap")[0],l.insertBefore(i,l.childNodes[0]),i=new el(document.getElementsByClassName("ex-sign")[0]);i.click(()=>{ri(!1)}),i.longClick(()=>{ri(!0)});{let e=setInterval(()=>{0<document.getElementsByClassName("danmuTips-1ee820").length&&(clearInterval(e),document.getElementsByClassName("danmuTips-1ee820")[0].parentElement.id="Ex_BarragePanel",new G("#Ex_BarragePanel",!0,i=>{Ie(()=>{let t=!1;if(0<i.length){for(let e=0;e<i.length;e++)if("attributes"==i[e].type){t=!0;break}var e,o,n;0==t?0<(n=i[0].addedNodes).length&&"getElementsByClassName"in(n=n[0])!=0&&(o=n.getElementsByClassName("buttonGroup-de6b66")[0],e="",0<(n=n.getElementsByClassName("danmuAuthor-3d7b4a")).length)&&(e=n[0].innerText,Ce(n[0],e),Le(o),Me(o),Te(o),Ne(o),Ae(0,e)):(0<(n=document.getElementsByClassName("barragePanel__funcPanel")).length&&n[0].remove(),null!=(o=document.getElementsByClassName("danmudiv-32f498")[0])&&(e=o.getElementsByClassName("buttonGroup-de6b66")[0],n="",0<(o=o.getElementsByClassName("danmuAuthor-3d7b4a")).length&&(n=o[0].innerText,Ce(o[0],n),Le(e),Me(e),Te(e),Ne(e),Ae(0,n)),Se()))}})}),new G("#Ex_BarragePanel",!1,e=>{Ie(()=>{Se()})}))},1500);new G("#comment-dzjy-container",!1,t=>{if(!(t.length<=0||t[0].addedNodes.length<=0)){{let e=document.createElement("div");e.style.display="inline-block";t=document.getElementsByClassName("labelfisrt-407af4");0!==t.length&&((t=t[0].parentElement).appendChild(e),(e=document.createElement("p")).className="sugun-e3fbf6",e.innerText="|",t.appendChild(e),(e=document.createElement("div")).className="labelfisrt-407af4 thirdBtn-06cde5 fourBtn-0845d4",e.id="barrage-panel-tip__+1",e.innerText="+1",t.appendChild(e))}document.getElementById("barrage-panel-tip__+1").onclick=()=>{var e=document.getElementById("comment-higher-container");0<e.getElementsByClassName("ex-image-danmaku").length?E(e.getElementsByClassName("text-879f3e")[0].innerHTML.replace(/<a[^>]*><img\s+(?:.*?\s+)?src="(.*?)"[^>]*?\/?><\/a>/g,(e,t)=>`[DouyuEx图片${(e=>(e=BigInt(e)).toString(36))((t=(t=(t=t.split("/")).pop()).split("."))[0])}.${t[2]}]`)):E(e.innerText)}}})}l=!!document.getElementsByClassName("live-next-body")[0];if(!l){l=document.createElement("div");l.style="position: absolute;right: -14px;top: 32px;cursor: pointer;",l.id="ex-accountList-icon",l.innerHTML=ne+`
        <div id="ex-accountList-wrap" class="public-DropMenu-drop">
            <div class="public-DropMenu-drop-main">
                <div id="ex-accountList-iframe"></div>
                <div id="ex-accountList-iframe2"></div>
                <div id="ex-accountList-content" style="width: 300px;font-size: 14px;padding: 10px;">
                </div>
            </div>
            <i></i>
        </div>
    `,document.getElementsByClassName("Header-right")[0].appendChild(l);{let e=JSON.parse(GM_getValue("Ex_accountList")||"{}"),a={},r="";GM_cookie("list",{path:"/"},function(t){var o=[];if(null==t)document.getElementById("ex-accountList-content").innerHTML="请升级Tampermonkey版本<br/><a href='https://www.crx4chrome.com/crx/1429/'>点我升级，选择Crx4Chrome</a>";else{for(let e=0;e<t.length;e++){var n=t[e].name,i=t[e].value;"acf_nickname"==n&&(a.nickname=i),"acf_uid"==n&&(a.uid=i,r=i),"acf_avatar"==n&&(a.avatar=i),o.push(t[e])}""==r&&(a.uid="null",r="null"),a.data=o,a.update_time=String((new Date).getTime()),e[r]=a,GM_setValue("Ex_accountList",JSON.stringify(e)),ae(e)}})}le("null",I),unsafeWindow.addEventListener("message",e=>{switch(e.data){case"cleanOver":setTimeout(()=>{window.location.reload()},50);break;case"msgCleanOver":case"yubaCleanOver":case"videoCleanOver":case"czCleanOver":case"switchOver":5<=++ie&&(ie=0,setTimeout(()=>{window.location.reload()},50));break;case"deleteOver":ae(),S("【账号管理】删除完毕","success")}})}document.getElementsByClassName("ChatSend-txt")[0].addEventListener("keydown",e=>{var t=e.target,o="TEXTAREA"===t.tagName;38==e.keyCode?0==$(t)&&(C=0<C?C-1:C,ze()):40==e.keyCode?(o=(o?t.value:t.innerText).length,$(t)==o&&(C=C<De.length-1?C+1:C,ze())):13==e.keyCode&&Pe(Oe())}),document.getElementsByClassName("ChatSend-button")[0].addEventListener("click",()=>{Pe(Oe())});i=document.createElement("span"),i.className="month-cost",i.innerHTML=`
	本月消费 <span id="monthcost__money">***</span> 元
	<span class="monthcost__icon"></span>
	`,i.title="数据每日更新，根据个人中心消费数据统计",l=k(["#js-backpack-enter"]),(l=l&&l.parentElement)&&l.insertBefore(i,l.childNodes[0]),i=en();if(i&&i.addEventListener("click",()=>{Ko=1===Ko?0:1,localStorage.setItem(Yo,String(Ko)),tn(),1===Ko&&ln()}),Ko=(()=>{var e=localStorage.getItem(Yo);return null!=e&&1===Number(e)?1:0})(),tn(),1===Ko&&ln(),fetch("https://www.douyu.com/member/platform_task/effect_list",{method:"GET",mode:"no-cors",cache:"default",credentials:"include"}).then(e=>e.text()).then(async e=>{e=(e=(new DOMParser).parseFromString(e,"text/html")).getElementsByClassName("enter-wraper is-effect");if(e&&0!=e.length){var t,o,n=e[0].getElementsByClassName("show-effect-more");if(n)if(0!=n.length)for(let e=0;e<n.length;e++){var i=JSON.parse(n[e].getAttribute("data-detail"));"1646"===String(i.property_id)&&String(i.show_id_list)===String(B)&&(i=1e3*i.expire_time,(i=Math.floor((i-Date.now())/864e5))<=On)&&(o=t=void 0,(t=document.createElement("span")).className="room-vip",t.innerHTML=`
	距VIP到期 <span id="room-vip-expire-days">**</span> 天
	`,(o=(o=k(["#js-backpack-enter"]))&&o.parentElement)&&o.insertBefore(t,o.childNodes[0]),document.getElementById("room-vip-expire-days").innerText=i)}}}).catch(e=>{console.log("请求失败!",e)}),(()=>{let e="Ex_WeeklyPanel_NextTime",t=(new Date).getTime(),o=t+6048e5,n=Number(localStorage.getItem(e));return(!n||n<=t)&&(localStorage.setItem(e,o),1)})()){(l=document.createElement("div")).className="weeklypanel__panel-wrap",l.innerHTML=`
		<div class="weeklypanel__panel">
            <div class="weeklypanel__close">×</div>
			<div class="weeklypanel__content">
				<div class="weeklypanel__text">😳项目维护不易，如果觉得DouyuEx有帮助到你的话</div>
				<div class="weeklypanel__text">请点击下方链接，在右上角点个免费的⭐吧！</div>
				<div class="weeklypanel__text">以鼓励我长期维护下去，感谢使用😇</div>
				<div class="weeklypanel__text"><a href="https://github.com/qianjiachun/douyuEx" target="_blank">https://github.com/qianjiachun/douyuEx</a></div>
				<img style="width: 500px;margin-top:50px;" class="weeklypanel__img" src="https://img.douyucdn.cn/data/yuba/weibo/2022/01/18/202201181035499149780732227.png"/>
			</div>
		</div>
	`,(i=document.querySelector("body")).insertBefore(l,i.childNodes[0]);{let e=document.getElementsByClassName("weeklypanel__panel-wrap")[0];document.getElementsByClassName("weeklypanel__close")[0].addEventListener("click",()=>{e.style.display="none"})}}{{let e=setInterval(()=>{void 0!==document.getElementsByClassName("ChatBarrageCollect")[0]&&(clearInterval(e),new G(".ChatBarrageCollect",!1,e=>{var t,o=document.getElementsByClassName("ChatBarrageCollectPop-title");o?0!==o.length&&((t=document.createElement("input")).id="ex-danmaku-collect-search",t.placeholder="搜索弹幕",t.style.marginLeft="6px",o[0].appendChild(t),t.addEventListener("input",Ve)):document.getElementById("ex-danmaku-collect-search").removeEventListener("input",Ve)}))},1e3)}let t=document.getElementsByClassName("ChatSend-txt")[0],o=document.getElementsByClassName("ChatBarrageCollect")[0];t.addEventListener("keyup",()=>{var e=("string"==typeof t.value?t.value:t.innerText).length;o.style.display=25<e?"none":""}),document.getElementsByClassName("ChatSend-button")[0].addEventListener("click",()=>{o.style.display=""}),hl((e,t)=>{if(e.includes("bulletscreen/query"))return(e=JSON.parse(t)).data.list.unshift(...qe().map(e=>({content:e.content,type:2,id:e.id}))),JSON.stringify(e)}),hl((e,t,o)=>{if(e.includes("bulletscreen/add"))return 0==(e=JSON.parse(t)).error?t:(t=JSON.parse(o).content,o=t,(t=qe()).unshift({content:o,id:(new Date).getTime()}),localStorage.setItem("ExSave_DanmakuCollect",JSON.stringify(t)),e.msg="收藏成功，云收藏已达上限，将收藏至本地（由DouyuEx插件实现无限收藏）",document.querySelector(".ChatBarrageCollect-tip").click(),document.querySelector(".ChatBarrageCollect-tip").click(),JSON.stringify(e))}),hl((e,t,o)=>{var n;e.includes("bulletscreen/del")&&(e=JSON.parse(o).id,n=e,o=qe(),localStorage.setItem("ExSave_DanmakuCollect",JSON.stringify(o.filter(e=>e.id!==n))))})}hl((e,t)=>-1!==e.indexOf("group/getBindGroup")?t.replace('"group_status":4','"group_status":0'):t);{let e=0,t=setInterval(()=>{if(100<++e)clearInterval(t);else if(null!=document.getElementsByClassName("ChatSend-txt")[0]){{let e;null!=(e=document.getElementsByClassName("ChatSend-button")[0])&&(e.className="ChatSend-button"),null!=(e=document.getElementsByClassName("ChatSend-txt")[0])&&(e.maxLength=e.maxLength+20)}clearInterval(t)}},1e3)}(async()=>{await Fe(),new G(".FansMedalPanel-enter",!1,async e=>{var t,o,n=document.querySelector(".FansMedalInfo-head");n&&(t=(new Date).getDate(),new Date(Re.t).getDate()<t&&await Fe(),0!==(t=Re.list).length)&&((o=document.createElement("div")).innerHTML=`
      <div style="display: flex; align-items: center;gap: 8px;margin-top: 4px;">
        ${t.map(e=>`
          <div style="display: flex; align-items: center;">
            <img style="width: 20px; height: 20px;margin-right: 4px;" src="${e.webIcon}" alt="${e.name}">
            <span style="font-size: 12px;">${e.name}</span>
          </div>
        `).join("")}
      </div>
    `,n.appendChild(o))})})();{let r="ex-LastLiveTime-overlay",e=document.body.innerHTML,t=e.match(/show_status\\":(\d+)/)||e.match(/"show_status":(\d+)/),o=t&&"1"===t[1];if(!o){l=e.match(/show_time\\":(\d+)/)||e.match(/"show_time":(\d+)/);if(l){l=1e3*parseInt(l[1],10);let i=_("yyyy-MM-dd hh:mm:ss",new Date(l)),a=(e=>{let t="",o=(new Date).getTime(),n=new Date(e).getTime(),i=Math.floor((o-n)/1e3);return t=31536e3<i?Math.floor(i/31536e3)+"年前":2592e3<i?Math.floor(i/2592e3)+"个月前":86400<i?Math.floor(i/86400)+"天前":3600<i?Math.floor(i/3600)+"小时前":60<=i?Math.floor(i/60)+"分钟前":"刚刚"})(l),t=0,o=setInterval(()=>{if(180<++t)clearInterval(o);else{var e=document.querySelector(".room-Player"),n=0<document.getElementsByClassName("LastLiveTime").length;if(e&&n&&(clearInterval(o),!document.getElementById(r))){let t=document.createElement("div");t.id=r,t.style.position="absolute",t.style.top="0",t.style.left="0",t.style.width="100%",t.style.height="100%",t.style.display="flex",t.style.justifyContent="center",t.style.alignItems="center",t.style.zIndex="1",t.style.pointerEvents="none";n=document.createElement("style");n.textContent=`
        .ex-llt-card {
            position: relative;
            padding: 32px 64px;
            border-radius: 16px;
            background: rgba(24, 24, 24, 0.65);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 215, 0, 0.15);
            box-shadow: 0 16px 32px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1);
            text-align: center;
            font-family: "PingFang SC", "Microsoft YaHei", sans-serif;
            pointer-events: auto;
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            animation: ex-llt-fade-in 0.5s cubic-bezier(0.25, 0.8, 0.25, 1) forwards;
        }
        .ex-llt-card:hover {
            transform: translateY(-6px) scale(1.02);
            box-shadow: 0 24px 48px rgba(0, 0, 0, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 215, 0, 0.35);
            background: rgba(30, 30, 30, 0.75);
        }
        @keyframes ex-llt-fade-in {
            0% { opacity: 0; transform: translateY(20px) scale(0.95); }
            100% { opacity: 1; transform: translateY(0) scale(1); }
        }
        .ex-llt-close {
            position: absolute;
            top: 14px;
            right: 14px;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            font-size: 22px;
            line-height: 1;
            color: rgba(255, 255, 255, 0.6);
            background: rgba(255, 255, 255, 0.05);
            transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1);
        }
        .ex-llt-close:hover {
            background: rgba(255, 69, 58, 0.9);
            color: #fff;
            transform: rotate(90deg) scale(1.1);
            box-shadow: 0 4px 12px rgba(255, 69, 58, 0.4);
        }
        .ex-llt-title {
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            color: #e5b855;
            margin-bottom: 12px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.6);
            font-weight: 500;
        }
        .ex-llt-time-ago {
            font-size: 36px;
            color: #eebb4d;
            font-weight: 900;
            letter-spacing: 2px;
            margin-bottom: 10px;
            text-shadow: 0 0 15px rgba(238, 187, 77, 0.35), 0 4px 12px rgba(0,0,0,0.6);
        }
        .ex-llt-time-exact {
            font-size: 15px;
            color: rgba(229, 184, 85, 0.75);
            letter-spacing: 1px;
            font-family: monospace;
            font-weight: 500;
        }
      `,t.appendChild(n);let o=document.createElement("div");o.className="ex-llt-card",o.innerHTML=`
					<div class="ex-llt-title">
						<span style="display: inline-flex; width: 18px; height: 18px; margin-right: 8px;">
							<svg style="width: 100%; height: 100%; fill: currentColor;"><use xlink:href="#time_92d92c7"></use></svg>
						</span>
						上次开播时间
					</div>
					<div class="ex-llt-time-ago">${a}</div>
					<div class="ex-llt-time-exact">${i}</div>
                    <button type="button" class="ex-llt-close" aria-label="关闭">×</button>
				`,o.querySelector(".ex-llt-close").addEventListener("click",e=>{e.stopPropagation(),t.style.opacity="0",t.style.transition="opacity 0.3s ease",o.style.transform="translateY(10px) scale(0.95)",setTimeout(()=>t.remove(),300)}),t.appendChild(o),e.appendChild(t)}}},1e3)}}}{let t=setInterval(()=>{var e=document.querySelector(".volume-07c230");let n=document.getElementById("__video2");e&&n&&(clearInterval(t),e.addEventListener("wheel",function(e){e.preventDefault(),e.stopPropagation();var t=n.volume,o=e.deltaY<0?Math.min(t+.05,1):Math.max(t-.05,0),e=document.getElementById("__video2");if(e){e.muted=0===o,e.volume=o;try{["volume_muted_before_key","player_storage_volume_h5p_room"].forEach(e=>{var t=localStorage.getItem(e);t&&((t=JSON.parse(t)).v=o,localStorage.setItem(e,JSON.stringify(t)))})}catch(e){}}},{passive:!1,capture:!0}),n.addEventListener("volumechange",()=>{Zr(n.volume)}),Zr(n.volume))},500)}}function c(){(async()=>{Qt(),setInterval(Qt,35e3)})(),mi(),setInterval(mi,3e5),setInterval(()=>{var e=document.querySelector(".ClosingRecommend .dy-ModalRadius-close-x");e&&e.click()},1e3)}function f(){var e=document.createElement("style");e.appendChild(document.createTextNode(`
		body{position:relative;}
		#ex-accountList-wrap {
    left: -152px;
    top: -16px;
    /* max-height: 330px;
    overflow-y: scroll;
    scrollbar-width: none;
    -ms-overflow-style: none; */
    -webkit-transition: all .2s cubic-bezier(.22,.58,.12,.98);
    -o-transition: all cubic-bezier(.22,.58,.12,.98) .2s;
    -moz-transition: all cubic-bezier(.22,.58,.12,.98) .2s;
    transition: all .2s cubic-bezier(.22,.58,.12,.98);
    -webkit-transform-origin: 80% 0;
    -moz-transform-origin: 80% 0;
    -ms-transform-origin: 80% 0;
    -o-transform-origin: 80% 0;
    transform-origin: 80% 0;
    -webkit-animation: scale-in-ease .5s cubic-bezier(.22,.58,.12,.98);
    -moz-animation: scale-in-ease cubic-bezier(.22,.58,.12,.98) .5s;
    -o-animation: scale-in-ease cubic-bezier(.22,.58,.12,.98) .5s;
    animation: scale-in-ease .5s cubic-bezier(.22,.58,.12,.98);
}

/* #ex-accountList-wrap::-webkit-scrollbar {
    display: none;
} */

.ex-accountList-item {
    padding: 10px;
    display: flex;
    border-radius: 10px;
    align-items: center;
}
.ex-accountList-item:hover {
    background-color: rgb(244,244,244);
}

#ex-accountList-iframe {
    display: none;
}
#ex-accountList-iframe2 {
    display: none;
}

#ex-accountList-item-add {
    padding: 10px;
    text-align: center;
    margin-bottom:0px;
    border-radius: 10px;
}

#ex-accountList-item-add:hover {
    background-color: rgb(244,244,244);
}

.ex-accountList-item__imgWrap {
    flex: 0 0 25%;
}

.ex-accountList-item__img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
}

.ex-accountList-item__name {
    line-height: 50px;
    flex: 0 0 55%;
}

.ex-accountList-item__btn {
    height: 30px;
    width: 50px;
    border-radius: 10px;
    align-items: center;
    flex: auto;
    text-align: center;
    line-height: 28px;
    color: white;
    background-color: rgb(245,108,108);
}

.ex-accountList-item__btn:hover {
    background-color: rgb(247,137,137);
}

#ex-accountList-icon:hover > #ex-accountList-wrap {
    display: block;
}

#ex-accountList-content {
    background-color: white;
}#ex-audio-line {
    cursor: pointer;
}

.live-next-body #ex-audio-line {
    margin-left: 4px;
}.bag-info {
    position: absolute;
    background-color: rgba(0, 0, 0, 0.6);
    color: white;
    width: 20px;
    font-weight: 800;
    height: 20px;
    text-align: center;
    z-index: 10;
    bottom: 0;
}

.bag-button {
    color: rgb(255, 255, 255);
    text-align: center;
    height: 15px;
    line-height: 15px;
    cursor: pointer;
    margin-left: 5px;
    background: rgb(70, 171, 255);
    border-radius: 9px;
    padding: 0px 10px;
    right: 20px;
}.bloop {
	background-color: rgba(255,255,255,0.9);
	width: 100%;
	height: 200px;
	position: relative;
	bottom: 200px;
	display: none;
	z-index: 1428;
	color: #333;
}

.bloop__switch {
	position: absolute;
	right: 0;
	bottom: 0;
}

.bloop__mode {
	display: inline-block;
}

#bloop__select {
	width: 150px;
}.barragePanel__funcPanel {
    position: absolute;
    width: 232px;
    height: 270px;
    display: block;
    background: white;
    overflow-y: scroll;
}

.barragePanel__funcPanel::-webkit-scrollbar {display:none}
.barragePanel__muteTime {
    /* position: absolute;
    left: 25px;
    top: 123px; */
    z-index: 5;
}

.danmuContent-25f266 {
    pointer-events: auto !important;
}

.thirdBtn-06cde5, .fourBtn-0845d4 {
    /* 加宽按钮方便点击 */
    margin-left: 0px !important;
    margin-right: 0px !important;
    padding: 0 17px !important;
}#copy-real-live {
    cursor: pointer;
}
.Title-row-span, .Title-row-icon  {
    display: flex;
    align-items: center;
    justify-content: center;
}

.Title-row-icon {
    margin-right: 4px;
}

.live-next-body #copy-real-live {
    margin-left: 4px;
}.ChatBarrageCollect .TagItem {
  height: auto !important;
}

.ChatBarrageCollect .TagItem-txt {
  overflow: auto !important;
  white-space: normal !important;
  text-overflow: clip !important;
}.ChatToolBar-DanmakuTail {
    display: inline-block;
    vertical-align: middle;
    width: 18px;
    height: 18px;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    margin-right: 8px;
    color: #bbb;
    cursor: pointer;
}

[data-mantine-color-scheme=dark] .ChatToolBar-DanmakuTail-tip {
    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAABGdBTUEAALGPC/xhBQAACklpQ0NQc1JHQiBJRUM2MTk2Ni0yLjEAAEiJnVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/stRzjPAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAJcEhZcwAACxMAAAsTAQCanBgAAAIxSURBVFiF1dixS1tRFMfxT16fuomDHcQs4h8giMVFXPo/lDpI5y710T+gf0K5dOlcuhUKHZ2Di7QInUW6JDjYIXSLDulwk5Imz5f3EpO0P8jy3rn3fDnv3HNzTq3b7RpWlmVL2MUeDlDHFpaxipWRRfnq4Bfavd8VzvAd5yGEu+EFtWGgLMs28ArH2CzpuIo6+IlPeBtCaOYC9aJyiA8zAsnTDY7Q6EcrGXh5iPdzhIHHPZ+H/Qe1brcry7I6LnoGi1ALT0II14/a7fYS3uDpgmCIB+Xu9PS0kWIfz4qsQwi1h/KcZdnosY46xpcEO1ifB8yY/Taxl4h1pmxdmbUOUmyXtS4Id6EqRLmeYm0GG0+qrUQFoIfQmCgvJ+KR+xdgYDVVIaGLNhz3OUvm30paFqas42lVGaiKJjmVlYGyLOsWRWnS0jAx0KDTPLBpc+n/yqE5Xap/aaIcGn42CH6f4zI2EwENb17l3aDNfVCVgOZwl0nFLmBstR533IvWVTDvpGLfNPJfOs/5tPlRwu5Xgtti6Gq6L4olo9tO8cMDtz5T5Fo7QXOc1bTXQYX9rhKx157aQVnoArsOzmonJyf7+Gy+HWueWnieiB3rxwXDEIcP5/1WegNfLS5KN9gNITQTCCFc4wUuFwBziaP+WGZw+tHAS5F2Xmr1fDb6D/IGVnW8Fvv9dbPpalti3r7rfZ0/GgHqQS2JQ4gdsdXeFvu3NZON9G7FAtwUy8w3XOSN9H4DKHngjnga2TgAAAAASUVORK5CYII=) 50% / 18px 18px no-repeat;
}

.ChatToolBar-DanmakuTail-tip {
    width: 18px;
    height: 18px;
    text-align: center;
    line-height: 18px;
    border-radius: 4px;
    font-size: 12px;
    color: #fff;
    cursor: pointer;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAMAAADW3miqAAAAPFBMVEUAAADKy8zKy8zExMzKy83Ky83KzMzKzM7Kys3Ky8zKy83Jy8zJy83Ky8zLzMzJzMzIyM3MzMzKzMzKy8zUpkOsAAAAE3RSTlMA5PgF2qdrQ+rqysOOhzw3HBnqZkz8cgAAAN5JREFUOMuNlEkOAyEMBNs2y+xL/P+/JgoJaGCAqZOFSk0fLOOL7M7ONLBGeDCTdZsgcq6kdzAtBwLiSauMPoR5ow2Mx4dj1CZ0ArJoh1Ww/Quh5Be1w3F0apaD1a5kMSVJLyRphuknEYaGpIEXuC7pD4YWnaITuUiIdKRkVCRNRlUq+te+a0p4Ujy9ZkMpIaeUgJrEld6aYAxZJS2nF+hGwnUwmHOp/HSCzffybn1dubyZww47aQfaIGtPWgQ4O1Hj8fRgQPzYKOQFgWMhvlfWExHZnJ3M9RzSbN0eYt4fdzsuAVjiHAAAAABJRU5ErkJggg==) 50% / 18px 18px no-repeat;
}

.ChatToolBar-DanmakuTail-tip-active,
.ChatToolBar-DanmakuTail-tip:hover {
    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAMAAADW3miqAAAAPFBMVEUAAAD6aDP7ZTD2cUHxeU/pjGvmkHPfjnH4azj4bDruf1fshWHrhmLpjW3njm3kk3/ugFnugVn/XSP+YCg/+VboAAAAEnRSTlMA/P3z4XQyCPr5za2namIOx8bnayGzAAAA3klEQVQ4y43U2w6EIAxF0dNyc7xP+///Ook6EEHA/UTMSukDEUdhna0hVokpD8ZOy4aY/5I8pTT6iwRHUo1dOJD7SKOPO+5iaUYe2EbptAcs/4VQdo1aMWk0NTXDShdZmITkVkIGQ38SgRtIzhhaR3KlkGKnaGI3hFgHJVFBkkQVFfvXrmsivFk8fc0OJUJeiYAa0sreklJwtpKUJwY9INwPA0yOyksNbP4un57vXD7ezOiElaQTLQh7D40b4Duj2L/9YSA4bizkAs78SPpMdo/YtkzWDPffIRk7r+eYH6dAOJwNbfZEAAAAAElFTkSuQmCC) 50% / 18px 18px no-repeat;
}


.ChatToolBar-DanmakuTail-Panel {
    background-color: rgba(255, 255, 255, 0.9);
    width: 100%;
    height: 140px;
    position: relative;
    display: none;
    z-index: 1015;
    color: #333;
}

.ChatToolBar-DanmakuTail-Panel__cell {
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    padding: 10px 16px;
    overflow: hidden;
    color: #323233;
    font-size: 14px;
    line-height: 24px;
    background-color: #fff;
    border-bottom: 1px solid rgba(0, 0, 0, 0.2);
    flex-wrap: wrap;
    -webkit-flex-wrap: wrap;
}

.ChatToolBar-DanmakuTail-Panel__cell_title {
    flex: 1;
    -webkit-box-flex: 1;
}

.ChatToolBar-DanmakuTail-Panel__cell_option {
    text-align: right;
}

.ChatToolBar-DanmakuTail-Panel__cell_switch {
    float: right;
}

.ChatToolBar-DanmakuTail-title {
    margin: 0 10px;
    font-size: 16px;
    font-weight: bold;
}

.DanmakuTail-input {
    margin: 10px;
    width: calc(100% - 20px);
    height: 2.2em;
}

.DanmakuTail-checkbox-label,
.DanmakuTail-option-label {
    margin: 10px;
    width: calc(100% - 20px);
    display: block;
    text-align: right;
}

.EnergyBarrageIcon {
    margin-right: 8px;
}.ex-icon {
	display: inline-block;
	vertical-align: middle;
	margin-right: 8px;

	-moz-user-select:none; /*火狐*/
    -webkit-user-select:none; /*webkit浏览器*/
    -ms-user-select:none; /*IE10*/
    -khtml-user-select:none; /*早期浏览器*/
    user-select:none;
}

.ex-icon a {
    display: flex;
    justify-items: center;
    align-items: center;
}

.ex-icon svg:hover {
    transform: scale(1.1);
}.ex-panel {
	position: absolute;
	bottom: 32px;
	right: 0px;
	background-color: rgba(255,255,255,0.9);
	border: 2px rgb(234,173,26) solid;
	z-index: 1428;
	user-select: none;
	display: none;
	overflow: visible;
}

.ex-panel__close {
	position: absolute;
	top: -9px;
	right: -9px;
	z-index: 3;
	width: 18px;
	height: 18px;
	padding: 0;
	margin: 0;
	border: none;
	border-radius: 50%;
	background: rgba(255, 255, 255, 0.95);
	color: #64748b;
	font-size: 14px;
	line-height: 16px;
	text-align: center;
	cursor: pointer;
	box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
	transition: color 0.15s ease, background-color 0.15s ease;
}

.ex-panel__close:hover {
	color: #fff;
	background: #f60;
}

.ex-panel__close:focus-visible {
	outline: 2px solid #ff7700;
	outline-offset: 1px;
}

/* 隐藏礼物栏时挂到播放器层，位置由 ExPanel_updateFloatingPosition 计算（视频工具条上方） */
.ex-panel.ex-panel--floating {
	position: fixed;
	z-index: 10000;
}
.ex-panel__wrap {
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: 100%;
	position: relative;
	z-index: 1;
}
.ex-panel__icon {
	margin: 0 10px;
	display: block;
	position: relative;
	padding: 5px;
	transition: 0.5s;
}
.ex-panel__icon:hover {
	transform: scale(1.15);
}
.ex-panel__tip {
	display:none;
	background:#f00;
	border-radius:50%;
	width:8px;
	height:8px;
	top:0px;
	right:0px;
	position:absolute;
}

/* 新版斗鱼右侧弹幕Panel的bottom */
.live-next-body .layout-Player-chat>* {
	bottom: 0 !important;
}.extool {
	background-color: rgba(255,255,255,0.9);
	width: 100%;
	max-height: 320px;
	position: relative;
	bottom: 200px;
	display: none;
	z-index: 1428;
	color: #333;
	box-sizing: border-box;
	padding: 8px 10px;
	overflow: auto;
	font-size: 13px;
	line-height: 22px;
}

.extool[style*="display: block"] {
	display: flex !important;
	flex-wrap: wrap;
	gap: 8px 10px;
	align-items: flex-start;
}

.extool > div:not(.ex_giftAnimation):not(.extool__close) {
	background: rgba(255,255,255,0.82);
	border: 1px solid rgba(0,0,0,0.10);
	border-radius: 10px;
	padding: 10px 12px 12px;
	box-sizing: border-box;
	box-shadow: 0 2px 10px rgba(0,0,0,0.06);
	display: flex;
	flex-wrap: wrap;
	gap: 6px 10px;
	align-items: center;
	min-width: 220px;
}

.extool__close {
	position: absolute;
	top: 8px;
	right: 8px;
	width: 26px;
	height: 26px;
	border-radius: 8px;
	display: flex;
	align-items: center;
	justify-content: center;
	cursor: pointer;
	user-select: none;
	background: rgba(0,0,0,0.06);
	color: rgba(0,0,0,0.72);
	font-size: 18px;
	line-height: 26px;
	z-index: 60;
}

.extool__close:hover {
	background: rgba(0,0,0,0.10);
}

.extool__treasure,
.extool__sendgift {
	flex: 1 1 720px;
}
.extool__autofish {
	flex: 1 1 520px;
}
.extool__redpacket_room,
.extool__gold,
.extool__clearbag,
.extool__tabswitch,
.extool__p2p,
.extool__fullscreen {
	flex: 1 1 260px;
}

.extool__treasure::before,
.extool__sendgift::before,
.extool__autofish::before,
.extool__redpacket_room::before,
.extool__gold::before,
.extool__clearbag::before,
.extool__tabswitch::before,
.extool__p2p::before,
.extool__fullscreen::before {
	display: block;
	width: 100%;
	content: "";
	font-weight: 700;
	font-size: 12px;
	letter-spacing: .4px;
	color: rgba(0,0,0,0.72);
	padding-bottom: 6px;
	margin-bottom: 2px;
	border-bottom: 1px dashed rgba(0,0,0,0.12);
}
.extool__treasure::before { content: "宝箱"; }
.extool__sendgift::before { content: "送礼"; }
.extool__autofish::before { content: "钓鱼"; }
.extool__redpacket_room::before { content: "礼物红包"; }
.extool__gold::before { content: "幻神/礼物"; }
.extool__clearbag::before { content: "背包"; }
.extool__tabswitch::before { content: "标签/切换"; }
.extool__p2p::before { content: "网络"; }
.extool__fullscreen::before { content: "播放器"; }

.extool label {
	white-space: nowrap;
	margin-right: 8px;
	line-height: 22px;
}
.extool input[type="text"] {
	padding: 2px 6px;
	border: 1px solid rgba(0,0,0,0.18);
	border-radius: 6px;
	outline: none;
	background: rgba(255,255,255,0.95);
	color: black;
}
.extool input[type="checkbox"], .extool input[type="radio"] {
	vertical-align: middle;
	margin-right: 4px;
}
.extool input[type="button"] {
	border: 1px solid rgba(0,0,0,0.18);
	border-radius: 8px;
	padding: 2px 10px;
	background: linear-gradient(#ffffff, #f4f6f8);
	cursor: pointer;
	color: black;
}
.extool input[type="button"]:hover {
	background: linear-gradient(#ffffff, #e9eef3);
}
.extool input[type="button"]:active {
	transform: translateY(1px);
}
.extool a {
	text-decoration: none;
}
.extool .extool__hint {
	margin-top: 6px;
	color: #666;
	font-size: 12px;
}

/* 兼容某些模块里使用 br 分行的写法，让它在 flex 下表现更一致 */
.extool br {
	flex-basis: 100%;
	width: 0;
	height: 0;
}

.extool__switch {
	position: absolute;
	right: 0;
	bottom: 0;
}
.extool__bsize,.extool__sendgift {
	margin-bottom: 5px;
}
/* 卡片内部已改为 flex，这里不再强制 inline-block */
.ex_giftAnimation {
	width: 100%;
	height: 100%;
	position: absolute;
	z-index: 50;
	pointer-events: none;
}
.text-879f3e {
  height: auto !important;
  max-height: 48px !important;
}

.ex-image-danmaku {
  height: 48px;
  border-radius: 6px;
  margin: 0 4px;
}

.danmuContent-25f266 .ex-image-danmaku {
  max-height: 32px;
}.barrageSpeed {
    position: absolute;
    right: 10px;
    top: -20px;
    color: rgba(0,0,0,0.5);
    cursor: default;
    z-index: 0;
}/* 自动抢红包面板样式 */
.count_bp__panel {
    width: 100%;
    display: none; /* 默认隐藏 */
    margin-top: 4px;
}

/* 标题样式 */
#count_bp__title {
    cursor: pointer;
    user-select: none;
    color: royalblue;
}

/* 输入框样式 */
#count_bp__add_input,
#count_bp__original_input {
    width: 35px;
}

/* 选项间距 */
.redpacket__option {
    margin-top: 5px;
}.enter__panel {
    width: 100%;
    display: none;
    margin-top: 4px;
}
#enter__title {
    cursor: pointer;
    user-select: none;
    color: royalblue;
}
#enter__select {
    width: 190px;
}

.enter__option {
    margin-top: 5px;
}

#enter__enterId {
    width: 40px;
}

#enter__reply {
    width: 150px;
}

#enter__word {
    width: 140px;
}

#enter__level {
    width: 25px;
    text-align: center;
}

#enter__export {
    cursor: pointer;
    color: royalblue;
    margin-left: 10px;
}

#enter__import {
    cursor: pointer;
    color: royalblue;
    margin-left: 5px;
}.gift__panel {
    width: 100%;
    display: none;
    margin-top: 4px;
}
#gift__title {
    cursor: pointer;
    user-select: none;
    color: royalblue;
}
#gift__select {
    width: 113px;
}

.gift__option {
    margin-top: 5px;
}

#gift__giftId {
    width: 40px;
}

#gift__reply {
    width: 150px;
}

#gift__export {
    cursor: pointer;
    color: royalblue;
    margin-left: 10px;
}

#gift__import {
    cursor: pointer;
    color: royalblue;
    margin-left: 5px;
}.livetool {
	background-color: rgba(255,255,255,0.9);
	width: 100%;
	height: 290px;
	top: -600px;
	position: relative;
	bottom: 290px;
	display: none;
	z-index: 1428;
}

.livetool__cell {
	position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    box-sizing: border-box;
    width: 100%;
    padding: 10px 16px;
    overflow: hidden;
    color: #323233;
    font-size: 14px;
    line-height: 24px;
	background-color: #fff;
	border-bottom: 1px solid rgba(0,0,0,0.2);
	flex-wrap: wrap;
    -webkit-flex-wrap: wrap;
}

.livetool__cell_title {
	flex: 1;
    -webkit-box-flex: 1;
}

.livetool__cell_option {
	text-align: right;
}

.livetool__cell_switch {
	float: right;
}.mute__panel {
    width: 100%;
    display: none;
    margin-top: 4px;
}
#mute__title {
    cursor: pointer;
    user-select: none;
    color: royalblue;
}
#mute__idlist {
    cursor: pointer;
    color: royalblue;
    margin-left: 10px;
}
#mute__export, #mute__import {
    cursor: pointer;
    color: royalblue;
    margin-left: 5px;
}
#mute__select {
    width: 110px;
}

.mute__option {
    margin-top: 5px;
}

#mute__word {
    width: 70px;
}

#mute__count {
    width: 30px;
}

#mute__time {
    width: 65px;
}.exRankPoint {
    position: absolute;
    right: 16px;
}

.exRankPoint--top {
    position: absolute;
    bottom: -12px;
    right: 0;
    left: 0;
}/* 自动抢红包面板样式 */
.redpacket__panel {
    width: 100%;
    display: none; /* 默认隐藏 */
    margin-top: 4px;
}

/* 标题样式 */
#redpacket__title {
    cursor: pointer;
    user-select: none;
    color: royalblue;
}

/* 输入框样式 */
#redpacket__delay,
#redpacket__cd {
    width: 35px;
}

/* 选项间距 */
.redpacket__option {
    margin-top: 5px;
}.reply__panel {
    width: 100%;
    display: none;
    margin-top: 4px;
}
#reply__title {
    cursor: pointer;
    user-select: none;
    color: royalblue;
}
#reply__select {
    /* width: 190px; */
    width: 100px;
}

#reply__time {
    width: 35px;
}

.reply__option {
    margin-top: 5px;
}

#reply__word {
    width: 70px;
}

#reply__reply {
    width: 147px;
}

#reply__export {
    cursor: pointer;
    color: royalblue;
    margin-left: 10px;
}

#reply__import {
    cursor: pointer;
    color: royalblue;
    margin-left: 5px;
}.livetool__Treasure {
    width: 100%;
    position: relative;
    z-index: 999;
}.vote__panel {
    width: 100%;
    display: none;
    margin-top: 4px;
}
#vote__title {
    cursor: pointer;
    user-select: none;
    color: royalblue;
}
#vote__select {
    width: 100px;
}

.vote__option {
    margin-top: 5px;
}

#vote__theme {
    width: 70px;
}

#vote__options {
    width: 133px;
}

#vote__time {
    width: 35px;
}

#vote__show-result {
    cursor: pointer;
    color: royalblue;
    margin-left: 10px;
}

.vote__result {
    position: absolute;
    top: 0px;
    width: 300px;
    background: rgba(255,255,255,0.85);
    left: 0px;
    z-index: 999;
    padding: 5px;
    border-radius: 10px;
    user-select: none;
    display: none;
    color: #333;
}

#vote__result-theme {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
}
#vote__result-close {
    position: absolute;
    top: 5px;
    right: 10px;
    font-size: 14px;
    cursor: pointer;
    color: gray;
}

.vote__option-wrap {
    margin-bottom: 10px;
}

.vote__option-choice {
    display: inline-block;
    font-size: 14px;
}

.vote__option-num {
    float: right;
    font-size: 14px;
}

.vote__progress {
    width: 100%;
    background-color: #ddd;
    border-radius: 10px;
}

.vote__progress-bar {
    width: 0%;
    height: 14px;
    background-color: #4CAF50;
    text-align: center;
    line-height: 30px;
    border-radius: 10px;
}

.exlottery {
	background-color: rgba(255,255,255,1);
	width: 100%;
	height: 250px;
	position: relative;
	bottom: 250px;
	display: none;
	z-index: 1428;
    overflow: auto;
    padding: 0 10px;
    box-sizing: border-box;
}

.lottery__nodata {
    z-index: 998;
    position: absolute;
    left:50%;
    top:50%;
    transform: translate(-50%, -50%);
    color: #606266;
}

.lottery__wrap {
    display: flex;
    flex-direction: column;
    z-index: 999;
}

.lottery__a:hover .lottery__item {
    background-color: rgb(244,244,244);
}

.lottery__item {
    display: flex;
    padding: 5px 0;
    border-bottom: 1px solid #d0d0d0;
    color: #606266;
}

.lottery__img img {
    width: 150px;
    border-radius: 5px;
}

.lottery__anchor {
    position: absolute;
    background-color: rgba(255,255,255,0.9);
    border-radius: 5px 0px 5px 0px;
}

.lottery__info {
    display: flex;
    justify-content: space-evenly;
    flex-direction: column;
    margin-left: 10px;
    overflow: hidden;
}

.lottery__prize {
    white-space: nowrap;
    text-overflow: ellipsis;
    word-break: break-all;
    font-size: 14px;
}

.lottery__expireTime {
    position: absolute;
    margin-top: -18px;
    background-color: rgba(255,255,255,0.9);
    border-radius: 0px 5px 0px 5px;
}

 /*滚动条样式*/
.exlottery::-webkit-scrollbar {
    width: 4px;    
}
.exlottery::-webkit-scrollbar-thumb {
    border-radius: 10px;
    box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
    background: rgba(0,0,0,0.2);
}
.exlottery::-webkit-scrollbar-track {
    box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
    border-radius: 0;
    background: rgba(0,0,0,0.1);
}

.lottery__func {
    display: flex;
    justify-content: space-between;
    margin-top: 5px;
    user-select: none;
    border-bottom: 1px solid #d0d0d0;
}

.lottery__notice,#lottery-refresh {
    cursor: pointer;
    color: #606266;
}.miniprogram__panel {
    position: absolute;
    right: 43px;
    bottom: 100px;
    animation: move-in 0.75s;
    z-index: 101;
    text-align: center;
    display: none;
}
.miniprogram__wrap {
    overflow: hidden;
    background-color: white;
    border-radius: 5%;
    width: 200px;
    box-shadow: 0px 2px 20px 0px #888888;
    font-size: 14px;
}

.miniprogram__triangle {
    width: 0px;
    height: 0px;
    border-color: white transparent transparent transparent;
    border-style: solid;
    border-width: 10px;
    position: absolute;
    left: 100px;
}.month-cost {
    margin-right: 5px;
    cursor: default;
    -moz-user-select:none;/*火狐*/
    -webkit-user-select:none;/*webkit浏览器*/
    -ms-user-select:none;/*IE10*/
    -khtml-user-select:none;/*早期浏览器*/
    user-select:none;
    display: inline-block;
    vertical-align: middle;
}

.monthcost__icon {
    position: relative;
    top: 3px;
    cursor: pointer;
    margin-left: 3px;
}/* 隐藏登录的提示 */
.multiBitRate-da4b60 {
  display: none !important;
}.exVideoDiv {
    width: 500px;
    height: 250px;
    background-color: rgba(255, 255, 255, 0);
    position: absolute;
    z-index: 1428;
}

.exVideoPlayer {
    width: 100%;
    height: 100%;
    cursor: move;
}

.exVideoScale {
    width: 10px;
    height: 10px;
    overflow: hidden;
    cursor: se-resize;
    position: absolute;
    right: 0;
    bottom: 0;
    background-color: rgb(231, 57, 57);
}

.exVideoInfo {
    width: 100%;
    height: 30px;
    background-color: gray;
    position: absolute;
    top: -30px;
    line-height: 30px;
}

.exVideoClose {
    width: 30px;
    float: right;
    color: white;
}

.exVideoQn, .exVideoCDN {
    margin-left: 5px;
}

.exVideoRID {
    margin: 0px 5px;
    font-weight: 800;
    font-size: medium;
}

#popup-player__prompt {
    display: none;
}

.postbird-box-header {
    width: auto !important;
}

.postbird-box-dialog {
    color: #333;
}.real-audience {
    cursor: pointer;
    display: flex;
    padding: 0 7px;
    line-height: 33px;
    color: rgb(153, 153, 153);
}

#Ex_EnterYuba {
    width: 100%;
}

.Title-anchorPic-bottom i{
    display: none !important;
}

#real-audience__total, #real-audience__barrage, #real-audience__money_yc, #real-audience__noble {
    margin-left: 2px;
}
/* #refresh-video {
    float: left;
    width: 24px;
    height: 24px;
    margin-right: 5px;
    cursor: pointer;
    background-size: contain;
} */

.refresh-barrage {
    display: inline-flex;
    align-items: center;
    vertical-align: top;
    margin: 0 2px;
    padding: 0 8px;
    height: 22px;
    line-height: 21px;
    background-color: #fff;
    border: 1px solid #e5e4e4;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    cursor: pointer;
    user-select: none;
}

.refresh-barrage.ex-active {
    background: linear-gradient(180deg, rgb(38, 169, 235), rgb(18, 150, 219));
    border-color: rgb(18, 150, 219);
    box-shadow: 0 0 0 2px rgba(18, 150, 219, .22), 0 8px 16px rgba(18, 150, 219, .28);
    font-weight: 700;
}

.refresh-barrage.ex-active:hover {
    box-shadow: 0 0 0 2px rgba(18, 150, 219, .28), 0 10px 18px rgba(18, 150, 219, .36);
}

.refresh-barrage.ex-active::after {
    content: "";
    width: 6px;
    height: 6px;
    margin-left: 6px;
    border-radius: 999px;
    background: rgba(255, 255, 255, .95);
    box-shadow: 0 0 0 2px rgba(255, 255, 255, .22);
}

.live-next-body .refresh-barrage {
    background-color: var(--front-background-color);
    border: 1px solid var(--front-border-color);
}

#refresh-barrage__svg {
    vertical-align: middle;
}

.top-0-important {
    top: 0 !important;
}
.room-vip {
  -moz-user-select:none;/*火狐*/
  -webkit-user-select:none;/*webkit浏览器*/
  -ms-user-select:none;/*IE10*/
  -khtml-user-select:none;/*早期浏览器*/
  user-select:none;
  vertical-align: middle;
  position: absolute;
  left: 12px;
}.repeated-danmaku {
  opacity: 0 !important;
  pointer-events: none !important;
  visibility: hidden !important;
}

.danmu-fbb2a3 > div {
  transition: font-size 0.5s ease !important;
}

.comment-dzjy-container > div {
  z-index: 99 !important;
}#ex-camera {
    background: rgba(0,0,0,0.7);
    position: absolute;
    right: 20px;
    bottom: 240px;
    z-index: 10;
    width: 60px;
    height: 60px;
    cursor: pointer;
    -webkit-border-radius: 50%;
    -moz-border-radius: 50%;
    border-radius: 50%;
    cursor: pointer;
    display: none;
    justify-content: center;
    align-items: center;
    border: 2px solid #2d2c2c;
    box-sizing: border-box;
}

#ex-camera:hover > svg > path {
    fill: rgb(252, 199, 84);
}

#ex-camera:active > svg > path {
    fill: rgb(253, 60, 60);
}

#ex-camera-close {
    position: absolute;
    top: -8px;
    right: -8px;
    width: 20px;
    height: 20px;
    background: rgba(0,0,0,0.8);
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    color: #fff;
    font-size: 12px;
    line-height: 1;
    border: 1px solid rgba(255,255,255,0.3);
    z-index: 11;
}

#ex-camera-close:hover {
    background: rgba(253, 60, 60, 0.9);
}
#ex-cinema:hover > .cinema__wrap {
    display: block;
}

.cinema__wrap {
    display: none;
    margin: 0;
    padding: 0;
    border: 1px solid #e5e5e5;
    background: #fff;
    position: absolute;
    left: 199px;
    min-width: 100px;
    top: 130px;
}


.cinema__panel {
    position: absolute;
    border: 1px solid #000;
    border-radius: 4px;
    transform: translateY(calc(-4px - 100%)) translateX(-50%);
    left: 33%;
    background-color: #000;
    opacity: .75;
    width: 70px;
}

.cinema__panel li {
    padding: 0 2px;
    white-space: nowrap;
    color: #fff;
    text-align: center;
    cursor: pointer;
}

.cinema__panel li:hover {
    background-color: rgb(85, 85, 85);
}  /* Joysound 控件已并入 VideoToolbarMenu，样式见 VideoToolbarMenu.css */
#exVideoDivFake {
  display: none;
}


#ex-metadata:hover > .metadata__wrap {
  display: block;
}

.metadata__wrap {
  display: none;
  margin: 0;
  padding: 0;
  border: 1px solid #e5e5e5;
  background: #fff;
  position: absolute;
  left: 199px;
  min-width: 100px;
  top: 0px;
  white-space: nowrap;
  color: black;
}


.metadata__panel {
  position: absolute;
  border: 1px solid #000;
  border-radius: 4px;
  transform: translateY(calc(-4px - 100%)) translateX(-50%);
  left: 33%;
  background-color: #000;
  opacity: .75;
  width: 70px;
}

.metadata__panel li {
  padding: 0 2px;
  white-space: nowrap;
  color: #fff;
  text-align: center;
  cursor: pointer;
}

.metadata__panel li:hover {
  background-color: rgb(85, 85, 85);
}  #ex-pip-menu-panel.ex-pip-menu-root {
    position: fixed;
    z-index: 10001;
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    transition: opacity 0.12s ease, visibility 0.12s ease;
}

#ex-pip-menu-panel.ex-pip-menu-root.is-visible {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
}

#ex-pip-menu-panel.ex-pip-menu-root::after {
    content: "";
    position: absolute;
    left: 0;
    right: 0;
    top: 100%;
    height: 8px;
}

.ex-pip-menu {
    box-sizing: border-box;
    width: 196px;
    padding: 4px 0;
    border-radius: 6px;
    font-family: "Microsoft YaHei", "PingFang SC", -apple-system, sans-serif;
    font-size: 12px;
    color: #e8e8e8;
    background: #2c2c30;
    border: 1px solid #1a1a1c;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.45);
    user-select: none;
    pointer-events: auto;
}

.ex-pip-menu__list {
    margin: 0;
    padding: 0;
    list-style: none;
}

.ex-pip-menu__list > li + li {
    border-top: 1px solid rgba(255, 255, 255, 0.06);
}

#ex-pip-menu-panel.ex-pip-menu-root.is-measuring {
    opacity: 0;
    pointer-events: none;
}

.ex-pip-opt {
    display: flex;
    align-items: center;
    gap: 10px;
    width: 100%;
    margin: 0;
    padding: 8px 12px;
    border: none;
    border-radius: 0;
    background: transparent;
    color: inherit;
    text-align: left;
    cursor: pointer;
    outline: none;
    line-height: 1.4;
}

.ex-pip-opt:hover {
    background: rgba(255, 255, 255, 0.06);
}

.ex-pip-opt:focus-visible {
    background: rgba(255, 255, 255, 0.08);
    outline: 1px solid rgba(255, 255, 255, 0.2);
    outline-offset: -1px;
}

.ex-pip-opt__icon {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    color: #9a9aa2;
}

.ex-pip-opt__icon svg {
    display: block;
    width: 24px;
    height: 24px;
}

.ex-pip-opt--ex .ex-pip-opt__icon {
    color: #c4c4cc;
}

.ex-pip-opt--ex:hover .ex-pip-opt__icon {
    color: #e0e0e6;
}

.ex-pip-opt__body {
    flex: 1;
    min-width: 0;
}

.ex-pip-opt__row {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 8px;
}

.ex-pip-opt__label {
    font-size: 12px;
    color: #f0f0f0;
}

.ex-pip-opt__mark {
    flex-shrink: 0;
    font-size: 11px;
    color: #8c8c94;
}

.ex-pip-opt--ex .ex-pip-opt__mark {
    color: #ff7f3a;
}

.ex-pip-opt__hint {
    display: block;
    margin-top: 2px;
    font-size: 11px;
    color: #7a7a82;
    line-height: 1.35;
}

.ex-pip-opt--ex:hover .ex-pip-opt__mark {
    color: #ff9555;
}

@media (prefers-reduced-motion: reduce) {
    .ex-pip-opt,
    #ex-pip-menu-panel.ex-pip-menu-root {
        transition: none;
    }
}
.filter__wrap {
    display: none;
    position: relative;
    border-radius: 4px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

.filter__panel {
    position: absolute;
    border: 1px solid #000;
    border-radius: 4px;
    transform: translateY(calc(-4px - 100%)) translateX(-50%);
    left: 33%;
    background-color: #000;
    opacity: .75;
    width: 300px;
    padding-top: 10px;
    padding-left: 10px;
    padding-right: 10px;
}

.filter__panel li {
    padding: 0 2px;
    white-space: nowrap;
    color: #fff;
    text-align: center;
    cursor: pointer;
}

.filter__panel li:hover {
    background-color: rgb(85, 85, 85);
}


.filter__scroll {
    width: 100%;
    height: 5px;
    background: #ccc;
    position: relative;
    display: inline-block;
}

.filter__scroll-bar {
    width: 15px;
    height: 15px;
    background: #369;
    position: absolute;
    top: -5px;
    left: 100px;
    cursor: pointer;
    border-radius: 100%;
}

.filter__scroll-mask {
    position: absolute;
    left: 0;
    top: 0;
    background: #369;
    width: 100px;
    height: 5px;
}

.filter__title {
    color: white;
    display: inline-block;
    cursor: initial;
    margin-right: 2px;
}

.filter__enhance {
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.filter__switch {
    width: 40px;
    height: 20px;
    background: #ccc;
    position: relative;
    display: inline-block;
    border-radius: 10px;
    cursor: pointer;
    transition: background 0.3s;
}

.filter__switch-slider {
    width: 18px;
    height: 18px;
    background: #fff;
    position: absolute;
    top: 1px;
    left: 0px;
    border-radius: 50%;
    transition: left 0.3s;
}

#filter__select {
    width: 100%;
    float: right;
}

.filter__filter {
    margin-top: 5px;
}

/* 增强画质提示弹窗样式 */
.enhance-modal__panel-wrap {
    width: 100%;
    height: 100%;
    z-index: 1000;
    background-color: rgba(0, 0, 0, 0.9);
    position: absolute;
    top: 0;
    left: 0;
    display: none;
    justify-content: center;
    align-items: center;
}
.enhance-modal__panel {
    height: 550px;
    width: 600px;
    background-color: white;
    border-radius: 20px;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    color: #333;
}

.enhance-modal__content {
    position: relative;
    top: 50%;
    transform: translateY(-50%);
    text-align: center;
}

.enhance-modal__text {
    font-size: 18px;
    margin-top: 20px;
}

.enhance-modal__img {
    width: 720px;
    margin-top: 20px;
}

.enhance-modal__close {
    font-size: 30px;
    font-weight: bold;
    position: absolute;
    right: 15px;
    top: 10px;
    cursor: pointer;
    transition: all 0.2s;
}

.enhance-modal__close:hover {
    color: #ff7700;
}
#ex-videospeed:hover > .videospeed__wrap {
    display: block;
}

.videospeed__wrap {
    display: none;
    margin: 0;
    padding: 0;
    border: 1px solid #e5e5e5;
    background: #fff;
    position: absolute;
    left: 199px;
    min-width: 100px;
    top: 120px;
}


.videospeed__panel {
    position: absolute;
    border: 1px solid #000;
    border-radius: 4px;
    transform: translateY(calc(-4px - 100%)) translateX(-50%);
    left: 33%;
    background-color: #000;
    opacity: .75;
    width: 70px;
}

.videospeed__panel li {
    padding: 0 2px;
    white-space: nowrap;
    color: #fff;
    text-align: center;
    cursor: pointer;
}

.videospeed__panel li:hover {
    background-color: rgb(85, 85, 85);
}  #ex-videosync {
    float: left;
    width: 24px;
    height: 24px;
    margin-left: 20px;
    cursor: pointer;
    background-size: contain;
}#ex-vtoolbar-menu {
    float: left;
    width: 24px;
    height: 24px;
    margin-right: 10px;
    position: relative;
    pointer-events: none;
    -webkit-user-select: none;
    user-select: none;
    overflow: visible;
}

.vtoolbar-menu__trigger {
    position: relative;
    z-index: 2;
    pointer-events: auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 24px;
    height: 24px;
    padding: 0;
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 6px;
    transition: background-color 0.2s ease, transform 0.2s ease;
}

.vtoolbar-menu__trigger:hover {
    background-color: rgba(255, 255, 255, 0.12);
}

.vtoolbar-menu__trigger:focus-visible {
    outline: 2px solid #ff7700;
    outline-offset: 2px;
}

#ex-vtoolbar-menu.is-open .vtoolbar-menu__trigger {
    background-color: rgba(255, 119, 0, 0.2);
}

.vtoolbar-menu__trigger .icon {
    display: block;
    transition: transform 0.2s ease;
}

.vtoolbar-menu__trigger:hover .icon {
    transform: scale(1.08);
}

.vtoolbar-menu__dropdown {
    display: none;
    position: absolute;
    left: 50%;
    bottom: calc(100% + 18px);
    transform: translateX(-50%);
    min-width: 188px;
    padding: 4px;
    border-radius: 10px;
    background: rgba(15, 15, 35, 0.96);
    border: 1px solid rgba(67, 56, 202, 0.35);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45), 0 0 0 1px rgba(255, 255, 255, 0.04) inset;
    z-index: 2;
    pointer-events: auto;
    backdrop-filter: blur(8px);
}

/* 仅连接菜单与精灵球之间的空隙，不遮挡工具条其他按钮 */
.vtoolbar-menu__dropdown::before {
    content: "";
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    top: 100%;
    width: 200px;
    height: 22px;
    pointer-events: auto;
}

#ex-vtoolbar-menu.is-open .vtoolbar-menu__dropdown {
    display: block;
    animation: vtoolbar-menu-fade-in 0.2s ease;
}

@keyframes vtoolbar-menu-fade-in {
    from {
        opacity: 0;
        transform: translateX(-50%) translateY(6px);
    }
    to {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }
}

@media (prefers-reduced-motion: reduce) {
    #ex-vtoolbar-menu.is-open .vtoolbar-menu__dropdown {
        animation: none;
    }
    .vtoolbar-menu__trigger,
    .vtoolbar-menu__pokeball,
    .vtoolbar-menu__item,
    .vtoolbar-menu__switch {
        transition: none;
    }
}

.vtoolbar-menu__dropdown::after {
    content: "";
    position: absolute;
    left: 50%;
    bottom: -7px;
    transform: translateX(-50%) rotate(45deg);
    width: 10px;
    height: 10px;
    background: rgba(15, 15, 35, 0.96);
    border-right: 1px solid rgba(67, 56, 202, 0.35);
    border-bottom: 1px solid rgba(67, 56, 202, 0.35);
    pointer-events: none;
}

.vtoolbar-menu__item {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    padding: 7px 10px;
    border: none;
    border-radius: 8px;
    background: transparent;
    color: #f8fafc;
    font-size: 12px;
    line-height: 20px;
    text-align: left;
    cursor: pointer;
    transition: background-color 0.2s ease, color 0.2s ease;
}

.vtoolbar-menu__item:hover {
    background-color: rgba(67, 56, 202, 0.35);
}

.vtoolbar-menu__item:focus-visible {
    outline: 2px solid #ff7700;
    outline-offset: -2px;
}

.vtoolbar-menu__item-icon {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
    color: #a5b4fc;
}

.vtoolbar-menu__item-icon .icon,
.vtoolbar-menu__item-icon svg,
.vtoolbar-menu__item-icon img {
    width: 20px;
    height: 20px;
    display: block;
    flex-shrink: 0;
}

.vtoolbar-menu__item-icon--compact svg,
.vtoolbar-menu__item-icon--compact .icon {
    width: 16px;
    height: 16px;
}

.vtoolbar-menu__item-icon .vtoolbar-menu__icon-pip {
    width: 18px;
    height: 18px;
}

.vtoolbar-menu__item-label {
    flex: 1;
    white-space: nowrap;
    font-size: 12px;
    line-height: 20px;
}

.vtoolbar-menu__item--filter.is-active {
    background-color: rgba(255, 119, 0, 0.15);
}

.vtoolbar-menu__item--filter.is-active .vtoolbar-menu__chevron {
    transform: rotate(90deg);
    color: #ff7700;
}

.vtoolbar-menu__chevron {
    flex-shrink: 0;
    width: 14px;
    height: 14px;
    color: #94a3b8;
    transition: transform 0.2s ease, color 0.2s ease;
}

.vtoolbar-menu__switch {
    flex-shrink: 0;
    width: 32px;
    height: 18px;
    border-radius: 10px;
    background: #475569;
    position: relative;
    transition: background-color 0.2s ease;
    pointer-events: none;
}

.vtoolbar-menu__switch.is-on {
    background: linear-gradient(90deg, #f0cb95, #e9be80);
}

.vtoolbar-menu__switch-thumb {
    position: absolute;
    top: 2px;
    left: 2px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
    transition: left 0.2s ease;
}

.vtoolbar-menu__switch.is-on .vtoolbar-menu__switch-thumb {
    left: 16px;
}

.vtoolbar-menu__filter-host {
    display: none;
    position: absolute;
    left: 100%;
    bottom: 0;
    margin-left: -6px;
    padding-left: 12px;
    z-index: 2;
    pointer-events: none;
}

.vtoolbar-menu__filter-host.is-visible {
    pointer-events: auto;
}

.vtoolbar-menu__filter-host.is-visible {
    display: block;
}

.vtoolbar-menu__filter-host .filter__wrap {
    display: block;
    position: static;
    float: none;
    right: auto;
    bottom: auto;
    margin: 0;
    height: auto;
}

.vtoolbar-menu__filter-host .filter__panel {
    position: relative;
    transform: none;
    left: auto;
    opacity: 0.92;
}

.vtoolbar-menu__divider {
    height: 1px;
    margin: 4px 8px;
    background: rgba(148, 163, 184, 0.2);
}
.menu-da2a9e {
  z-index: 999 !important;
} .volume-07c230.custom-muted .icon-c8be96 svg,
 .volume-07c230.custom-normal .icon-c8be96 svg {
     display: none !important;
 }

 .volume-07c230.custom-muted .icon-c8be96::after,
 .volume-07c230.custom-normal .icon-c8be96::after {
     content: '';
     display: block;
     width: 32px;
     height: 32px;
     background-size: contain;
     background-repeat: no-repeat;
     background-position: center;
 }

 /* 静音图标颜色控制 */
 .volume-07c230.custom-muted .icon-c8be96::after {
     background-image: url('data:image/svg+xml;utf8,<svg fill="none" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M5 10h5.5L16 6v20l-5.5-4H5V10z" stroke="%23fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M20 19l6-6M20 13l6 6" stroke="%23fff" stroke-width="2" stroke-linecap="round"></path></svg>');
 }

 .volume-07c230.custom-muted:hover .icon-c8be96::after {
     background-image: url('data:image/svg+xml;utf8,<svg fill="none" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M5 10h5.5L16 6v20l-5.5-4H5V10z" stroke="%23ff5d23" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M20 19l6-6M20 13l6 6" stroke="%23ff5d23" stroke-width="2" stroke-linecap="round"></path></svg>');
 }

 /* 正常图标颜色控制 */
 .volume-07c230.custom-normal .icon-c8be96::after {
     background-image: url('data:image/svg+xml;utf8,<svg fill="none" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M5 10h5.5L16 6v20l-5.5-4H5V10z" stroke="%23fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21.736 23.517a8 8 0 00-.527-15.206M19.687 19.867a3.925 3.925 0 00-.258-7.46" stroke="%23fff" stroke-width="2" stroke-linecap="round"></path></svg>');
 }

 .volume-07c230.custom-normal:hover .icon-c8be96::after {
     background-image: url('data:image/svg+xml;utf8,<svg fill="none" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><path d="M5 10h5.5L16 6v20l-5.5-4H5V10z" stroke="%23ff5d23" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21.736 23.517a8 8 0 00-.527-15.206M19.687 19.867a3.925 3.925 0 00-.258-7.46" stroke="%23ff5d23" stroke-width="2" stroke-linecap="round"></path></svg>');
 }.weeklypanel__panel-wrap {
    width: 100%;
    height: 100%;
    z-index: 1000;
    background-color: rgba(0, 0, 0, 0.9);
    position: absolute;
    top: 0;
    left: 0;
    display: flex;
    justify-content: center;
    align-items: center;
}
.weeklypanel__panel {
    height: 600px;
    width: 500px;
    background-color: white;
    border-radius: 20px;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
}

.weeklypanel__content {
    position: relative;
    top: 50%;
    transform: translateY(-50%);
    text-align: center;
}

.weeklypanel__text {
    font-size: 18px;
}

.weeklypanel__text a {
    font-weight: bold;
    font-size: 24px;
}

.weeklypanel__close {
    font-size: 30px;
    font-weight: bold;
    position: absolute;
    right: 15px;
    cursor: pointer;
}.noticejs-top{top:0;width:100% !important}.noticejs-top .item{border-radius:0 !important;margin:0 !important}.noticejs-topRight{top:10px;right:10px}.noticejs-topLeft{top:10px;left:10px}.noticejs-topCenter{top:10px;left:50%;transform:translate(-50%)}.noticejs-middleLeft,.noticejs-middleRight{right:10px;top:50%;transform:translateY(-50%)}.noticejs-middleLeft{left:10px}.noticejs-middleCenter{top:50%;left:50%;transform:translate(-50%,-50%)}.noticejs-bottom{bottom:0;width:100% !important}.noticejs-bottom .item{border-radius:0 !important;margin:0 !important}.noticejs-bottomRight{bottom:10px;right:10px}.noticejs-bottomLeft{bottom:10px;left:10px}.noticejs-bottomCenter{bottom:10px;left:50%;transform:translate(-50%)}.noticejs{font-family:Helvetica Neue,Helvetica,Arial,sans-serif}.noticejs .item{margin:0 0 10px;border-radius:3px;overflow:hidden}.noticejs .item .close{float:right;font-size:18px;font-weight:700;line-height:1;color:#fff;text-shadow:0 1px 0 #fff;opacity:1;margin-right:7px}.noticejs .item .close:hover{opacity:.5;color:#000}.noticejs .item a{color:#fff;border-bottom:1px dashed #fff}.noticejs .item a,.noticejs .item a:hover{text-decoration:none}.noticejs .success{background-color:#64ce83}.noticejs .success .noticejs-heading{background-color:#3da95c;color:#fff;padding:10px}.noticejs .success .noticejs-body{color:#fff;padding:10px}.noticejs .success .noticejs-body:hover{visibility:visible !important}.noticejs .success .noticejs-content{visibility:visible}.noticejs .info{background-color:#3ea2ff}.noticejs .info .noticejs-heading{background-color:#067cea;color:#fff;padding:10px}.noticejs .info .noticejs-body{color:#fff;padding:10px}.noticejs .info .noticejs-body:hover{visibility:visible !important}.noticejs .info .noticejs-content{visibility:visible}.noticejs .warning{background-color:#ff7f48}.noticejs .warning .noticejs-heading{background-color:#f44e06;color:#fff;padding:10px}.noticejs .warning .noticejs-body{color:#fff;padding:10px}.noticejs .warning .noticejs-body:hover{visibility:visible !important}.noticejs .warning .noticejs-content{visibility:visible}.noticejs .error{background-color:#e74c3c}.noticejs .error .noticejs-heading{background-color:#ba2c1d;color:#fff;padding:10px}.noticejs .error .noticejs-body{color:#fff;padding:10px}.noticejs .error .noticejs-body:hover{visibility:visible !important}.noticejs .error .noticejs-content{visibility:visible}.noticejs .progressbar{width:100%}.noticejs .progressbar .bar{width:1%;height:30px;background-color:#4caf50}.noticejs .success .noticejs-progressbar{width:100%;background-color:#64ce83;margin-top:-1px}.noticejs .success .noticejs-progressbar .noticejs-bar{width:100%;height:5px;background:#3da95c}.noticejs .info .noticejs-progressbar{width:100%;background-color:#3ea2ff;margin-top:-1px}.noticejs .info .noticejs-progressbar .noticejs-bar{width:100%;height:5px;background:#067cea}.noticejs .warning .noticejs-progressbar{width:100%;background-color:#ff7f48;margin-top:-1px}.noticejs .warning .noticejs-progressbar .noticejs-bar{width:100%;height:5px;background:#f44e06}.noticejs .error .noticejs-progressbar{width:100%;background-color:#e74c3c;margin-top:-1px}.noticejs .error .noticejs-progressbar .noticejs-bar{width:100%;height:5px;background:#ba2c1d}@keyframes noticejs-fadeOut{0%{opacity:1}to{opacity:0}}.noticejs-fadeOut{animation-name:noticejs-fadeOut}@keyframes noticejs-modal-in{to{opacity:.3}}@keyframes noticejs-modal-out{to{opacity:0}}.noticejs-rtl .noticejs-heading{direction:rtl}.noticejs-rtl .close{float:left !important;margin-left:7px;margin-right:0 !important}.noticejs-rtl .noticejs-content{direction:rtl}.noticejs{position:fixed;z-index:10050;width:320px}.noticejs::-webkit-scrollbar{width:8px}.noticejs::-webkit-scrollbar-button{width:8px;height:5px}.noticejs::-webkit-scrollbar-track{border-radius:10px}.noticejs::-webkit-scrollbar-thumb{background:hsla(0,0%,100%,.5);border-radius:10px}.noticejs::-webkit-scrollbar-thumb:hover{background:#fff}.noticejs-modal{position:fixed;width:100%;height:100%;background-color:#000;z-index:10000;opacity:.3;left:0;top:0}.noticejs-modal-open{opacity:0;animation:noticejs-modal-in .3s ease-out}.noticejs-modal-close{animation:noticejs-modal-out .3s ease-out;animation-fill-mode:forwards}.noticejs .special{background-color:rgb(160,37,160)}.noticejs .special .noticejs-heading{background-color:rgb(110,26,110);color:#fff;padding:10px}.noticejs .special .noticejs-body{color:#fff;padding:10px}.noticejs .special .noticejs-body:hover{visibility:visible !important}.noticejs .special .noticejs-content{visibility:visible}.noticejs .special .noticejs-progressbar{width:100%;background-color:rgb(160,37,160);margin-top:-1px}.noticejs .special .noticejs-progressbar .noticejs-bar{width:100%;height:5px;background:rgb(110,26,110)}/**
 * PostbirdAlertBox.js
 * -    原生javascript弹框插件
 * Author:  Postbird - http://www.ptbird.cn
 * License: MIT
 * Date:    2017-09-23
 */
 .postbird-box-container {
    width: 100%;
    height: 100%;
    overflow: hidden;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 9999;
    background-color: rgba(0, 0, 0, 0.2);
    display: block;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none
}

.postbird-box-container.active {
    display: block
}

.postbird-box-content {
    min-width: 400px;
    max-width: 600px;
    min-height: 150px;
    background-color: #fff;
    border: solid 1px #dfdfdf;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    margin-top: -100px
}

.postbird-box-header {
    width: 100%;
    padding: 10px 15px;
    position: relative;
    font-size: 1.1em;
    letter-spacing: 2px
}

.postbird-box-close-btn {
    cursor: pointer;
    font-weight: 700;
    color: #000;
    float: right;
    opacity: .5;
    font-size: 1.3em;
    margin-top: -3px;
    display: none
}

.postbird-box-close-btn:hover {
    opacity: 1
}

.postbird-box-text {
    box-sizing: border-box;
    width: 100%;
    padding: 0 10%;
    text-align: center;
    line-height: 40px;
    font-size: 20px;
    letter-spacing: 1px
}

.postbird-box-footer {
    width: 100%;
    position: absolute;
    padding: 0;
    margin: 0;
    bottom: 0;
    display: flex;
    display: -webkit-flex;
    justify-content: space-around;
    border-top: solid 1px #dfdfdf;
    align-items: flex-end
}

.postbird-box-footer .btn-footer {
    line-height: 44px;
    border: 0;
    cursor: pointer;
    background-color: #fff;
    color: #0e90d2;
    font-size: 1.1em;
    letter-spacing: 2px;
    transition: background-color .5s;
    -webkit-transition: background-color .5s;
    -o-transition: background-color .5s;
    -moz-transition: background-color .5s;
    outline: 0
}

.postbird-box-footer .btn-footer:hover {
    background-color: #e5e5e5
}

.postbird-box-footer .btn-block-footer {
    width: 100%
}

.postbird-box-footer .btn-left-footer,
.postbird-box-footer .btn-right-footer {
    position: relative;
    width: 100%
}

.postbird-box-footer .btn-left-footer::after {
    content: "";
    position: absolute;
    right: 0;
    top: 0;
    background-color: #e5e5e5;
    height: 100%;
    width: 1px
}

.postbird-box-footer .btn-footer-cancel {
    color: #333
}

.postbird-prompt-input {
    width: 100%;
    padding: 5px;
    font-size: 16px;
    border: 1px solid #ccc;
    outline: 0
}.onoffswitch {
    position: relative; width: 45px;
    -webkit-user-select:none; -moz-user-select:none; -ms-user-select: none;
}
.onoffswitch-checkbox {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}
.onoffswitch-label {
    display: block; overflow: hidden; cursor: pointer;
    height: 20px; padding: 0; line-height: 20px;
    border: 2px solid #E3E3E3; border-radius: 20px;
    background-color: #FFFFFF;
    transition: background-color 0.3s ease-in;
}
.onoffswitch-label:before {
    content: "";
    display: block; width: 20px; margin: 0px;
    background: #FFFFFF;
    position: absolute; top: 0; bottom: 0;
    right: 23px;
    border: 2px solid #E3E3E3; border-radius: 20px;
    transition: all 0.3s ease-in 0s; 
}
.onoffswitch-checkbox:checked + .onoffswitch-label {
    background-color: #3AAD38;
}
.onoffswitch-checkbox:checked + .onoffswitch-label, .onoffswitch-checkbox:checked + .onoffswitch-label:before {
   border-color: #3AAD38;
}
.onoffswitch-checkbox:checked + .onoffswitch-label:before {
    right: 0px; 
}.layui-timeline {
    padding-left: 5px;
}

.layui-timeline-item {
    position: relative;
    padding-bottom: 20px;
}

li {
    list-style: none;
}

.layui-timeline-item:first-child::before {
    display: block;
}

.layui-timeline-item:last-child::before {
    content: '';
    position: absolute;
    left: 5px;
    top: 0;
    z-index: 0;
    width: 0;
    height: 100%;
}
.layui-timeline-item::before {
    content: '';
    position: absolute;
    left: 5px;
    top: 0;
    z-index: 0;
    width: 1px;
    height: 100%;
}

.layui-timeline-item::before,
hr {
    background-color: #e6e6e6;
}

.layui-timeline-axis {
    position: absolute;
    left: -5px;
    top: 0;
    z-index: 10;
    width: 20px;
    height: 20px;
    line-height: 20px;
    background-color: #fff;
    color: #5FB878;
    border-radius: 50%;
    text-align: center;
    cursor: pointer;
}

.layui-icon {
    font-family: layui-icon !important;
    font-size: 16px;
    font-style: normal;
}

.layui-timeline-content {
    padding-left: 25px;
}

.layui-text {
    line-height: 22px;
    font-size: 14px;
    color: rgb(85,85,85);
}

.layui-timeline-title {
    position: relative;
}
		`)),document.head.appendChild(e)}var o=document.getElementsByTagName("html")[0].innerHTML,l="$ROOM.room_id =".length,t=o.indexOf("$ROOM.room_id ="),B="",I=(0<t?B=(B=o.substring(t+l,o.indexOf(";",t+l)))&&B.trim():(B=v(o,"roomID:",","))?B=B.trim():(t=document.querySelector('link[rel="canonical"]'))&&(B=t.getAttribute("href").split("/").pop().trim()),o=null,Q("acf_uid")),q="",m=Q("acf_uid")+"_"+Q("acf_biz")+"_"+Q("acf_stk")+"_"+Q("acf_ct")+"_"+Q("acf_ltkid"),U=null;function b(t){return new Promise(e=>setTimeout(e,t))}function y(e){let t=parseInt(e),o=0,n=0,i=(60<t&&(o=parseInt(t/60),t=parseInt(t%60),60<o)&&(n=parseInt(o/60),o=parseInt(o%60)),parseInt(t)+"秒");return 0<o&&(i=parseInt(o)+"分"+i),i=0<n?parseInt(n)+"小时"+i:i}function W(e){var t=0,o=0;return 60<(e=parseInt(e))&&(t=parseInt(e/60),e=parseInt(e%60),60<t)&&(o=parseInt(t/60),t=parseInt(t%60)),e=""+(parseInt(e)<10?"0"+parseInt(e):parseInt(e)),e=(parseInt(t)<10?"0"+parseInt(t):parseInt(t))+":"+e,e=(parseInt(o)<10?"0"+parseInt(o):parseInt(o))+":"+e}async function Y(){return!0}function v(e,t,o){e=e.match(new RegExp(t+"(.*?)"+o));return!!e&&e[1]}function Q(e){var e=new RegExp("(^| )"+e+"=([^;]*)(;|$)");return(e=document.cookie.match(e))?unescape(e[2]):null}function x(){let e=Q("acf_ccn");var t,o,n;return null==e&&(t="acf_ccn",o="1",(n=new Date).setTime(n.getTime()+108e5),document.cookie=t+"="+escape(o)+"; path=/; expires="+n.toGMTString(),e="1"),e}function S(e,t="success",o){e={text:e,type:t,position:"bottomLeft",...o};new NoticeJs(e).show()}function w(e,t=!0){GM_openInTab(e,{active:t})}function J(){-1!=navigator.userAgent.indexOf("Firefox")||-1!=navigator.userAgent.indexOf("Chrome")?window.location.href="about:blank":(window.opener=null,window.open("","_self")),window.close()}function _(e,t){var o,n={"M+":t.getMonth()+1,"d+":t.getDate(),"h+":t.getHours(),"m+":t.getMinutes(),"s+":t.getSeconds(),"q+":Math.floor((t.getMonth()+3)/3),S:t.getMilliseconds()};for(o in/(y+)/.test(e)&&(e=e.replace(RegExp.$1,(t.getFullYear()+"").substr(4-RegExp.$1.length))),n)new RegExp("("+o+")").test(e)&&(e=e.replace(RegExp.$1,1==RegExp.$1.length?n[o]:("00"+n[o]).substr((""+n[o]).length)));return e}function Z(e,t){return Math.floor(Math.random()*(t-e)+e)}function X(t,o,n){window.Notification&&"denied"!==Notification.permission&&Notification.requestPermission(function(e){new Notification(t,{body:o}).onclick=function(){n()}})}function K(){return new Promise(t=>{fetch("https://www.douyu.com/member/cp",{method:"GET",mode:"no-cors",credentials:"include"}).then(e=>e.text()).then(e=>{e=(e=(new DOMParser).parseFromString(e,"text/html")).getElementsByClassName("uname_con")[0].title;t(e)}).catch(e=>{console.error("请求失败",e)})})}function $(e){if("TEXTAREA"===e.tagName)return e.selectionStart;let t=0;var o,n,i;return document.selection?(n=document.selection.createRange(),(o=(i=e.createTextRange()).duplicate()).moveToBookmark(n.getBookmark()),o.setEndPoint("EndToEnd",i),t=o.text.length):window.getSelection&&0<(n=window.getSelection()).rangeCount&&((i=n.getRangeAt(0).cloneRange()).selectNodeContents(e),i.setEnd(0<n.rangeCount?n.getRangeAt(0).endContainer:e,0<n.rangeCount?n.getRangeAt(0).endOffset:0),t=i.toString().length),t}function ee(t){var o=[{name:"弹幕发送小助手",className:"bloop"},{name:"扩展功能",className:"extool"},{name:"直播间工具",className:"livetool"},{name:"全站抽奖信息",className:"exlottery"},{name:"弹幕小尾巴",className:"ChatToolBar-DanmakuTail-Panel"}];for(let e=0;e<o.length;e++){var n=o[e],i=document.getElementsByClassName(n.className)[0];i&&(t===n.name?i.style.display="block"!==i.style.display?"block":"none":i.style.display="none")}}function te(e,t,o="download.xlsx"){var n=[],e=(n.push(e,...t),XLSX.utils.aoa_to_sheet(n)),i=(t=e,(n={SheetNames:[r=r||"sheet1"],Sheets:{}}).Sheets[r]=t,r={bookType:"xlsx",bookSST:!1,type:"binary"},t=XLSX.write(n,r),n=new Blob([(e=>{for(var t=new ArrayBuffer(e.length),o=new Uint8Array(t),n=0;n!=e.length;++n)o[n]=255&e.charCodeAt(n);return t})(t)],{type:"application/octet-stream"})),e=o;"object"==typeof i&&i instanceof Blob&&(i=URL.createObjectURL(i));var a,r=document.createElement("a");r.href=i,r.download=e||"",window.MouseEvent?a=new MouseEvent("click"):(a=document.createEvent("MouseEvents")).initMouseEvent("click",!0,!1,window,0,0,0,0,0,!1,!1,!1,!1,0,null),r.dispatchEvent(a),"string"==typeof i&&0===i.indexOf("blob:")&&setTimeout(function(){try{URL.revokeObjectURL(i)}catch(e){}},1500)}function oe(){var e=new Event("resize");window.dispatchEvent(e)}function k(e){for(var t of e){let e=null;if(e="string"==typeof t?document.querySelector(t):t)return e}return null}let ne='<svg t="1613993967937" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2122" width="16" height="16"><path d="M217.472 311.808l384.64 384.64-90.432 90.56-384.64-384.64z" fill="#8A8A8A" p-id="2123"></path><path d="M896.32 401.984l-384.64 384.64-90.56-90.496 384.64-384.64z" fill="#8A8A8A" p-id="2124"></path></svg>',ie=0;function ae(e){document.getElementById("ex-accountList-content").innerHTML=(e=>{let t=null==e?JSON.parse(GM_getValue("Ex_accountList")||"{}"):e,o="";for(var n in t)"null"!=n&&(n=t[n],o+=`
        <div class="ex-accountList-item" uid="${n.uid}">
            <div class="ex-accountList-item__imgWrap">
                <img src=${decodeURIComponent(n.avatar)+"middle.jpg"} alt="" class="ex-accountList-item__img">
            </div>
            <div class="ex-accountList-item__name">${decodeURIComponent(n.nickname)}</div>
            <div class="ex-accountList-item__btn">删除</div>
        </div>`);return o+=`
    <div id="ex-accountList-item-add">
        <svg t="1613995373702" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2832" width="32" height="32"><path d="M577.088 0H448.96v448.512H0v128h448.96V1024h128.128V576.512H1024v-128H577.088z" p-id="2833" fill="#8A8A8A"></path></svg>
    </div>
    `})(e);var t=document.getElementsByClassName("ex-accountList-item");for(let e=0;e<t.length;e++){var o=t[e];let a=o.getAttribute("uid");o.addEventListener("click",()=>{S("【账号管理】正在切换账号，请耐心等待...","info");{a;var i=()=>{};JSON.parse(GM_getValue("Ex_accountList"));let o=[],n=0;GM_cookie("list",{path:"/"},function(t){for(let e=0;e<t.length;e++)GM_cookie("delete",{name:t[e].name},function(e){if(++n>=t.length){let t=0;for(let e=0;e<o.length;e++)GM_cookie("set",{name:o[e].name,value:o[e].value,domain:o[e].domain,path:o[e].path,secure:o[e].secure,httpOnly:o[e].httpOnly,sameSite:o[e].sameSite,expirationDate:o[e].expirationDate,hostOnly:o[e].hostOnly},function(e){++t>=o.length&&i()})}})})}le("switch",a),document.getElementById("ex-accountList-iframe2").innerHTML=`
    <iframe id="ex-yuba-iframe" width="100%" height="100%" scrolling="no" frameborder="0" src="https://yuba.douyu.com/iframe/tab/6416853?exClean&domain=${encodeURIComponent(window.location.href)}&"></iframe>
    <iframe id="ex-msg-iframe" width="100%" height="100%" scrolling="no" frameborder="0" src="https://msg.douyu.com/web/index.html?exClean&domain=${encodeURIComponent(window.location.href)}&"></iframe>
    <iframe id="ex-video-iframe" width="100%" height="100%" scrolling="no" frameborder="0" src="https://v.douyu.com/show/0?exClean&domain=${encodeURIComponent(window.location.href)}&"></iframe>
    <iframe id="ex-cz-iframe" width="100%" height="100%" scrolling="no" frameborder="0" src="https://cz.douyu.com/item/gold?exClean&domain=${encodeURIComponent(window.location.href)}&"></iframe>
    `}),o.getElementsByClassName("ex-accountList-item__btn")[0].addEventListener("click",e=>{var t,o;e.stopPropagation(),S("【账号管理】正在删除...","info"),e=a,t=()=>{},delete(o=JSON.parse(GM_getValue("Ex_accountList")||"{}"))[e],GM_setValue("Ex_accountList",JSON.stringify(o)),t(),le("delete",a)})}document.getElementById("ex-accountList-item-add").addEventListener("click",()=>{re(()=>{}),le("clean","null")})}function re(o){let n=0;GM_cookie("list",{path:"/"},t=>{if(t)for(let e=0;e<t.length;e++)GM_cookie("delete",{name:t[e].name},function(e){++n>=t.length&&o()});else o()})}function le(e,t){document.getElementById("ex-accountList-iframe").innerHTML=`
    <iframe id="login-passport-frame" width="100%" height="100%" scrolling="no" frameborder="0" src="https://passport.douyu.com/index/error/show404?&exid=chun&cmd=${e}&uid=${t}&domain=${encodeURIComponent(window.location.href)}&"></iframe>
    `}function se(){var e=k([".pause-c594e8",".icon-c8be96"]);e&&e.click(),pl(B,!0,0,"1428",e=>{var i,a;i=A.length,pl(a=B,!1,0,"1",t=>{if(""!=t||null!=t)if("None"==t)S("房间未开播或其他错误","error");else{var o=String(t).split("/live");let e="";0<o.length&&(e=o[0]);var o=document.createElement("div"),n="",n=(o.id="exVideoDiv"+String(i),o.rid=a,o.className="exVideoDiv",n=(n=(n=(n=(n=(n+="<div class='exVideoInfo' id='exVideoInfo"+String(i)+"'><a title='复制直播流地址'><span class='exVideoRID' id='exVideoRID"+String(i)+"' style='color:white'>斗鱼音频流 - "+a+"</span></a>")+("<select style='display:none' class='exVideoQn' id='exVideoQn"+String(i)+"'><option value='1'>流畅</option><option value='2'>高清</option><option value='3'>超清</option><option value='0'>蓝光</option></select>"))+("<select style='display:none' class='exVideoCDN' id='exVideoCDN"+String(i)+"'><option value='1'>主线路</option><option value='2'>备用线路5</option><option value='3'>备用线路6</option></select>"))+("<a style='margin-left:5px;display:none' href='"+e+"' target='_blank'>无视频？</a>"))+("<a><div class='exVideoClose' id='exVideoClose"+String(i)+"'>X</div></a>")+"</div>")+("<video controls='controls' class='exVideoPlayer' id='exVideoPlayer"+String(i)+"'></video><div class='exVideoScale' id='exVideoScale"+String(i)+"'></div>"),o.innerHTML=n,k([".layout-Main",".playerWrap__8wGvw",".live-next-body"]));n.insertBefore(o,n.childNodes[0]),yn(i),fn(i),vn(i,a),hn(i,t)}})})}let de,ce=null;let pe=[],me=[],ue=0,ge=0,he,fe=0,ye=0,be=!0,ve=!1,xe,we=[];function E(e){var t=document.getElementsByClassName("ChatSend-txt")[0];"TEXTAREA"==t.tagName?t.value=e:t.innerText=e,document.getElementsByClassName("ChatSend-button")[0].click()}function _e(){var e=document.getElementById("bloop__text_speed1").value,t=document.getElementById("bloop__text_speed2").value;return Z(Number(e),Number(t))}function ke(){let e=document.getElementById("bloop__text_speed1").value,t=document.getElementById("bloop__text_speed2").value,o=document.getElementById("bloop__text_stoptime").value;var n=document.getElementById("bloop__checkbox_tiangou").checked,n=("undefined"==e&&(e=2e3),"undefined"==t&&(t=3e3),"undefined"==o&&(o=5),{text:we,speed1:e,speed2:t,stopTime:o,isChangeColor:be,isTiangouMode:n});localStorage.setItem("ExSave_BarrageLoopOptions",JSON.stringify(n).replace(/\\n/g,"\\r"))}async function Ee(){if(1==be){{var t=ye;let e;null!=(e=(0==ve?(document.getElementsByClassName("FansBarrageSwitcher")[0].click(),document.getElementsByClassName("FansBarrageColor-item")):(document.getElementsByClassName("MatchSystemFansBarrageSwitcher")[0].click(),document.getElementsByClassName("MatchSystemFansBarrageColor-item")))[t])&&e.click()}++ye>ue&&(ye=0)}1==document.getElementById("bloop__checkbox_tiangou").checked?(t=await new Promise(t=>{GM_xmlhttpRequest({method:"GET",url:"https://api.shadiao.app/chp",responseType:"json",onload:function(e){e=e.response;t(e.data.text)}})}),E(t=String(t).replace(/他/g,"她"))):(1==document.getElementById("bloop__checkbox_random").checked&&(fe=Math.floor(Math.random()*me.length)),E(me[fe]),1!=document.getElementById("bloop__checkbox_random").checked&&++fe>me.length-1&&(fe=0)),he=setTimeout(Ee,_e())}let Be=!1;function Ie(e){if(!Be){Be=!0;try{e()}finally{setTimeout(()=>{Be=!1},0)}}}function Se(){var e,t,o=document.getElementsByClassName("danmuContent-25f266")[0];o&&(e=o.innerHTML).includes("[DouyuEx图片")&&(t=e.replace(/\[DouyuEx图片(.*?)\]/g,(e,t)=>{var o;return(e=>(e=e.substring(e.lastIndexOf(".")).toLowerCase(),[".jpg",".jpeg",".png",".gif",".webp",".svg",".bmp",".ico",".tiff",".tif"].includes(e)))(t)?(o=(t=>{let o=0n,n=1n;for(let e=t.length-1;0<=e;e--){var i=t[e].toUpperCase(),a="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(i);if(-1===a)throw new Error("Invalid base36 character: "+i);o+=BigInt(a)*n,n*=36n}return o.toString()})((t=t.split("."))[0]),t=`<a href="${(o=DOMPurify.sanitize(`https://img.douyucdn.cn/data/yuba/weibo/${o.slice(0,4)+"/"+o.slice(4,6)+"/"+o.slice(6,8)+"/"+o}.200x0.`+t[1])).replace("200x0.","")}" target="_blank"><img class="ex-image-danmaku" src="${o}" alt=""></a>`,DOMPurify.sanitize(t)):""}))!==e&&(o.innerHTML=t)}function Ce(t,e){null==t.querySelector("#barragePanel__id")&&(t.childNodes&&0<t.childNodes.length&&t.removeChild(t.childNodes[0]),n=(t=>{let o="";var n=document.getElementsByClassName("Barrage-listItem");for(let e=n.length-1;0<=e;e--){var i=n[e].lastElementChild;if(null!=i&&-1!=i.innerHTML.indexOf(t)){0<i.getElementsByClassName("Barrage-icon--roomAdmin").length&&(o+="【房管】");var a=i.getElementsByClassName("Barrage-nobleImg"),a=(0<a.length&&(o+=`【${a[0].title}】`),i.getElementsByClassName("UserLevel"));0<a.length&&(o+=a[0].title);break}}return o})(e),(o=document.createElement("span")).innerHTML=e,o.title=n,o.id="barragePanel__id",t.insertBefore(o,t.childNodes[0]||null));var o,n=(t=>{let o=!1;var n=document.getElementsByClassName("Barrage-listItem");for(let e=n.length-1;0<=e;e--){var i=n[e].lastElementChild;if(null!=i&&-1!=i.innerHTML.indexOf(t)){i=i.getElementsByClassName("FansMedalWrap");if(0<i.length){o=i[0].cloneNode(!0);break}}}return o})(e);if(0!=n){let e=t.querySelector("#barragePanel__fansMedal");e?e.innerHTML="":((e=document.createElement("div")).id="barragePanel__fansMedal",e.style="display:inline-block",t.insertBefore(e,t.childNodes[0]||null)),e.appendChild(n)}}function Te(e){var t;null==document.getElementById("barragePanel__split")&&((t=document.createElement("br")).id="barragePanel__split",e.appendChild(t))}function Ne(e){var t;null!=document.getElementById("barragePanel__mute")||0<document.getElementsByClassName("barragePanel__muteTime").length||((t=document.createElement("div")).style="display:flex;align-items:center;width:100%;gap:8px;",t.innerHTML=`
        <div class="button-7e1395" id="barragePanel__mute" style="z-index:5">禁言</div>
        <div class="barragePanel__muteTime" style="z-index:5">
            <select id="barragePanel__muteSelect" style='width:55px'>
                <option value="1">1分钟</option>
                <option value="10">10分钟</option>
                <option value="30">30分钟</option>
                <option value="60">1小时</option>
                <option value="480">8小时</option>
                <option value="1440">1天</option>
                <option value="4320">3天</option>
                <option value="10080">7天</option>
                <option value="43200">30天</option>
                <option value="259200">180天</option>
                <option value="518400">360天</option>
            </select>
        </div>
    `,e.appendChild(t))}function Me(e){var t;null==document.getElementById("barragePanel__search")&&((t=document.createElement("div")).className="button-7e1395",t.innerText="查弹幕",t.id="barragePanel__search",t.style="z-index:5",e.appendChild(t))}function Le(e){var t;null==document.getElementById("barragePanel__reply")&&((t=document.createElement("div")).className="button-7e1395",t.innerText="回复",t.id="barragePanel__reply",t.style="z-index:5",e.appendChild(t))}function Ae(e,o){document.getElementById("barragePanel__reply").onclick=()=>{var e=document.getElementsByClassName("danmuContent-25f266")[0].innerText,t=document.getElementsByClassName("ChatSend-txt")[0],e=`@${o}：`+e;"TEXTAREA"==t.tagName?t.value=e:t.innerText=e,t.focus()},document.getElementById("barragePanel__mute").onclick=async()=>{var e=document.getElementById("barragePanel__muteSelect").value||"1",t=await go(B,o,e);"添加成功"==t.msg?S(`【禁言】${o}已被禁言${e}分钟`,"success"):S(t.msg,"error")},document.getElementById("barragePanel__search").onclick=async()=>{n=o;var n,e=await new Promise(o=>{GM_xmlhttpRequest({method:"GET",url:"https://www.doseeing.com/api/suggest_all?type=room&nickname="+encodeURIComponent(n),responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded"},onload:function(e){e=e.response;let t=!0;e.suggest||(t=!1),e.suggest.fan||(t=!1),0===e.suggest.fan.length&&(t=!1),(t=e.suggest.fan[0].nickname!==n?!1:t)?o(e.suggest.fan[0].user_id):o("")}})});""!==e&&w(`https://www.doseeing.com/data/fan/${e}?type=chat&dt=0`,!0)}}let De=[],C=0,je=200;function Pe(e){De.length>=je&&(De.shift(),C=Math.min(C,De.length)),C=De.push(e)}function ze(){var e,t;null!=De[C]&&(e=De[C]||"",null!=(t=document.getElementsByClassName("ChatSend-txt")[0]))&&("TEXTAREA"===t.tagName?t.value=e:t.innerText=e)}function Oe(){var e=document.getElementsByClassName("ChatSend-txt")[0];return null!=e?"TEXTAREA"===e.tagName?e.value:e.innerText:""}let Re={t:0,list:[]};async function Fe(){o=B;var o,e=await new Promise((t,e)=>{fetch("https://www.douyu.com/japi/interact/cdn/pocket/effective?rid="+o,{method:"GET",mode:"no-cors",credentials:"include"}).then(e=>e.json()).then(e=>{if(!e.data)return t([]);t(e.data.list)}).catch(e=>{console.log("请求失败!",e)})});Re.list=e,Re.t=(new Date).getTime()}function He(e){pl(B,!0,0,e,e=>{"None"==e?S("房间未开播或其他错误","error"):(e=String(e),GM_setClipboard(e),S("复制成功","success"))})}function Ge(){0<document.querySelectorAll(".tipItem-898596 > ul > li").length?document.querySelectorAll(".tipItem-898596 > ul > li").forEach(e=>{e.className.includes("selected")&&He((e=e.innerText,String(e).includes("蓝光8M")?8:String(e).includes("蓝光4M")?4:String(e).includes("超清")?3:String(e).includes("高清")?2:0))}):He(0)}function Ve(e){var t=e.target.value,o=document.getElementsByClassName("ChatBarrageCollectPop-barrageContent")[0].parentElement.getElementsByClassName("TagItem");for(let e=0;e<o.length;e++){var n=o[e];n.innerText.includes(t)?n.style.display="":n.style.display="none"}}function qe(){let t=localStorage.getItem("ExSave_DanmakuCollect");try{t=JSON.parse(t)||[]}catch(e){t=[]}return t}function Ue(){var e={isTailEnabled:document.getElementById("DanmakuTail-checkbox").checked,tailContent:document.getElementById("DanmakuTail-input").value,type:document.querySelector('input[name="DanmakuTailType"]:checked').value};localStorage.setItem("ExSave_DanmakuTail",JSON.stringify(e))}let We=null,Ye=!1,Qe="ex-barrageLine";function Je(){let n=setInterval(()=>{var e=document.getElementsByTagName("demand-video")[0].shadowRoot.getElementById("demandcontroller-bar").shadowRoot.querySelector("demand-video-controller-progress").shadowRoot.querySelector(".ProgressBar-Sign"),t=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot,o=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot;e&&t&&o&&(clearInterval(n),(e=document.createElement("style")).innerHTML=`.no-hasLR #ex-barrageLine {
        display: none !important;
    }`,document.getElementsByTagName("demand-video")[0].shadowRoot.getElementById("demandcontroller-bar").shadowRoot.querySelector("demand-video-controller-progress").shadowRoot.append(e),Ze(),t=o.querySelector("share-hover"),(We=new MutationObserver(function(e){Ze()})).observe(t,{attributes:!0,childList:!0,subtree:!1}))},1e3)}async function Ze(){if(!Ye){Ye=!0,setTimeout(()=>{Ye=!1},1e3),S("弹幕高能进度条加载中，请耐心等待","info");var o=document.getElementsByTagName("demand-video")[0].shadowRoot.getElementById("demandcontroller-bar").shadowRoot.querySelector("demand-video-controller-progress").shadowRoot,n=o.querySelector(".ProgressBar"),o=o.querySelector("#"+Qe),i=(o&&o.remove(),document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("share-hover").getAttribute("hashid")),o=document.getElementsByTagName("demand-video")[0].shadowRoot.getElementById("demandcontroller-bar").shadowRoot.querySelector("#time-label").innerText.split("/");if(!(o.length<=0)){var a=(e=>{let t=0;return 1===(e=e.split(":")).length?t=Number(e[0]):2===e.length?t=60*Number(e[0])+Number(e[1]):3===e.length&&(t=3600*Number(e[0])+60*Number(e[1])+Number(e[2])),1e3*t})(o[1])/99,r=new Array(100).fill(0,0,100);let e=0;do{var l=await $e(i,e);if(e=l.data.pre,l.data.list)for(let e=0;e<l.data.list.length;e++){var s=l.data.list[e];r[Math.floor(s.tl/a)]++}}while(0<=e);var d=1e3/r.length,c=Math.max(...r)/100,p=[];for(let e=0;e<r.length;e++){var m=r[e],u=e*d;p.push([u,m/c])}let t="";for(let e=0;e<p.length-1;e++){var[g,h]=p[e],[f,y]=p[e+1];t=t+"C "+(g+` ${80-(h+y)/2}, ${f} ${80-(h+y)/2}, ${f} ${80-y} `)}var o="M 0 100 L 0 80 "+(t+="L 1000 100 Z"),b=`
    <svg preserveAspectRatio="none" width="100%" height="100%" viewBox="0 0 1000 100" >
        <path fill="rgba(255,255,255,0.3)" d="${o}" />
    </svg>`,o=(-1!==o.indexOf("NaN")&&(console.log(o),S("弹幕高能进度条加载失败","error")),document.createElement("div"));o.id=Qe,o.style="position:absolute;width:100%;height:30px;bottom:0px;pointer-events:none;cursor: default;",o.innerHTML=b,n.insertBefore(o,n.childNodes[0])}}}function Xe(){let o=setInterval(()=>{var e,t=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot;if(t){clearInterval(o);var t=t.querySelector(".ToolBar-positiveUl");(e=document.createElement("style")).innerHTML=`
    #btn-download:hover .download__panel {
        display: block;
    }
    .download__panel {
        width:150px;
        position:absolute;
        text-align: center;
        cursor: default;
        margin-top: 29px;
        margin-left: -38px;
        box-shadow: 0px 3px 10px 0px;
        display: none;
        background: white;
    }
    .download__item {
        height: 30px;
        line-height: 30px;
        width: 100%;
        cursor: pointer;
    }
    .download__item:hover {
        color: rgb(255,119,0)
    }
    `,document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.appendChild(e),e=t,(t=document.createElement("li")).title="下载视频",t.innerHTML=`
    <div class="download__panel">
        <div class="download__item" id="download__default" title="文件超过2GB时可能会下载失败">
            <span class="ToolBar-iconText">浏览器下载</span>
        </div>
        <div class="download__item" id="download__copy" title="可将链接填至第三方下载器中下载">
            <span class="ToolBar-iconText">复制m3u8链接</span>
        </div>
        <div class="download__item" id="download__barrage" title="下载弹幕(.xlsx)">
            <span class="ToolBar-iconText">下载弹幕(.xlsx)</span>
        </div>
        <div class="download__item" id="download__barrageass" title="下载弹幕(.ass)">
            <span class="ToolBar-iconText">下载弹幕(.ass)</span>
        </div>
    </div>
    <span class="ToolBar-icon ">
        <svg t="1634113402576" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7734" width="28" height="28"><path d="M761.98 413.12c0.25-4.4 0.39-8.82 0.39-13.28 0-127.18-102.84-230.28-229.71-230.28s-229.71 103.1-229.71 230.28c0 0.67 0.02 1.33 0.03 2a213.156 213.156 0 0 0-38.91-3.58c-117.2 0-212.21 95.25-212.21 212.74 0 117.49 95.01 212.74 212.21 212.74 2.94 0 5.86-0.08 8.77-0.2 2.54 0.13 5.09 0.2 7.66 0.2h467.35c2.82 0 5.61-0.09 8.39-0.24 108.96-5.16 195.72-95.13 195.72-205.36 0.01-108.3-83.73-197.04-189.98-205.02zM616.33 584.24l-90.86 93.93c-0.78 1.11-1.66 2.17-2.63 3.17-3.95 4.09-8.9 6.62-14.09 7.61-8.34 1.77-17.38-0.51-23.97-6.89a25.975 25.975 0 0 1-3.16-3.68l-93.5-90.45c-10.53-10.19-10.81-26.99-0.62-37.52 10.19-10.53 26.99-10.81 37.52-0.62l45.09 43.62c0-0.06-0.01-0.12-0.01-0.18l-2.43-146.62c-0.3-17.83 13.92-32.52 31.75-32.82 17.83-0.3 32.52 13.92 32.82 31.75l2.43 146.63v0.17l43.52-44.99c10.19-10.53 26.99-10.81 37.52-0.62 10.53 10.17 10.81 26.97 0.62 37.51z" p-id="7735" fill="#515151"></path></svg>
    </span>
    <span class="ToolBar-iconText" id="download-text">下载</span>
    `,t.id="btn-download",e.appendChild(t);{let a=unsafeWindow.$DATA,r=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("#download-text");document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector(".download__panel"),document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("#btn-download").addEventListener("click",()=>{"下载完成"===r.innerText&&S("请刷新页面后再下载","warning")}),document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("#download__default").addEventListener("click",async()=>{var o=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("share-hover").getAttribute("hashid"),n=a.ROOM.vid;if(o!==n)S("视频内容已改变，请刷新网页后重试","error");else{S("开始下载视频...当视频超过2GB时可能会下载失败","info");o=new ol;let e=new tl(a.ROOM.point_id);var i=e.getSign(),n=(e=null,await Ke(n,i));let t="";""!==(t="super"in n.data.thumb_video?n.data.thumb_video.super.url:"high"in n.data.thumb_video?n.data.thumb_video.high.url:"normal"in n.data.thumb_video?n.data.thumb_video.normal.url:0<(i=Object.keys(n.data.thumb_video)).length?n.data.thumb_video[i[0]].url:"")?o.start(t,{filename:a.ROOM.name+".mp4"}).on("progress",e=>{r.innerText=Number(e.percentage).toFixed(2)+"%"}).on("finished",e=>{r.innerText="下载完成",S("视频下载完成","success")}).on("error",e=>{r.innerText="下载失败",S(e,"success")}).on("aborted",()=>{r.innerText="下载中止"}):S("获取m3u8链接失败","error")}}),document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("#download__copy").addEventListener("click",async()=>{var o=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("share-hover").getAttribute("hashid"),n=a.ROOM.vid;if(o!==n)S("视频内容已改变，请刷新网页后重试","error");else{S("正在获取m3u8链接...","info");let e=new tl(a.ROOM.point_id);var o=e.getSign(),n=(e=null,await Ke(n,o));let t="";""!==(t="super"in n.data.thumb_video?n.data.thumb_video.super.url:"high"in n.data.thumb_video?n.data.thumb_video.high.url:"normal"in n.data.thumb_video?n.data.thumb_video.normal.url:0<(o=Object.keys(n.data.thumb_video)).length?n.data.thumb_video[o[0]].url:"")?(GM_setClipboard(t),S("复制成功，可将链接复制到第三方下载器中下载","success")):S("获取m3u8链接失败","error")}}),document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("#download__barrage").addEventListener("click",async()=>{var e=document.getElementsByTagName("demand-video-title")[0].shadowRoot.querySelector(".Title-Main").innerText,t=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("share-hover").getAttribute("hashid");S("正在获取弹幕数据，请勿切换页面...","info");let o=0;var n=[];do{var i=await $e(t,o);o=i.data.pre;for(let e=0;e<i.data.list.length;e++){var a=i.data.list[e];n.push([a.vid,t,a.uid,a.nn,a.ctt,W(a.tl/1e3),_("yyyy-MM-dd hh:mm:ss",new Date(1e3*a.sts))])}}while(0<=o);te(["vid","hashid","uid","昵称","弹幕","时间","发送时间"],n,`【${e}】弹幕数据.xlsx`)}),document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("#download__barrageass").addEventListener("click",async()=>{var e=document.getElementsByTagName("demand-video-title")[0].shadowRoot.querySelector(".Title-Main").innerText,t=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("share-hover").getAttribute("hashid");S("正在获取弹幕数据，请勿切换页面...","info");let o=0;var n=new Xr({title:e}),i=[];do{var a=await $e(t,o);o=a.data.pre;for(let e=0;e<a.data.list.length;e++){var r=a.data.list[e];i.push({time:Number(r.tl),txt:r.ctt,color:r.col})}}while(0<=o);var l,s,d,n=n.generate(i);e=e+".ass",l=n,s=unsafeWindow.URL||unsafeWindow.webkitURL||unsafeWindow,l=new Blob([n]),(n=document.createElementNS("http://www.w3.org/1999/xhtml","a")).href=s.createObjectURL(l),n.download=e,(s=document.createEvent("MouseEvents")).initMouseEvent("click",!0,!1,unsafeWindow,0,0,0,0,0,!1,!1,!1,!1,0,null),n.dispatchEvent(s),(d=n.href)&&0===d.indexOf("blob:")&&setTimeout(function(){try{URL.revokeObjectURL(d)}catch(e){}},1500)})}}else;},1e3)}function Ke(e,o){return new Promise(t=>{fetch("https://v.douyu.com/api/stream/getStreamUrl",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},body:o+"&vid="+e}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})})}function $e(e,o=0){if(!(o<0))return new Promise(t=>{fetch(`https://v.douyu.com/wgapi/vod/center/getBarrageListByPage?vid=${e}&offset=`+o,{method:"GET",mode:"no-cors",credentials:"include"}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})})}let et=`<svg class="icon" width="24" height="24" viewBox="0 0 108 108" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="页面-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="精灵球" transform="translate(0.830769, 0.830769)" fill-rule="nonzero">
            <path d="M53.1692307,106.338461 C23.8276922,106.338461 0,82.5107692 0,53.1692307 C0,51.0030769 1.77230775,49.2307692 3.9384615,49.2307692 L33.476923,49.2307692 C35.6430769,49.2307692 37.4153845,51.003077 37.4153846,53.1692307 C37.4153846,61.8338461 44.5046154,68.9230769 53.1692307,68.9230769 C61.8338461,68.9230769 68.9230769,61.8338461 68.9230769,53.1692307 C68.9230769,51.0030769 70.6953846,49.2307692 72.8615385,49.2307692 L102.4,49.2307692 C104.566154,49.2307692 106.338461,51.003077 106.338461,53.1692307 C106.338461,82.5107692 82.5107692,106.338461 53.1692307,106.338461 Z" id="路径" fill="#33363A"></path>
            <path d="M8.07384612,57.1076922 C10.0430769,80.2461537 29.5384615,98.4615385 53.1692307,98.4615385 C76.8,98.4615385 96.2953846,80.2461539 98.2646154,57.1076922 L76.5046154,57.1076922 C74.6338461,68.2338461 64.8861539,76.8 53.1692307,76.8 C41.4523076,76.8 31.7046154,68.2338461 29.8338461,57.1076922 L8.07384612,57.1076922 Z" id="路径" fill="#FFFFFF"></path>
            <path d="M53.1692308,3.9384615 C25.9938461,3.9384615 3.9384615,25.9938461 3.9384615,53.1692307 L33.476923,53.1692307 C33.476923,42.3384615 42.3384615,33.476923 53.1692308,33.476923 C64,33.476923 72.8615385,42.3384615 72.8615385,53.1692307 L102.4,53.1692307 C102.4,25.9938461 80.3446154,3.9384615 53.1692308,3.9384615 Z" id="路径" fill="#D60909"></path>
            <path d="M102.4,57.1076922 L72.8615385,57.1076922 C70.6953846,57.1076922 68.923077,55.3353845 68.9230769,53.1692307 C68.9230769,44.5046154 61.8338461,37.4153846 53.1692307,37.4153846 C44.5046154,37.4153846 37.4153846,44.5046154 37.4153846,53.1692307 C37.4153846,55.3353846 35.6430769,57.1076922 33.476923,57.1076922 L3.9384615,57.1076922 C1.77230762,57.1076922 0,55.3353845 0,53.1692307 C0,23.8276922 23.8276923,0 53.1692307,0 C82.5107692,0 106.338461,23.8276922 106.338461,53.1692307 C106.338461,55.3353846 104.566154,57.1076922 102.4,57.1076922 Z" id="路径" fill="#33363A"></path>
            <path d="M76.5046154,49.2307693 L98.3630769,49.2307693 C96.2953846,26.0923076 76.8,7.876923 53.1692307,7.876923 C29.5384615,7.876923 10.0430769,26.0923076 8.07384612,49.2307693 L29.9323076,49.2307693 C31.7046154,38.1046154 41.4523076,29.5384615 53.1692307,29.5384615 C64.8861539,29.5384615 74.6338461,38.1046154 76.5046154,49.2307693 L76.5046154,49.2307693 Z" id="路径" fill="#D60909"></path>
            <path d="M53.1692307,76.8 C40.1723076,76.8 29.5384615,66.1661539 29.5384615,53.1692307 C29.5384615,40.1723076 40.1723076,29.5384615 53.1692307,29.5384615 C66.1661539,29.5384615 76.8,40.1723076 76.8,53.1692307 C76.8,66.1661539 66.1661539,76.8 53.1692307,76.8 Z" id="路径" fill="#33363A"></path>
            <path d="M53.1692307,37.4153846 C44.5046154,37.4153846 37.4153846,44.5046154 37.4153846,53.1692307 C37.4153846,61.8338461 44.5046154,68.9230769 53.1692307,68.9230769 C61.8338461,68.9230769 68.9230769,61.8338461 68.9230769,53.1692307 C68.9230769,44.5046154 61.8338461,37.4153846 53.1692307,37.4153846 L53.1692307,37.4153846 Z" id="路径" fill="#FFFFFF"></path>
            <path d="M43.3230769,53.1692307 C43.3230769,58.6071114 47.7313501,63.0153846 53.1692307,63.0153846 C58.6071114,63.0153846 63.0153846,58.6071114 63.0153846,53.1692307 C63.0153846,47.7313501 58.6071114,43.3230769 53.1692307,43.3230769 C47.7313501,43.3230769 43.3230769,47.7313501 43.3230769,53.1692307 Z" id="路径" fill="#33363A"></path>
        </g>
    </g>
</svg>`;let tt=null,ot=null;function nt(){return document.querySelector(".PlayerToolbar-ContentCell .PlayerToolbar-Wealth")||document.querySelector(".PlayerToolbar-ContentRow")}function it(){var e=document.getElementsByClassName("PlayerToolbar-ContentRow")[0];return e&&"hidden"===e.style.visibility}function at(){return document.getElementById("js-player-dialog")||document.getElementsByClassName("room-Player-Box")[0]||document.body}function rt(e){tt||(tt=e.parentNode,ot=e.nextSibling)}function lt(){var e,t,o,n=document.querySelector(".ex-panel.ex-panel--floating");n&&(o=document.getElementById("js-player-toolbar"),t=document.getElementById("ex-vtoolbar-menu"),n.style.position="fixed",n.style.top="auto",t?(t=t.getBoundingClientRect(),n.style.bottom=window.innerHeight-t.top+8+"px",e=n.offsetWidth||n.scrollWidth||320,t=t.left+t.width/2-e/2,t=Math.max(8,Math.min(t,window.innerWidth-e-8)),n.style.left=t+"px",n.style.right="auto"):o?(e=o.getBoundingClientRect(),n.style.bottom=window.innerHeight-e.top+8+"px",t=n.offsetWidth||n.scrollWidth||320,o=e.left+e.width/2-t/2,o=Math.max(8,Math.min(o,window.innerWidth-t-8)),n.style.left=o+"px",n.style.right="auto"):(n.style.bottom="72px",n.style.right="12px",n.style.left=""))}function st(){var e=document.querySelector(".ex-panel");e&&!e.classList.contains("ex-panel--floating")&&(rt(e),at().appendChild(e),e.classList.add("ex-panel--floating")),lt()}function dt(){var e=document.querySelector(".ex-panel"),t=nt();e&&t&&e.classList.contains("ex-panel--floating")&&(ot&&ot.parentNode===t?t.insertBefore(e,ot):t.insertBefore(e,t.childNodes[0]),e.classList.remove("ex-panel--floating"))}function ct(){var e=document.querySelector(".ex-panel");e&&"block"===e.style.display&&(st(),lt())}function pt(){dt()}function mt(){var e=document.querySelector(".ex-panel");e&&(clearTimeout(U),U=null,e.style.display="none")}function ut(){mt()}function gt(){var e=document.getElementsByClassName("ex-panel")[0];e&&((it()?st:dt)(),"block"!==e.style.display?(e.style.display="block",clearTimeout(U),e.classList.contains("ex-panel--floating")&&lt()):(e.style.display="none",clearTimeout(U)))}let ht=[],ft=null,yt=0,bt=!1,vt=0;async function xt(){let o=await new Promise(t=>{fetch("https://www.douyu.com/japi/revenuenc/web/actfans/fishing/reelIn",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&rid=`+B}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})});if(0!==o.error)console.log(o,"收杆失败"),0==(await Et()).data.fishing.stat&&(bt=!1,yt=0);else{let t="【自动钓鱼】";var n=ht.find(e=>e.fishId==o.data.fish.id);if(n&&(t+=`获得${n.name}${o.data.fish.wei}斤`),o.data.awards&&0<o.data.awards.length)for(let e=0;e<o.data.awards.length;e++){var i=o.data.awards[e];t+=`${n?"，":""}获得${i.awardName}x`+i.awardNum}"【自动钓鱼】"!==t&&S(t,"success"),bt=!1}}function wt(){let t;try{t=JSON.parse(localStorage.getItem("ExSave_AutoFish"))}catch(e){t=null}return t&&"object"==typeof t||(t={}),Array.isArray(t.rids)||(t.rids=[]),t.modes&&"object"==typeof t.modes||(t.modes={}),t}function _t(t){document.querySelectorAll('input[name="autofish_mode"]').forEach(e=>e.disabled=t)}function kt(){var e,t=document.getElementById("extool__autofish_start"),o=document.querySelector('input[name="autofish_mode"]:checked');t&&o&&(t=t.checked,o=o.value,e=wt(),t?(e.rids.includes(B)||e.rids.push(B),e.modes[B]=o):(e.rids=e.rids.filter(e=>e!==B),delete e.modes[B]),localStorage.setItem("ExSave_AutoFish",JSON.stringify(e)))}function Et(){return new Promise(t=>{fetch(`https://www.douyu.com/japi/revenuenc/web/actfans/fishing/homePage?rid=${B}&opt=1`,{method:"GET",mode:"no-cors",cache:"default",credentials:"include"}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})})}function Bt(e,t){fetch("https://www.douyu.com/japi/prop/backpack/web/v5?rid="+e,{method:"GET",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"}}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})}function It(){return document.getElementById("extool__fullscreen").checked}function St(){return document.getElementById("extool__highestvideoquality").checked}let Ct,Tt=0,Nt,Mt,Lt;function At(e){if(0!=e.length&&0!=e[0].addedNodes.length){let i=e[0].addedNodes[0],a=i.lastElementChild;if(null!=a&&-1!=a.innerHTML.indexOf("is-self")){let n=setTimeout(()=>{i.className="Barrage-listItem js-noblefloating-barrage",a.className="js-noblefloating-barragecont Barrage-notice--noble",a.setAttribute("style","background-color: #fff3df");a.getElementsByClassName("Barrage-nickName")[0].setAttribute("class","Barrage-nickName is-self js-nick");var e,t=a.querySelector(".UserLevel"),t=(null!=t&&(t.className="UserLevel UserLevel--150",t.setAttribute("title","用户等级：150")),a.querySelector(".RoomLevel")),t=(null!=t&&(t.className="RoomLevel RoomLevel--18",t.setAttribute("title","房间等级：18")),i.querySelector(".FansMedal")),t=(null!=t&&(t.style="display:none;"),document.getElementsByClassName("FansMedal-name")[0]),o=(document.getElementsByClassName("DiamondsFansRankList-item DiamondsFansRankList-item--top")[0],t?(o=document.createElement("div"),e=document.createElement("span"),o.className="FansMedal level-50 js-fans-dysclick Barrage-icon",e.className="FansMedal-name js-fans-dysclick",e.innerHTML=t.innerText,o.appendChild(e),a.insertBefore(o,a.querySelector(".UserLevel"))):((t=document.createElement("div")).className="FansMedal level-50 js-fans-dysclick Barrage-icon",t.setAttribute("data-rid","4042402"),(e=document.createElement("span")).className="FansMedal-name js-fans-dysclick",e.setAttribute("data-rid","4042402"),e.innerHTML="二九汪",t.appendChild(e),a.insertBefore(t,a.querySelector(".UserLevel"))),i.querySelector(".Barrage-nobleImg"));null!=o?(o.src="//res.douyucdn.cn/resource/2019/08/15/common/4e85776071ffbae2867bb9d116e9a43c.gif",o.title="幻神"):(e=document.createElement("span"),t=document.createElement("img"),e.className="Barrage-icon Barrage-noble",t.className="Barrage-nobleImg",t.setAttribute("src","//res.douyucdn.cn/resource/2019/08/15/common/4e85776071ffbae2867bb9d116e9a43c.gif"),t.setAttribute("title","幻神"),e.appendChild(t),a.insertBefore(e,a.firstElementChild)),clearTimeout(n)},100)}}}function Dt(t){if(0!=t.length&&0!=t[0].addedNodes.length){t=t[0].addedNodes[0];if(-1==t.className.indexOf("noble-d35c82")&&-1!=t.innerHTML.indexOf("border: 2px solid rgb(2, 255, 255)")){t.style.zIndex="30",t.className="danmuItem-f8e204 noble-d35c82";var o=document.createElement("img"),o=(o.className="super-noble-icon-54c62c",o.setAttribute("src","https://shark2.douyucdn.cn/front-publish/live_player-master/assets/images/h1_dcd226.png"),o.setAttribute("style","margin-left: -57px; margin-top: -4px;"),t.insertBefore(o,t.firstElementChild),document.createElement("img"));o.className="super-user-icon-253711";let e=document.getElementsByClassName("Avatar is-circle")[0];null!=e&&(e=e.getElementsByTagName("img")[0].getAttribute("src"),o.setAttribute("src",e.replace(new RegExp("_middle"),"_small"))),t.insertBefore(o,t.firstElementChild);t.getElementsByClassName("afterpic-f864c2")[0].remove();var o=t.getElementsByClassName("text-edf4e7")[0],n=(o.className="super-text-188279",o.setAttribute("style","font: bold 23px SimHei, 'Microsoft JhengHei', Arial, Helvetica, sans-serif; color: rgb(255, 255, 255); background: url('https://shark2.douyucdn.cn/front-publish/live_player-master/assets/images/h2_8e5e64.png'); height: 44px;"),document.createElement("div")),o=(n.setAttribute("class","afterpic-f864c2"),n.setAttribute("style","margin-top: 7px; margin-left: -1px;"),o.appendChild(n),document.createElement("img"));o.className="super-tail-6a0446",o.setAttribute("src","https://shark2.douyucdn.cn/front-publish/live_player-master/assets/images/h3_fd2e5b.png"),t.appendChild(o),console.log(o)}}}function jt(e){if(0!=e.length&&0!=e[0].addedNodes.length){e=e[0].addedNodes[0];if(e.getElementsByClassName("Banner4gift-senderName")[0].title==Ct){var i=e.getElementsByClassName("Banner4gift-objectName")[0].title;if("粉丝荧光棒"==i&&(e.className="Banner4gift Banner4gift--size2",e.getElementsByClassName("Banner4gift-bg")[0].src="https://gfs-op.douyucdn.cn/dygift/2019/03/15/6651f2de52dd359c7b553a77b9d00020.png",e.getElementsByClassName("Banner4gift-objectName")[0].title="超级火箭",e.getElementsByClassName("Banner4gift-objectName")[0].innerText="超级火箭",e.getElementsByClassName("Banner4gift-headerImg")[0].src="https://gfs-op.douyucdn.cn/dygift/2018/11/27/3adbb0c17d9886c1440d55c9711f4c79.gif",!(0<document.getElementsByClassName("ex_giftAnimation_exist").length))){Tt++;i=document.createElement("div");let t="ex_giftAnimation_"+String(Tt),o=(i.id=t,i.className="ex_giftAnimation_exist",document.getElementsByClassName("ex_giftAnimation")[0].appendChild(i),new SVGA.Player("#"+t)),n=new SVGA.Parser("#"+t);n.load("https://gfs-op.douyucdn.cn/dygift/2018/11/27/6c6349672e662750ad5c019b240d57f2.svga",e=>{o.setVideoItem(e),o.startAnimation(),setTimeout(()=>{o=null,n=null,document.getElementById(t).remove()},4e3)})}}}}function Pt(){return document.getElementById("extool__p2p").checked}let zt=[],Ot;function Rt(t){fetch("https://www.douyu.com/japi/interactnc/web/propredpacket/grab_prp",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"activityid="+t+"&ctn="+x()}).then(e=>e.json()).then(e=>{2==e.data.isSuc&&Rt(t)})}function Ft(){try{var e=localStorage.getItem("ExSave_TabSwitch");if(null!=e)return!!JSON.parse(e).isEnableTabSwitch}catch(e){}e=document.getElementById("extool__tabSwitch");return!!e&&e.checked}function Ht(e){localStorage.setItem("ExSave_TabSwitch",JSON.stringify({isEnableTabSwitch:!!e}));var t=document.getElementById("extool__tabSwitch");t&&(t.checked=!!e),e&&Gt()}function Gt(){Object.defineProperty(document,"hidden",{value:!1,writable:!1}),Object.defineProperty(document,"visibilityState",{value:"visible",writable:!1}),Object.defineProperty(document,"webkitVisibilityState",{value:"visible",writable:!1}),document.dispatchEvent(new Event("visibilitychange")),document.hasFocus=function(){return!0},document.addEventListener("visibilitychange",function(e){e.stopImmediatePropagation()},!0,!0)}var Vt=!1;function qt(){var e=document.getElementById("extool__treasure_delay").value;return Number(e)}async function Ut(e,t,o){return(await fetch("https://www.douyu.com/japi/prop/donate/mainsite/v1",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"propId="+e+"&propCount="+t+"&roomId="+o+"&bizExt=%7B%22yzxq%22%3A%7B%7D%7D"})).json()}let Wt;function Yt(e){var t=document.getElementsByClassName("Header-follow-tab is-active")[0].innerText;"特别关注"!==t&&"视频动态"!==t&&0!=(t=document.getElementsByClassName("Header-follow-listWrap")).length&&(document.getElementsByClassName("Header-follow-listBox")[0].style.display="none",(async e=>{var i=await GM_getValue("Ex_LoadInCurrentPage",!1),a=await new Promise(t=>{fetch("https://www.douyu.com/wgapi/livenc/liveweb/follow/list?sort=1&cid1=0",{method:"GET",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"}}).then(e=>e.json()).then(e=>{t(e)})});if("0"==a.error){let t=0,o=`
        <div id="refreshFollowList" style="color: grey; position: absolute; top: 0px; cursor: default; display: flex; align-items: center; justify-content: space-between; width: calc(100% - 10px); padding: 0 5px;">
            <label style="display: flex; align-items: center; cursor: pointer; color: inherit;">
                <input type="checkbox" id="loadInCurrentPageCheckbox" ${i?"checked":""} style="margin-right: 5px;">
                在当前页面加载
            </label>
            <span>长按弹出同屏播放</span>
        </div>
    `;var r=Math.floor(Date.now()/1e3);for(let e=0;e<a.data.list.length;e++){var l=a.data.list[e];if("1"==l.show_status&&"0"==l.videoLoop&&(o+=`<li class="DropPaneList FollowList ExFollowListItem" rid="${l.room_id}"><a><div class="DropPaneList-cover"><div class="LazyLoad is-visible DyImg "><img src="${String(l.avatar_small).replace("_big","_small")}" alt="${l.nickname}" class="DyImg-content is-normal "></div></div><div class="DropPaneList-info"><p><span class="DropPaneList-hot"><i></i>${l.online}</span><span class="DropPaneList-title">${l.room_name}</span></p><p><span class="DropPaneList-name">${l.nickname}</span><span class="DropPaneList-time">已播${y(r-Number(l.show_time))}</span></p></div></a></li>`,t++),10<=t)break}e.innerHTML+=o;i=e.querySelector("#loadInCurrentPageCheckbox");i&&i.addEventListener("change",async e=>{e=e.target.checked;await GM_setValue("Ex_LoadInCurrentPage",e),S(`【关注列表】已${e?"开启":"关闭"}当前页加载功能（${e?"当前页面直接加载关注的直播间":"使用新网页打开关注的直播间"}）`,"info")});let n=document.getElementsByClassName("ExFollowListItem");for(let o=0;o<n.length;o++){var s=new el(n[o]);s.longClick(()=>{gn(A.length,n[o].getAttribute("rid"),"Douyu"),document.querySelector(".Follow .public-DropMenu").className="public-DropMenu"}),s.click(async e=>{e.preventDefault();var e=await GM_getValue("Ex_LoadInCurrentPage",!1),t="https://www.douyu.com/"+n[o].getAttribute("rid");e?window.location.href=t:w(t,!0)}),n[o].addEventListener("mousedown",e=>{1==e.button&&w("https://www.douyu.com/"+n[o].getAttribute("rid"),!1)})}}})(t[0]))}async function Qt(){e=B;var e,n,t=await new Promise((t,o)=>{fetch("https://www.douyu.com/japi/interactnc/web/userLevel/userLevelDetail?rid="+e,{method:"GET",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"}}).then(e=>e.json()).then(e=>{e=e.data.taskIds.join(",");t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}),o=(n=t,await new Promise((t,o)=>{fetch("https://www.douyu.com/japi/tasksys/userLevelTask/getTaskStatus?taskIds="+n,{method:"GET",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"}}).then(e=>e.json()).then(e=>{t(e.data.list)}).catch(e=>{console.log("请求失败!",e),o(e)})}));for(let e=0;e<o.length;e++){var i=o[e],a=i.taskId,r=i.name;if(1==i.taskStatus&&0==i.prizeStatus){var l=await((e,n)=>new Promise((t,o)=>{fetch("https://www.douyu.com/japi/tasksys/userLevelTask/getPrize",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&taskIds=${n}&roomId=`+e}).then(e=>e.json()).then(e=>{t(e.data.list)}).catch(e=>{console.log("请求失败!",e),o(e)})}))(B,a);for(let e=0;e<l.length;e++)S(`【等级任务】${r} 获得`+l[e].name+l[e].num,"success")}}}let Jt="",Zt=0;let Xt=0;let n=0,i=0,a=0,Kt=0,$t=!1,eo=5;function to(){var e,t;(e=document.createElement("div")).className="livetool__cell",e.innerHTML=`
        <div class='livetool__cell_title'>
            <span id='count_bp__title'>自动发送计数弹幕(白胖直播间专属)</span>
        </div>
    `+`
        <div class='count_bp__panel' style='display:none;'>
            <div id="count_bp__status">当前已扣命数：0，已加命数：0，剩余命数：0</div>
            <label>已加命数：<input id="count_bp__add_input" type="text" placeholder="0" /></label>
            <label>剩余命数：<input id="count_bp__original_input" type="text" placeholder="0" /></label>
            <div class="count_bp__buttons">
                <input style="width:60px;margin-left:10px;" type="button" id="count_bp__add_btn" value="计数+1"/>
                <input style="width:70px;margin-left:10px;" type="button" id="count_bp__reset_btn" value="重置计数"/>
                <input style="width:70px;margin-left:10px;" type="button" id="count_bp__summary_btn" value="发送汇总"/>
            </div>
        </div>
    `,(t=document.getElementsByClassName("livetool")[0]).insertBefore(e,t.childNodes[0]),document.getElementById("count_bp__title").addEventListener("click",()=>{var e=document.getElementsByClassName("count_bp__panel")[0];e.style.display="block"===e.style.display?"none":"block"}),document.getElementById("count_bp__add_input").addEventListener("change",()=>{i=Number(document.getElementById("count_bp__add_input").value)||0,oo(),no()}),document.getElementById("count_bp__original_input").addEventListener("change",()=>{a=Number(document.getElementById("count_bp__original_input").value)||0,Kt=a-n,oo(),no()}),document.getElementById("count_bp__add_btn").addEventListener("click",()=>{if(!$t){n++,Kt=a-n,oo(),no();let e;E(e=Kt<=0?`当前已扣${n}命，已团灭！`:`当前已扣${n}命！`),0<eo&&($t=!0,setTimeout(()=>{$t=!1},1e3*eo))}}),document.getElementById("count_bp__reset_btn").addEventListener("click",()=>{n=0,i=0,a=0,Kt=0,oo(),no()}),document.getElementById("count_bp__summary_btn").addEventListener("click",()=>{{let e=`${a} - ${n} = `+Kt,t=`${a} - ${n} + ${i} = `+(Kt+i),o;E(o=Kt<=0?`当前已扣${n}命，已加${i}命，已团灭！（${e}）`:`当前已扣${n}命，已加${i}命，剩余${t}命`)}}),n=null!==(ret=localStorage.getItem("ExSave_CountBpReduce"))?Number(ret):0,null!==(ret=localStorage.getItem("ExSave_CountBpAdd"))?(i=Number(ret),document.getElementById("count_bp__add_input").value=ret):i=0,null!==(ret=localStorage.getItem("ExSave_CountBpOriginal"))?(a=Number(ret),document.getElementById("count_bp__original_input").value=ret):a=0,Kt=null!==(ret=localStorage.getItem("ExSave_CountBpCurrent"))?Number(ret):0,oo()}function oo(){var e=document.getElementById("count_bp__status"),t=`${a} - ${n} = `+Kt;document.getElementById("count_bp__add_input").value=i,document.getElementById("count_bp__original_input").value=a,Kt<=0?e.innerHTML=`当前已扣${n}命，已加${i}命，已团灭！`:e.innerHTML=`当前已扣${n}命，已加${i}命，剩余${t}命`}function no(){localStorage.setItem("ExSave_CountBpReduce",n),localStorage.setItem("ExSave_CountBpAdd",i),localStorage.setItem("ExSave_CountBpOriginal",a),localStorage.setItem("ExSave_CountBpCurrent",Kt)}window.countBpInitialized||(window.countBpInitialized=!0,setTimeout(to,1e3));let io=!1,T=[];function ao(){var e=T;localStorage.setItem("ExSave_Enter",JSON.stringify(e))}function ro(){var e,t=document.getElementById("enter__select");t.options.length=0;for(e of T)t.options.add(new Option(`【${e.level}级】`+e.word,""))}let lo=!1,N={};function so(){var e=N;localStorage.setItem("ExSave_Gift",JSON.stringify(e))}function M(e){return v(e,"type@=","/")}let co=!1,L={},po={},mo=[];function uo(){var e=L;localStorage.setItem("ExSave_Mute",JSON.stringify(e))}function go(e,o,n){return new Promise(t=>{fetch("https://www.douyu.com/room/roomSetting/addMuteUser",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"ban_nickname="+o+"&room_id="+e+"&ban_time="+n+"&reason=7"}).then(e=>e.json()).then(e=>{t(e)})})}let ho={day:{},week:{},all:{}};function fo(t,o){if(o)for(let e="week"===t?10:0;e<o.length;e++){var n=o[e],i=n.innerHTML.split("<span")[0],a=n.parentElement,r=ho[t][i];a.className.includes("--top")?n.innerHTML=i+`<span class="exRankPoint--top">${r}</span>`:n.innerHTML=i+`<span class="exRankPoint">${r}</span>`}}function yo(t){var o={};for(let e=0;e<t.length;e++){var n=t[e];o[n.nickname]=Number(n.gold)/100}return o}let bo=!1,vo=0,xo=!1,wo=0,_o=!1;function ko(){localStorage.setItem("ExSave_RedPacketDelay",vo),localStorage.setItem("ExSave_RedPacketCd",wo)}let Eo=!1,Bo={},Io=!1,So=0;function Co(){var e=Bo;localStorage.setItem("ExSave_Reply",JSON.stringify(e))}var To=0;function No(i,a,r,l){GM_xmlhttpRequest({method:"POST",url:"https://pcapi.douyucdn.cn/h5nc/member/getRedPacket?token="+m,data:"room_id="+i+"&package_room_id="+i+"&device_id="+r+"&packerid="+a+"&version=1",responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded"},onload:function(t){t=t.response;if("-1"==t.data.code&&"0"!=t.data.validate){var e=JSON.parse(t.data.geetest.validate_str),o=e.success;null!=unsafeWindow.initGeetest?unsafeWindow.initGeetest({gt:e.gt,challenge:e.challenge,offline:!o,product:"float"},o=>{let n=document.getElementById(l);o.appendTo("#"+l),o.onSuccess(()=>{var e=o.getValidate(),t=e.geetest_challenge,t="room_id="+i+"&package_room_id="+i+"&device_id="+r+"&packerid="+a+"&version=1"+"&geetest_challenge="+t+"&geetest_validate="+e.geetest_validate+"&geetest_seccode="+encodeURIComponent(e.geetest_seccode);GM_xmlhttpRequest({method:"POST",url:"https://pcapi.douyucdn.cn/h5nc/member/getRedPacket?token="+m,data:t,responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded"},onload:function(e){e=e.response;let t="";""!=(t=""==e.data.prop_id?"鱼丸x"+e.data.silver:e.data.prop_name+"x"+e.data.prop_count)&&S("【宝箱】获得"+t,"success"),null!=n&&n.remove()}})})}):S("宝箱验证初始化失败","error")}else if("领取失败"!=t.data.msg&&"验证码不正确"!=t.data.msg){let e="";""!=(e=""==t.data.prop_id?"鱼丸x"+t.data.silver:t.data.prop_name+"x"+t.data.prop_count)&&S("【宝箱】获得"+e,"success")}else S("【宝箱】领取失败","error")}})}let Mo=!1,Lo={},Ao={},Do={},jo=0,Po,zo=!1;function Oo(){var e=Lo;localStorage.setItem("ExSave_Vote",JSON.stringify(e))}function Ro(){for(var e in Do){var e=Do[e],t=document.getElementsByClassName("vote__option-num")[e.index],o=document.getElementsByClassName("vote__progress-bar")[e.index],n=String(Number(100*Number(e.num/jo)).toFixed(1))+"%";t.innerText=e.num+`（${n}）`,o.style.width=n}}let Fo=[],Ho={},Go="",Vo=!1,qo=0;async function Uo(){100<Object.keys(Ho).length&&(Ho={});let t="";var o=await new Promise((t,o)=>{GM_xmlhttpRequest({method:"GET",url:"https://www.douyu.com/lapi/interact/lottery/getHallList",responseType:"json",onload:e=>{e=e.response;t(e)},onerror:e=>{o(e)}})});if(o.data.list){for(let e=0;e<o.data.list.length;e++){var n,i,a,r=o.data.list[e];0===r.status&&(a="command_content"in(i=(n=await(e=>new Promise((t,o)=>{fetch("https://www.douyu.com/member/lottery/activity_info?room_id="+e,{method:"GET",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"}}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{o(e)})}))(r.room_id)).data.join_condition)?"发送弹幕":`赠送 ${i.gift_name}（${i.gift_price}）x`+i.gift_num,l=Number(n.data.start_at)+Number(n.data.join_condition.expire_time),l=1e3*l,s=(new Date).getTime(),c=d=void 0,s=-1==(s=l<s?-1:(d="",c=(s=(l=Math.abs(l-s))%864e5)%36e5,(d=(d=(d+=0<(l=Math.floor(l/864e5))?l+"天":"")+(0<(l=Math.floor(s/36e5))?l+"时":""))+(0<(s=Math.floor(c/6e4))?s+"分":""))+(0<(l=Math.round(c%6e4/1e3))?l+"秒":"")))?"已结束":"距结束："+s,(d=-1!==Fo.indexOf(String(r.room_id))||i.lottery_range<=1)&&Vo&&((c=n.data.prize_name+"|"+n.data.start_at)in Ho||(Ho[c]=1,S(`<a style="font-size:14px;border:none;" target="_blank" href="https://www.douyu.com/${r.room_id}">【${n.data.prize_name}x${n.data.prize_num}】${a}</a>`,"special",{timeout:100}))),t+=`
            <a class="lottery__a" href="https://www.douyu.com/${r.room_id}" target="_blank">
                <div class="lottery__item">
                    <div class="lottery__img">
                        <div class="lottery__anchor">${r.anchor_name}</div>
                        <img loading="lazy" src="${r.verticalSrc}"/>
                        <div class="lottery__expireTime">${s}</div>
                    </div>
                    <div class="lottery__info">
                        <div class="lottery__prize">${n.data.prize_name}x${n.data.prize_num}</div>
                        <div class="lottery__jointext">${a}</div>
                        <div style="color:${d?"#64ce83":"#e74c3c"}" class="lottery__condition">${(e=>{let t="";switch(e.lottery_range){case 0:t="所有人可参与";break;case 1:t="关注主播";break;case 2:t="成为粉丝";break;case 3:t="关注主播+成为粉丝"}return t})(i)}</div>
                    </div>
                </div>
            </a>
        `)}var l,s,d,c,e=document.getElementsByClassName("lottery__nodata")[0],e=(""!==t.trim()?e.style.display="none":e.style.display="block",Go=t,document.getElementsByClassName("lottery__wrap")[0]);e&&(e.innerHTML=Go)}}let Wo="ExSave_MonthCost",Yo="ExSave_MonthCost_SeeStatus",Qo=0,Jo=[],Zo='<svg t="1619141525444" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4635" width="16" height="16" style="/* display: inline-block; */"><path d="M1009.592 531.212C863.184 730.624 696.96 832 512 832c-184.96 0-351.184-101.376-497.592-300.788C10.384 525.864 8 519.212 8 512s2.384-13.864 6.408-19.212C160.816 293.376 327.04 192 512 192c184.96 0 351.184 101.376 497.592 300.788 4.024 5.348 6.408 12 6.408 19.212s-2.384 13.864-6.408 19.212zM512 768c156.864 0 300.54-84.332 432.012-256C812.54 340.332 668.864 256 512 256c-156.864 0-300.54 84.332-432.012 256C211.46 683.668 355.136 768 512 768z m0-64c-106.04 0-192-85.96-192-192s85.96-192 192-192 192 85.96 192 192-85.96 192-192 192z m0-64c70.692 0 128-57.308 128-128s-57.308-128-128-128-128 57.308-128 128 57.308 128 128 128z" p-id="4636" fill="#707070"></path></svg>',Xo='<svg t="1619143157694" class="icon" viewBox="0 0 1186 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1733" width="16" height="16"><path d="M591.707784 915.740462A642.870487 642.870487 0 0 1 2.965954 526.459025a39.298888 39.298888 0 0 1 0-28.91805 632.489649 632.489649 0 0 1 584.292899-388.539948h8.897862a630.265183 630.265183 0 0 1 584.292899 388.539948 39.298888 39.298888 0 0 1 0 28.91805 637.680068 637.680068 0 0 1-336.635757 337.377245 646.577929 646.577929 0 0 1-252.106073 51.904192zM77.856287 512.370744a565.755688 565.755688 0 0 0 1026.961505 0 556.116338 556.116338 0 0 0-508.661077-329.220872h-8.897862a556.857827 556.857827 0 0 0-509.402566 329.220872z" p-id="1734" fill="#707070"></path><path d="M590.966296 732.592814a218.739093 218.739093 0 1 1 222.446535-218.739093 218.739093 218.739093 0 0 1-222.446535 218.739093z m0-362.587852a144.590248 144.590248 0 1 0 148.29769 143.848759 148.29769 148.29769 0 0 0-148.29769-143.848759z" p-id="1735" fill="#707070"></path><path d="M1137.443284 1023.997776a37.074423 37.074423 0 0 1-24.469119-8.897862L20.761677 65.253208A37.074423 37.074423 0 0 1 68.958426 8.900086l1092.212489 946.880752a37.074423 37.074423 0 0 1 0 52.64568 35.591446 35.591446 0 0 1-23.727631 15.571258z" p-id="1736" fill="#707070"></path></svg>',Ko=0;function $o(){return document.getElementById("monthcost__money")}function en(){return document.getElementsByClassName("monthcost__icon")[0]}function tn(){var e=en(),t=$o();e&&t&&(1===Ko?e.innerHTML=Zo:(t.innerText="***",e.innerHTML=Xo),rn())}function on(e){return new Promise(t=>{fetch(e,{method:"GET",mode:"no-cors",credentials:"include"}).then(e=>e.json()).then(e=>{t(e)}).catch(()=>{t({error:-1,data:[]})})})}async function nn(){o=new Date,e=o.getMonth(),t=o.getFullYear(),t=new Date(t,e,1);var e,t,o,[n,i]=[Math.round(new Date(t).getTime()/1e3).toString(),Math.round(o.getTime()/1e3).toString()],[a,r]=(e=new Date,t=e.getMonth(),o=e.getFullYear(),o=new Date(o,t,1),[(t=e=>e.getFullYear()+`-${(e.getMonth()+1).toString().padStart(2,"0")}-`+e.getDate().toString().padStart(2,"0"))(o),t(e)]);let l=[],s=!0,d=0;for(;s;){let e=`https://www.douyu.com/wjapi/nc/exchange/consume/giftList?queryType=0&consumeType=0&startDate=${n}&endDate=${i}&tradeStartDate=${a}&tradeEndDate=${r}&direction=`+1;0!==d&&(e+="&id="+d);var c=await on(e);1e3==c.error?await new Promise(e=>setTimeout(e,2e3)):(c=c&&c.data||[],l=l.concat(c),c.length<20?s=!1:d=c[c.length-1].id)}var p,m,u={};for(p of l){var g=Math.abs(p.amount),h=(Qo+=g,p.consumeTypeDesc||"其他");u[h]||(u[h]=0),u[h]+=g}for(m in u)Jo.push({title:m,money:u[m]})}async function an(){Qo=0,Jo=[],await nn();{let e=1;var n=[];let t=!0;for(var i=new Date,a=i.getMonth(),r=i.getFullYear();t;){var l,s=((await on("https://www.douyu.com/japi/interactnc/web/dFansbadge/myLogs?type=0&page="+e)||{}).data||{}).list||[];for(l of s){var d=new Date(1e3*l.consumeTime);d.getMonth()===a&&d.getFullYear()===r&&n.push(l)}if(!s[s.length-1])break;var c=new Date(1e3*s[s.length-1].consumeTime);s.length<20||c.getMonth()!==a||c.getFullYear()!==r?t=!1:e++}let o=0;for(let e of n)o+=Math.abs(e.consumeMoney);0<o&&Jo.push({title:"钻粉充值/续费",money:o}),Qo+=o}await 0;{let e={monthCost:Qo,updateTime:(new Date).getTime(),typeDetail:Jo},t=localStorage.getItem(Wo);if(null!==t)try{t=JSON.parse(t)}catch(e){t={}}else t={};t[I]=e,localStorage.setItem(Wo,JSON.stringify(t))}rn();i=$o();i&&(i.innerText=String(Qo/100))}function rn(){var e=document.getElementsByClassName("month-cost")[0];if(e)if(1===Ko&&0<Jo.length){let t="数据每日更新，根据个人中心消费数据统计。\n--- ---\n";Jo.forEach(e=>{t+=`${e.title}: ${String(e.money/100)} 元\n`}),e.title=t}else e.title="数据每日更新，根据个人中心消费数据统计。"}function ln(){if(1===Ko){let e=1;var t,o=(new Date).getDate(),n=(()=>{let t=localStorage.getItem(Wo);if(null!==t)try{t=JSON.parse(t)}catch(e){t={}}else t={};return t})();I in n?(n=n[I],e=Math.abs(o-new Date(n.updateTime).getDate()),o=n.monthCost,n=n.typeDetail||[],(t=$o())&&(t.innerText=String(o/100)),Jo=n,rn()):(t=$o())&&(t.innerHTML='<span class="PlayerToolbar-dataLoadding"></span>'),1<=e&&an()}}let sn='<svg t="1587640254282" class="icon" viewBox="0 0 1055 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5670" width="26" height="26"><path d="M388.06497 594.013091c-96.566303-167.253333-39.067152-381.889939 128.217212-478.487273a348.656485 348.656485 0 0 1 256.248242-36.864C623.491879-5.306182 435.417212-11.170909 276.542061 80.616727 37.236364 218.763636-44.776727 524.815515 93.401212 764.152242c138.146909 239.305697 444.198788 321.318788 683.535515 183.140849 158.875152-91.725576 247.870061-257.520485 249.669818-428.559515a348.656485 348.656485 0 0 1-160.085333 203.496727c-167.253333 96.566303-381.889939 39.036121-478.487273-128.217212" p-id="5671" fill="#8a8a8a"></path></svg>',dn='<svg t="1587640423416" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2270" width="26" height="26"><path d="M270.016 197.248l-83.84-84.544-69.76 70.464 83.776 84.544 69.76-70.4zM139.648 465.024H0v93.888h139.648V465.024zM558.528 0H465.472v136.192h93.056V0z m349.056 183.168l-69.76-70.464-83.84 84.544L819.2 263.04l88.384-79.872z m-153.6 643.584l83.84 84.48 65.28-65.728L819.2 760.96l-65.216 65.792z m130.368-267.84H1024V465.024h-139.648v93.888zM512.064 230.08C358.4 230.08 232.768 356.992 232.768 512c0 155.008 125.632 281.856 279.296 281.856 153.6 0 279.232-126.848 279.232-281.856 0-154.944-125.632-281.856-279.232-281.856zM465.472 1024h93.056v-136.256H465.472V1024z m-349.056-183.232l69.76 70.4 83.84-84.48L204.8 760.96 116.48 840.768z" p-id="2271" fill="#8a8a8a"></path></svg>',cn=0;function pn(){var e={mode:cn};localStorage.setItem("ExSave_Mode",JSON.stringify(e))}function mn(){!document.getElementsByClassName("live-next-body")[0]&&_l("Ex_Style_NightMode",`
    .layout-Player-barrage,.Barrage--paddedBarrage,.Barrage-firstCharge,.Barrage-notice--replyBarrage{background-color:rgba(37,38,42,1) !important;}
    .Barrage-userEnter{background-color:rgba(37,38,42,1) !important;color:rgba(187,187,187,1) !important;}
    /*.Barrage-content,.Barrage-text{color:rgba(187,187,187,1) !important;}*/
    .Barrage-content,.Barrage-text{color:rgba(187,187,187,1);}
    .Barrage-notice--noble{background-color:rgba(37,38,42,1) !important;border:rgba(37,38,42,1) solid 1px !important;}
    .layout-Player-title{background-color:rgba(35,36,39,1) !important;border:rgba(35,36,39,1) solid 1px !important;}
    .Title-header{color:rgba(191,191,191,1) !important;}
    .Title-anchorText{color:rgba(107,176,125,1) !important;}
    .Title-row-text,.Title-anchorName{color:rgba(153,153,153,1) !important;}
    #js-player-toolbar{background:rgb(37,38,42) !important;border:1px solid rgb(37,38,42) !important;}
    .PlayerToolbar-wealthNum,.Header-wrap .Header-menu-link>a,.public-DropMenu-link,.Header-icon{color:rgb(191,191,191) !important;--mantine-color-dark-5:rgb(191,191,191) !important;--mantine-color-dark-3:rgb(191,191,191) !important;}
    .layout-Main{background:rgba(35,36,39,1) !important;}
    .ChatRank-rankWraper{background:rgba(47,48,53,1) !important;border:rgba(47,48,53,1) solid 1px !important;}
    .bg-icon{display:none;}
    .ChatRankWeek-headerContent,.NobleRank,.NobleRankTips{background-color:rgba(47,48,53,1) !important;}
    #js-player-asideMain{border:1px solid rgba(37,38,42,1) !important;background-color:rgb(47,48,53) !important;}
    .Chat,.ChatSend-txt{background:rgba(47,48,53,1) !important;color:rgb(187,187,187) !important;border-radius:0px !important;}
    .ChatTabContainer-titleWraper--tabLi{background:rgb(29,32,35) !important;border:1px solid rgb(47,48,53) !important;}
    .ChatTabContainer-titleWraper--tabLi.is-active,.FansRankInfo{background:rgb(47,48,53) !important;}
    .FansRankInfo-txt{color:rgb(121,127,137) !important;}
    .Barrage{border:1px solid rgba(35,36,39,1) !important;}
    .layout-Player-chat{border-top:1px solid rgba(47,48,53,1) !important;}
    .layout-Player-announce{background-color:rgb(29,32,35) !important;border:1px solid rgb(29,32,35) !important;}
    .FansRankBottom,.AnchorFriend-footer{border-top:1px solid rgb(47,48,53) !important;}
    .Title-official{background:rgb(35,36,39) !important;}
    .Header-wrap{background:rgb(45,46,54) !important;border-bottom:1px solid rgb(45,46,54) !important;}
    [data-mantine-color-scheme=light] .Header-wrap:not(.is-darkMode):not(.NewActNavIng){background:rgb(45,46,54) !important;border-bottom:1px solid rgb(45,46,54) !important;}
    .Header-follow{--mantine-color-gray-2: rgba(47,48,53,1) !important;--mantine-color-dark-5:rgb(191,191,191) !important;--mantine-color-dark-3:rgb(191,191,191) !important;}
    .Header-follow-listBoxLine{display: none !important;}
    .DropPaneList>a:hover{background: rgb(47,48,53) !important;}
    .DropPaneList>a:hover, .DropPaneList>a:hover .DropPaneList-title, .DropPaneList>a:hover h4{color: var(--Header-hover-color) !important;}
    .layout-Menu{background:rgb(47,48,53) !important;border-color:rgb(35,36,39) !important;}
    .GuessMainPanel{background:rgba(47,48,53,0.9) !important;border:1px solid rgb(47,48,53) !important;}
    .danmuAuthor-3d7b4a{color:rgb(234,234,234) !important;}
    .danmudiv-32f498{background:rgba(47,49,53,0.9) !important;}
    .danmuContent-25f266{background:rgba(35,36,39,0.9) !important;}
    .word-89c053{background:rgba(35,36,39,0.9) !important;color:rgb(187,187,187) !important;}
    .FansMedalPanel-Panel{color:black !important;}
    .AnchorLike-ItemBox,.AnchorFriendPane-content,.SociatyLabelPop-content{border:1px solid rgb(35,36,39) !important;}
    .AnchorFriendCard-info>h3,.GiftExpandPanel-descName,.GiftInfoPanel-name,.FansMedalInfo-titleL,.SociatyAnchorCard-info>h3{color:rgb(204,204,204) !important;}
    .GuessReturnYwFdSlider{background:rgba(47,48,53,0.7); !important;border-left:1px solid rgb(35,36,39) !important;}
    .GuessGuideList-itemBox,.GuessGuideList-moreGuess{background-color:rgba(47,48,53) !important;color:rgb(204,204,204) !important;}
    .AnchorFriend-footer a{background-color:rgb(47,48,53) !important;color:rgb(204,204,204) !important;}
    .AnchorFriendPane-title{border-bottom:1px solid rgb(47,48,53) !important;background-color:rgb(35,36,39) !important;}
    .AnchorLike-friendList .AnchorFriendPane-title h3,.Title svg{color:rgb(153,153,153) !important;}
    .GiftExpandPanel{background:rgb(35,36,39) !important;border:1px solid rgb(35,36,39) !important;}
    .GiftInfoPanel-cont{background-color:rgb(35,36,39) !important;border:1px solid rgb(35,36,39) !important;}
    .BatchGiveForm-num{background-color:rgb(35,36,39) !important;}
    .BatchGiveForm-input{background-color:rgb(35,36,39) !important;color:rgb(149,149,149) !important;}
    .BatchGiveForm-btn,.Backpack-prop.is-blank,.GuessMainPanel-sliderItem{background-color:rgb(47,48,53) !important;}
    .Backpack{background-color:rgb(35,36,39) !important;border:1px solid rgb(35,36,39) !important;}
    .Backpack-name,.NormalCard-btn,.NormalCard-close,.NobleCard-close,.ReportButton-41fa9e,.HideButton-d22988,.txtHidden-486e56,.BackpackInfoPanel-name,.NormalCard-name{color:rgb(187,187,187) !important;}
    .Backpack-propPage,.BatchProp-content{background-color:rgb(35,36,39) !important;color:rgb(149,149,149)!important;}
    .BackpackInfoPanel-content{background-color:rgb(35,36,39) !important;border:1px solid rgb(35,36,39) !important;}
    .BatchProp-customIpt,.BatchGiveForm-num,.GiftInfoPanel-intro{color:rgb(149,149,149) !important;}
    .GuessReturnYwFdSlider-numIptWrap,.GuessReturnYwFdSlider-numIpt{background-color:rgb(47,48,53) !important;color:rgb(149,149,149) !important;}
    .GuessReturnYwFdSlider-giftName{color:rgb(160,160,160) !important;}
    .NormalCard-common,.GuessRankPanel{background-color:rgb(47,48,53) !important;border:1px solid rgb(47,48,53) !important;}
    .FansMedalPanel-OwnerInfo,.FansMedalPanel-list{background-color:rgb(47,48,53) !important;color:rgb(187,187,187) !important;}
    .FansMedalList-item:hover{background-color:rgb(37,38,42) !important;}
    .AnchorFriend-content,.SociatyAnchor-content{background-color:rgb(35,36,39) !important;border-top:1px solid rgb(47,48,53) !important;}
    .SociatyLabelPop-title{border-bottom:1px solid rgb(121,127,137) !important;background-color:rgb(35,36,39) !important;color:rgb(153,153,153) !important;}
    .Barrage-nickName{color:rgb(255,119,0) !important;}
    .wm-general-wrapper{background:rgb(35,36,39) !important;}
    .ChatRank-rankWraper .ChatRankTab-title.is-active{color:rgb(255,119,0)!important;}
    .ChatRank-rankWraper .ChatRankTab-title{color:rgb(131,140,154)!important;background:rgb(29,32,35)!important;border:1px solid rgb(47,48,53)!important;}
    .MatchTeamRankList-topAvatar{background:rgb(47,48,53)!important;}
    .MatchTeamRankList-topName{color:rgb(131,140,154)!important;background-color:rgb(47,48,53)!important;}
    .MatchTeamRankTitle-content{background:rgb(47,48,53)!important;color:rgb(131,140,154)!important;}
    .MatchTeamRankBottom{background:rgb(47,48,53) !important;}
    .MatchTeamRankBottom-lable{color:rgb(131,140,154);}
    .MatchTeamRankBottom-desc{color:rgb(121,127,137);}
    .Barrage-text>a,.Barrage-firstCharge{color:rgb(187,187,187)!important;}
    .GuessMainPanelHeader-slogon{color:rgb(204,204,204)!important;}
    .Barrage-hitYwGame--text{color:rgb(187,187,187)!important;}
    .AnchorFriendPane-title h3{color:rgb(153,153,153)!important;}
    .Barrage-nickName.is-self{color:rgb(255,0,51)!important;}
    .barragePanel__funcPanel{background:rgba(47,49,53,0.9) !important;}
    .layui-text{color:rgb(187,187,187) !important;}
    .GuessReturnYwFdSlider-ywNum{color:rgb(237,90,101) !important;}
    .VideoBottomTabs span{color:rgb(204,204,204)}
    .BackpackHeader-info--title,#point__value{color:rgb(191,191,191) !important;}
    #red_envelope_text,#red_envelope_query{color:rgb(191,191,191) !important;}
    .layout-Container{background-color:rgb(35,36,39) !important;}
    .FansRankBottom-invisible,.ChatRankWeek-invisibleContent{background:rgb(47,48,53) !important;}
    .Barrage-roomVip--super{border-top: 1px solid rgb(37,38,42)!important;border-bottom: 1px solid rgb(37,38,42)!important;background: rgb(37,38,42)!important;}
    .Barrage-userEnter--vip{background: rgb(37,38,42)!important;}
    .ChatRankWeek-nobleInvisible{border-top:1px solid rgb(121,127,137) !important;}
    #refresh-video2-svg{fill:#ffffff !important}
    .VideoRecommendItem a{border-bottom: 3px solid rgb(35,36,39) !important;}
    .AnchorFriendPane-title a:after{display:none !important;}

    .MedalOwnerInfo-box{border-bottom: 1px solid rgb(79,81,88)!important;}
    .FansMedalList-item.is-NoWear{border-top: 1px solid rgb(79,81,88)!important;}

    .layout-Player-announce,#js-player-title,.DiamondsFansRankList-anniversary{background: none !important;}
    .DiamondsFansRankContainer-skinbg,.shark-webp .DiamondsFansRankList-anniversary{background: none !important;background-color: rgba(35, 36, 39, 1) !important;}
    .DiamondsFansRankList-anntitle,.DiamondsFansRankList-anntitle{color: #cfcfcf;}

    /*弹幕时速*/
    .barrageSpeed{color: rgba(255,255,255,0.5) !important;}

    /*用户等级*/
    ${(()=>{let t="";for(let e=1;e<70;e++)t+=".UserLevel--"+String(e)+",";return t=t.substring(0,t.length-1),t+="{background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAADACAMAAAAN8R4NAAAC+lBMVEUlJioDvrdnxgPfkxaJb0lrsSIhrKYDvLVif0ftnhtnxQQKnZlZpAwnKCy+iDDYmzlFfHwrLC/ckhc5OTq1exuIbkg6PjyAa0qehVxzX0JpwA5CQT84PkEpKi5geEksLjE3lZNHamsqpKAfQEIxQiM9QT5Gd3c8RUguoJ1HbG0tLzIRt7FCUlVquxZabUpplD1TYUnOmkRBRkAzNTcVs64/REBSTUZnjEJDPDNGYWMwNDdHOyZGdHVqvRJpxAkKu7RAPz2zhDcwMTMcrqlCgYE6QUQ2ODjekxc/iIdqnjVrpDA0mZY6kY+tjFdliERqmjg9SEvGjCpHZmhEfX1VT0czOTxYaUqPc0avgzjonyZ4ZktVZElhV0k7REfZkRtLVEZ4ZkpFQkBrojJrpi5ccUmRdEY2NjdrtxsasKtGb3BPTElSTkrLmUVkhUVMSEOCc1xEWFo/S05hekinfz2oilpLSUZCSEIHvLVBT1HElktqXkprqSw8j42McUhjgkaaeUO0hDbenTNJUEVOSkThnS5qtB1u1QIkqKRBhYSGdlxpXUpnkECfe0DWkB131BIAy8NfWVFvYUprrSa4klNIRkTpnSA9jIuih1s8OzvMjSYwnZtEe3t8aUnOjiTUkCD+phRmX1NdVUcym5jkniuifT8rop5Ef393bFlQWkiWdkSrgTxqmDvBii3akhkPzMVESUNrqCqXgFyEbUg+PTx0almpfzwTtK9EW12wjVaCbEhOV0fOmUFYUki6hzLRjyLImEtXZ0m4hjPfmihsX0rUmzy4hjTlmRxBhINGTUScekGB0yj/rCXAlU5FTEPRky1tZFa8iDG0klyQfWCKeVy9lFFsX0tNRToZp6KbflA2TE65jkeddDCvfSvYlyrwoyQgzcYZycIVwbubgluFcVAyQkVESkLDkT75rjNqVTNxxBkhnJghi4h5aE5tWz67gydfoRpVjI1yjlZeTDJeqxBs0QGm1HSohUxVRzPJhhhyzBF0z82Tu2mHqmJThCGbY0TbAAAbfUlEQVR42uybe1BUVRzHv7uLyVIrXTZFXTeI8gWC4ZpYKcKaoKTp5pquEYnBWoFUQCkVIUkPSwoCAgwRg0oJKuylSVhE9iILtZe9c9KaXtP0rmmme3b3cL3uuZwzjTNZ2++Pc9z1O2fOxzlz93783YszTgrRcyvkpDOmjhgaxK2hI6aK5s49JczArbBTzhXd3+knDtZxa/CJp+OkUyFQp540YopIbsoI0dwpS0Vyy04R3d+J00RyY05ECIQqZKhYbqhoLkwsFya6v8FiucHQg9SZk4BJcQAdI7Ky7MDLcXI9ClL6INB64krgyqsAOkrr1rlBKyioP5YD5CixnDe8A80ZQGqzBbDcAdDRvOx6kzIBMOihbPAigI7yNy8DuG4LvKXXeeezxwJjLwTk8TQyrr7vaTItICMpnQ94UDBwqf4sAGlzIJOGLF+ufxQTYx977LGso4FDhwMVxmsB5BYBqKjZtcuYowCrY9XemDS8Jt47qIGHhANrDY8DWFIAYG3GmtaMOjpRYGWDo+kGgYv1CYgODrnsKOATTgYm6GYBGHc+gCtiZt92AqIXDn6AAYzYm4AI/ZkAll8AzJmINA8sCxhl8iAZHwKw8xBQVKUAM2PDi3bFk4EFjPodcig1HcCL64EnF/smP2DEBtMNYvT0VxMQPGc5CxiTF8o53dmAacbVMEXOOvn8DUzglSuArEQAkOTsoJuwIis/OIUNXFgKrHMBgFXOhtYqwBqxefFkYAIHOYAXygGgOA94dj2d/IBX3gLEjfR+PnN+AoAEJvB5M4HxM8gBv3vWmGnRAGYzgc+Sz3TaRHjqTn0akBh705yQS5nA18pnOrcKntpuzAUTmMY4wEmGJCwpgbcqU/PoRIFVG7zMs8H5F2AA4Et0l2DcXHKiH7n83suf0gAm403RI718iNiyYiW22MnJZgCTsTbC2ARPSU2lhUxgMh6Qapo4wGjbEZ3q+zXb2uikEwVWb1BPNph1A7SByfhgtG4CgGl3LwBmPK0JnH9X1g8gNfFRIHgFtpiAm1awgTua324GqaocYHipFvBw19fd4AE3fLBtI0hJQz6wkcnxwVSwgPO/u3g6mS8bGRubmHiZJvCYdybEkPlpnQmYeR4LOGGYXCm33nWBFzgt5axBczB9YsTLsQl+wNstctVteq3QC5xrvjK0lwE8j8Qe39RdOBBwtlkut3HPVpB6Zfe3vySZ5embty1mBVjZ4I+/eTaYMnr06LSHh7GAZ4+Sa9Hdj9wOUjEPWi/UTWAB60lJN+gfhWfBOYnT77Tj0TR97AXwAzaSMsX7foseL6pp3h7tB0xjO0lMG9hAyrSmPROkMsin5+lEgZUNWm/QXwdPaR5pHSlrlG4BSF0zWbdqGvyAtcsEKMAiFSSaM3AjFJhXFJhd0VCVLvBuLQNOHgJOD0U3+J8BPtZHdYRTJOf854606EXmP3PRCgJbdFX2CgRp+zBwLZlpTnutzo6HJDEflirfstOfJQ0dPus5AMPyL7LSnyWmDtumjbcBGDXmNF9OR4CZBgupltorBWHFSNmbXaqcfyiarFVcs6sn1Cniw3ntra1hmRSYqcP26SPlbxJvWJ44jAIzdHhUTGSk/GnCqqgNq0YpwGzRpfZKQTRixIgPs4FRViuz0rVsu2th3f2ZiA+3FstTCQVm6TAee1UGvmc+sDyBAvvrMCJvBBaOR1QkcP9sBVjDYDHPD5gZK9z/kBqYvZb53Slw7y4U8WGi2G3bKDBLhy94+OKR8ngzgabA/joM3YXj77sGuH01cFskE5gaLBdYiT0UCgYwe63W0nQxH94atgQUmKHDZw4CASaiqL+ZAvvr8Dm6meeP83girtCt9gemohttbOIBk9Hrw5ZmCxOYSvNuZS3zoZ4Ktg9vO9qHJacjyA8Yg86UPDo8bPowH/CdI7dAAVbrMAE+D4iMBHBvzNXQAu748O094AN3uDZ7fHjfprIyl7EsiQnc8do6Za0pG4uTwPbhPV9QH37fRiwxEwh3+APnf/mHR4ezbo2NHamPHSYNuicFDOAxMe/FgNSqC4GTL4d021eLwACmovvRgYGB5x3pw9bq6uoOV7WSo6EkuTwhutaHH4zIvNLM9OGatsVeHy5PtljMKFliswxpocD+vi7JOnzqyNGYeNfnkybRq7RKhz/16vCNUYvGXn4v5j6yeuxY1lVaMVg2MDsGvyPNXMu5m3zTJzF92KDy4ZSCjK7saArM1mFypBP1P4To76HADB22btDpzjdhBvkyigIL+uu/1IdNJqhKF3i3lgEnDwGnhwEHfIyP6vH/XzwBd9EKgkZDt2KdXDkCPpyyd12KkA9LV+17XMyHgaQ7RHw4Ii7uHBEfjhg/3pfTQdNzq8ri4+P38X3Y0ry/l3yiOU23zqvJLTI+IeLDgH1jI/g+fHMiaWPzfXj1qg0bdAsosJbn5lJYjg/vrwI+W6fkNN36gBw8sEvAh8kfdjeC58O0jc334Q23A/fPpcBanlu6r+Nrm4APG9PtU00CPuyx3J4+ER9G8fr0RvB82NfGDub7MMmdsJACa3muq6ywyNjE9WG3sbQ3l+Y4PvyuMT5CxIfT20CAOT5M29giPnyvbhwosFbft8kG9FYN4MN2Ty7FWAvs388CJqN0pFtLFaF9TB9eJh3pw+aNZgYwGfMjjvLhiGduWSniwxFXzzxPA7jjsK/v+4YJqC3V9uFurw+j5ipWf5g2kV9oBgXe/gZwsMzG8mFHrdeHIxzP2oDKTfX1jan1Zn8fHvT9kT482tvGZvjwx7+rfHjuAmDh5QqwSofNVGGbq6SKsnksYJrz/mXVTvOVpdvVORpS+fDP8dWWnl1MH970UTFItQypk1e21tXVLW2sE/DhtJRJg+azfPgRtQ+PWzT2hEgKrNX3zck1lhUK+LBpl9FYJODDSOmtcVVZMLAP/+ptDJMjzfdhs9zGTrDzfXjR+atiZtv/9+EAubUMOHkIOD0MOGDRI/ifeeQh4C5abM8lOkwKtIL8vZmO1qv2uYV8GEi6SsiH866XK5Prw3Ti+zBwyYU8Hx7e09NTagTfhytcRX2ug2wfvlbda7Z3u8wiPvxK/Zo1ayp5Pkwnrg+TXEwMG1hp6ZLaXiTgw32HgL3dGv1hda/50OHDZhEfXkJguT5MJ74PA1Efx4Dnw4DJ1STgw7Wh0ejbI+DDeHdXusss4sOOymXhNq4P04nvw7g98uwY8HwY6CgT6Q9be4w1NUkCPpweaqbAHB8urw8qCJvC82E68X347BNAgVk+bKc6X/oZE5jmrOWeXF/pGxW9Hyo5rV6zubsJbGC0LXar+sNOO9DyCsOHT1X5sG/i+vComFEDAHd8NNWnsE1G+wDAn+2p9Zxje+lBoNO4lu3D3c5+H66UG8nNxrIKZn94qK8/3EZ8GJ0mYCirP3yLyoeDfW1ihg+/947iwzMX3T15coxu8ig/4Hm+9rBPCouKwAKmqmv0qW78Tre10Oj28+FMucybXPMoMGkkH3RVsH14j68/7PgmyWLGxhIpr34x14ft3onlwzNeUnz4duusWbPGzJgFCqzhuXX0ZHN8OGe/qya3ScCHAXKk2T7c6PPhsF/DZB/OXBJWX8z1YTrxfRggR/oY+rDpfx8+jm8tA04eAk4P/ymQ49+HRR9lWCZ2VP8zPix6MToefFjdH0bF8H2SkOcmdew1H/1zk05E93qAjpmdkIjlptOfmwH7w7ZllTZuf5i+38z34WtOk2sBrz/cYeztKbMJeG5eTdHO0moFuP+eMc9AnCK5QM5tC0tGZ0ZycnKLAqztw+au9S2pj3N92Pt+cxzfh+dOjoqKGs/rDxv3Aj2FAp57aD+ws48BjI3b5JwhHQgvaE3GC8lQyjCQD7eUADsq+T58WRYAAR8edwUAjg/LQBVAVY+A59bsBd4NtTKAi4noZoBUdjLCW9KL8/yAWT4cdsdb4dUCPnxLXH6wTcCHZ44fc5+N68O5vVJOczPfc1PIYwxfH3YzgInoJpdQ4OywkuzGbAVY04ftBkfBklQBH06MXUneb+b68IzJ590/eAIbWFHYTtnl9odq9X0j+j3XTvqlB0ttfsBk3CoZplBgSybpkTGA0fbNuUf6sM0wFFi/ngL7vz5MRXjLOcD8iQwfXqjuD18t5yLnavlw6RfNIOWGpGqIsx6WJsDYPRxyKxQs4GV7ptaDAueZAYuBBdzw7fv0eWmPD7ffofG89J/5R/rwWVusnnPu78NfTVP1h6+2knOu1R/+yFXo1eFedLo6FWC/JjIFfjf02ryavSpgKrq2TY5i9B9ph9nWspECq98f7vLG2gzv15HnpdfYLI6t/P7w9InSzbEJ/P5wzI3S6qdm8/rD1fFG1z6IeO4BY00f1MBUdJMNmf3AKGnMaEmiwMz+cLshg/iwqdVgKOD7MH2/mevDC8bpJr8k4MMmYR/+G557bHzYxPdhdU4XeLeWAScPAaeHx3qDxz3wsT2CS0Vz/9yRPtYXmeP+omWAV0wzgUyPuSZRfwXSGzKP/hlJpwJLRyfWvkXq6BxZjyTo6CRfLnVjYB/uDJ8CrL2elIAPw5YVZ+P3h+lESkeAFTFN8omptKM9GVgyZGtXA90gMxdNPDf8zTffdBg0c8menLyeu7w1m66n4cPF7evb3vQumAq+Dw+bPn8++ZLjw3RSgFViatjs89fNXYCzxA/E57nRXs8t8EpudgErV09znvW2ydH0roF82GbYDGvYWo9EFIDvw0QcguO4PkwnCqz21+vLQWpxsuwrzvB0sEBI7i1vLtsDbCp3auVe6F+v0hGNbY6BfNi8GHCnbiYLZnQK+LD+ubjg17k+TCcK7OevdIMvOoaUlLOONBVYBXjpRtCc9npINrS3J/F8+EkHGZfVA1wftulvmZ+m5/uwb/IDJuMOyeBUgIHN5f4gZCyeKucUYEcDmLm2rW5lvfD69MySfhD2+8PmIWvsdEGuD9tuXQk8/DC3P+ybWMANjju60H+kWz3/+CyQhrLs96EAOw3RADPX/YWyniMciDasZQDv+PCLb0FqSlc2SDnD7Czg/Lt+Uj0vHfKcxvPSn6jeH6aTGnixt1H7WnH/Bp3ta6US9UVGaei6tkEBLigAtHLKeq0vutFgcLN8uNtnv12Oty0WCXiyBYDA89KPpUxacSfLh99R+bB3osB+/ko3iIZ2gyNTAVELrEUBpseW5jTWc5d0tSenM334RW/MaSC3m0vhTnUCAj5sXa7XzzFxfZhOCrBmSaL+KpgzHXMfNgn6MM3pAu/WMuDkIeD08K/2zjNWhiiK42dGlyzGKgnWItFWjW6xeu+9r15WogtC9LASfYPoEi1EjU4QRHQiPuglhEQLgsQXH9xr7zV7uHPPZBBlzYd3n+efO/55a9/83jn3f2rlaUrfuGmeWu50f4Hhn/9S/cN/xdMUXF1N3er++Dctm4cFudb7yq8NemAe5jJc9gX/mi/13Hprlli2zgl0JWbT9eEGS3pJnekcLz2zPL80PCzipScW5ZcCHkbYPLx3ZzeotyDHpp3oQQHJDgD7NDr9QNTPlk2n2ltS5wy6HJ/d1IeXrNs2NqqpD4t46ayJRGKIKQ07x0t3jMfjQw1p+Lt6btMk53aDTdNtDELPvmvzCxmc2gRwYBBMH8T/RuqcQZdjsZv6cPslAPNlqcU5Xppf85pLw87x0sCu5RtswxhMl3A+8kHXbtCtK3/Ya/L9PzAvx+aoqOdy08wOdD0ldTrQ7VrfTX24/jawjucXhnXx0uCL2GlLmnhpbl0aVnMuN7xkbT9r7PoRdD23SYaC/LUgdRrQ5Ybp/WDwgmjTHDoelvHSMLAcSMO6eGmIVQGVYWi/N7CzkzTsW5dhZ9cMfgXO5chrycf7aWs7QYMMI+zyJubh/EEMurZhXB9uIGRwgfdL5xi79NgO2U2ri5eGIWNA1S9dO4jjpWHoatsw5tcL7eGr4X0+6LVAWc+9/07Uc+/dDbIlOok5PyB1SNg3Kay24AiAo+E1d3uI/Y7nece/4yuAvXEpeRjHSx81GyjztF68xfHSo4wwgIqHm5yNDpKG2cH0JoHpU1T13CYPNia/3u31R99gPwzK0WBEtJeSh08L0M3xbjADXWzYlq1sn7zthR3PrH1+a2dGaNDtmpKHcbx087ZgG9bES2/gb9kqHg7wQq00DJsWNLVBPIMKh6MZojv5ed8DGaJ51dwsQZdfPZBhJIuKfummX/K0jnWLrpsvfyxp4qWbmEdtw5p46c7GKGz4x/nV542bf32/dAjwZaTfo2XawUPa4eHPvvFv0rk3/LNfWr9F570+/ONvHr9L556HdVw6K/8SC3PpeIDxjEjlx2D5LwXaqmMGipAdUzkfiSu2fvnDVrB1aL9Kcr8GydxoS+iI+nBPn5v6cDhWU+gM0HHpmtybjq9s8O0j3kw5l4l/ygKtxsPMSNvEkCAyjIXQpkCF2UMglNUcYBu2ZZJz2UZiPzs3WlMfZug0r3mErA8XYui0vOUEWR/WcWnuvozWpmi4VARaTa4u/gYbhjrsQ4gLQ5ErEDC3Zm3ewjbsPOcJ5Ubr6sNDygO0nUfVh4vC0NLsU1lq0XCpxStf2+QzLZ7LVD4iHrB4oBX/R1RPYMNYGBDf7+rYsJRJzrW+IBHKjdbVhyfPg1DCRZ7W5uUQiucShnVc2m2T1e/EWg2XMgdmC/DzJ9zCdZDh74R1zIGADWOZPecJ50br+qWbRCJmJhfnhzvXnWDEQRjGddrggtRzvCPWZlg5P4cjlyYDrYYMr2zOlGVLbBhmTw1mF0J/efMKNoznPKXsx30XOKrSDcR5WpnaXtmaqTqdp5W55ehDmZspDE/b+Oqe6Fs+VZktDcBSHlweM7ti8vtZYfwXp5Eu7NP+yLAE2K1v+Hqlwhf3yDCSDXyTul8wsaeJUpdA54e3msXZ5wUUPNzwSWp9uDF/F4uVQYaTXFpjfXfBpac78b7lsZtg6YIR33Op/8NzOZfJX5UFWlXPVPl8pCIyLIQCYKHAmEBFsycyrOBcGZBVYeH44jI3WlMfrhwZ7gu3SJD90sEJjXzhVXFhWJ1rtfMLl+6bnnvBEkWd1ie51N+WBVqFAFiddqptBAFsJUj+pzMzFQZs2JZZcr8mbSMFWEBWAf5FYURXH97aIlJge3G6Pnxo1YS6RdCPJZJz3fctO+kCYqV0QOh+9Pxw+j1aph08pB0eut3wZw+i+m2Gvb20fnzUmNv9ftv84Z89TO63vWkh3kRcKheaX/kfTwI1p3jx4/0px33U97XKlx/MlsGF+ULzcJ+sA0NueLhsx1hIM39YBjeLheLX3SjXyvE88q1ll3PmDCLD8r6Yr5+KPmiah8dkb5soF6b7pUtkKRKvEqbnD4uF5lcGahcLEHOKK7PzyIFlI23DmHOtlP1EHzTNw9kZgCXa0P3SWWIA8bnCMOZNG18DjEvFouZXW8fxtGIBYk6xv7UfBi+7jgxjbLbnHptdymd9CiQPhzilzctE8zAfPbQ8Ts8fthd840pmJcSvHE+ZYXJOMdyZYWcFaHh4sDmE90HTPDygbWh8nTo0D5cqEmpXpoxy/nDgPeNQGdwsFiW/mkdtfmV4yg1Tc4r9Z84sBYVh/vErX1tsv8FmSh+07vzw+XJmue2ZFDy8Ooh4ePRBo0qRzArDhRd+Kpcyf1gsKn7NV8fWvSkscq3Uc4ov3UgG5lU7e9gCteHCz0+K/Z5+uaHZxeG+s/ugeUuVIaQ8MF3iZgz1S4eZrkgrbHje9/OH24qF5NdAEk+JOcWnr95oMsxOjXDYb/CX+05uUlX2QZt4/DDql27e1nclcp7kYWhZxDe67mjbMOZNe/6wWDRcagsqFiDmFHfKlu3s2WzjbMOYh5/K/XhgtCX6oCkeLr7HjAwEmocbFzPqxkAY/tlc6jZPy20ftF4XoHkY64z0e7RMO3hIOzz8Z8De7fXP/OrG7fXP/HLO7WU6lnNxP7IjN4dFnZbWSX6lObc4qzfrOFcGZDUuERM6w7VhJW+2qVMh0xDcj4x0mIdFnZbUIX7Vz1FqO3lISMO5IiBrYt0ixYaGPBm2eVOWc33Zt6J+ZE19WNRpSZ3gV5JzRb1Zw7kiIOtFMx405M0w5k1Llu/tfmQHHa8PizotqRP8SnKuqDdrOFcEZHHzzeIeDKvLubgfWcOvok5L6SS/kpybjxekCpdz5txkQNbEkFESoPZBz4b5x6Dk0nwDs19B/cjfcDPXSW5GdVqss5BO8CvFueE5dr0Zc26JJOeKgKywMRFg9dAfMDyGc6ldzkX9yJiHs9ZJ4ebiok6r0FmpOkjlV3zfyuhcsKg3Kzg32QedDMh6AXWLArTa4M0w5tICYyxWzhX9yCQPB0WdltIJfiXrvqzeHGb1ZmfOTQZknYNmmcOj69b0ZhjzZsUEK+fifmSFTg48EnVaUif4leZc6G9Gpuo4VwZkbTAmbAEPhjWg6bGeS/Prj+ZkAdYZ/x8t/8ND8ko/PHS74Z+uc23Y7UvmT9e5Nuz2TeFP17k2bIAKODtw4LQA2h2SMi2XFipRNEDr5BxgWsfnI5G6xjg32r1hFXAacQachUIds2yWMh2Xlp1QbNWEQqROzAEmdWI+EqUrKuTeDGPgDCbP6uVquco2rOHSYkUANjQjdWIOMKkT85EonVy8GcbA2XjR6KJPgF3NbMNqLg2HGZfOZdQSL6LTcX6Vc4ApnZyPROnE4tEwBs6yxuYtmctgwwpZSnBzzJhI6eQcYEon5iPROrF4MWw3GieBs8EoXms8hAwjGeJSbqTMKFqH5gBjXShVJ+YjkTqxeDFsB1ElG407822HdkSGFTIZ3GzFX3ZW6qrcRjoxB5jQ3QynzkfCudFv0X5i8WQYA+dEo2aAvUiRYUcubQatdpXtXbIQqUNzgLHuUYquI5qPhHRZUnXNxOLRMAbOWEOjWAdAhjVcWpd/sRipE3OASZ2Yj0Tp5OLFMA3EhoZLf5MO8/D/R8v/8JCuePinG/nPw/952AMPO3ApymU2nLEZ5VVp9+PneGkd6m/W9EF7qw9ruBTlMhvO2IzyqjT7iXO8pA71N2v6oL3VhzW8iXKZDWdsRnlVmv3EOV5Sh/qbdX3QxbzUhx1480nnyjiX2VBj8+3OgPOqHPYre6iyPMdLcm4otb9Z0wftrT6s4U2Uy2zosBliVWhuFud4SR3ub9b0QRfyVB9GvBmDVN5EucyGDpvtvCqs64h4GJ3jxftZSCf6m1X3zYJyo73UhxFvPiqKeFO0Gyt4uHMqNqO8KrxfzdT90DlevF8sVYf6m5Hu4aEXKX3Q3urDGn5FucyGDpt5XhXNzeIcL6lD/c2aPmhv9WENb6JcZkODzSKviuJXcY6X1KH+Zk0ftLf6MMGbPoJLA7+GcwOkzvefh//Dw3885NdnBn9Rvur73V4AAAAASUVORK5CYII=) !important; !important}"})()}

    /*新背包*/
    .BackpackHeader{border-bottom: 1px solid rgb(37,38,42) !important;}
    .BackpackHeader-tabItem{color:rgb(121,127,137)!important;}
    .RightsPropsList{background-color: rgb(35,36,39) !important;color: rgb(149,149,149)!important;}
    .RightsPropsList-item{background: rgb(47,48,53) !important;}

    /*加入公会*/
    .SociatyLabelPop-content{background:rgb(35,36,39) !important;}

    /*任务文字*/
    .taskScoreEntryTxt{color:#BFBFBF !important;}

    .GiftExpandPanel-giftTabsWrap:after{display: none !important;}
    .PostCard-module__feedInfoWrapper-be1-y{background:#fff;}
    .PostCard-module__feedInfoWrapper-be1-y:hover{background:rgb(239,239,239) !important;}

    /* 新版斗鱼 */
    #root{background-color:rgb(35,36,39) !important;}
    #bc3, #bc3-bgblur{background-image: none !important;}
    .Barrage-label>span{color:rgb(187,187,187) !important;}
    .ToolbarRechargeModule-icon,.ToolbarGiftArea-backpack--content>i{background-color:rgb(35,36,39) !important;}
    .PlayerToolbar div:before{background-image:linear-gradient(0deg,rgba(255, 255, 255, 0),rgba(0, 0, 0, 0.55) ) !important;}
    .GiftExpandPanel-giftListWrap.is-mask:after{opacity: 0 !important;}
    .ToolbarGiftArea-backpack p, .ToolbarGiftArea-backpack span{color:rgb(187,187,187) !important;}
    .ToolbarCardModule p, .ToolbarCardModule span{color:rgb(187,187,187) !important;background:rgb(35,36,39) !important;}
    .GiftExpandPanel-giftValueWrap{border-top: 1px solid rgb(47,48,53) !important;}
    .GiftInfoPanel-brief, .GiftInfoPanel-footer, .AudioGiftEdit{background:rgb(47,48,53) !important;}
    .InteractEntryPanel{background:rgb(35,36,39) !important;border:2px solid rgb(35,36,39) !important;}
    .GiftSkinPanel{background:rgb(35,36,39) !important;}
    .BatchGiveForm-btn{background-color:rgb(35,36,39) !important;}
    .InteractEntryPanel:after{opacity: 0 !important;}
    .InteractEntryPanel p, .InteractEntryPanel span, .InteractEntryPanelTitle{color:rgb(187,187,187) !important;}
    .BackpackExpandPanel{background:rgb(35,36,39) !important;border:2px solid rgb(35,36,39) !important;}
    .BackpackExpandPanel-giftListWrap:after{opacity: 0 !important;}
    .BackpackExpandPanel-giftValueWrap{border-top: 1px solid rgb(47,48,53) !important;}

    * {
        --page-background-color: rgba(37,38,42,1) !important;
        --room-title-color: rgb(187,187,187) !important;
        --front-background-color: rgba(37,38,42,1) !important;
        --bg-follow: rgba(37,38,42,1) !important;
        --room-title-light-button-broder-color: rgb(90, 90, 90) !important;
        --bg-share-hover: rgb(187,187,187) !important;
        --ex-night-third-bg: rgb(90, 90, 90) !important;
        --ex-night-scroll-bg: rgb(60, 60, 60) !important;
    }
    
    .activeItem__d6uUm{background:rgb(35,36,39) !important;color:rgb(187,187,187) !important;border:1px solid var(--room-title-light-button-broder-color) !important;}

    .DiamondsFansRankContainer{background-image: none !important;}
    .DiamondsFansRankInfo{background: rgba(37,38,42,1) !important;}
    .DiamondsFansRankContainer-content{background-image: none !important;}
    .info__J-VGf{background-image: none !important;}
    .ChatTabContainer-titleWraper--tabLi:before{background: none !important;}
    .NobleRankList-nickName, .Barrage-EntranceIntroduce{color: rgb(187,187,187) !important;}
    .Chat{border-top: 1px solid rgb(47,48,53) !important;}
    .DiamondsFansRankInfo-txt, .DiamondsFansRankList-policyText{color: #7f7f7f !important;opacity: 1 !important;}

    .snapbarMenu__szc-e{color: rgb(187,187,187) !important;}
    .snapbarMenu__szc-e div:before{background-color: var(--ex-night-third-bg) !important;}
    .FansMedalPanel-container:after{background: var(--ex-night-third-bg) !important;}
    .snapbarMenu__szc-e{border: 1px solid var(--ex-night-third-bg);}
    .snapbar-menu-item:before{background: var(--ex-night-scroll-bg) !important;}

    /* 滚动条 */
    .Barrage-scroll--bar,.GiftExpandPanelScroll-bar,.InteractEntryScrollThumb{background: var(--ex-night-scroll-bg);transition: all 0.1s;}
    .Barrage-scroll--bar:hover,.GiftExpandPanelScroll-bar:hover,.InteractEntryScrollThumb:hover{background: var(--ex-night-third-bg);}
    .Barrage-main>div>div,.GiftExpandPanel-giftTabsList>div>div,
    .GiftExpandPanel-giftListWrap>div>div,
    .InteractEntryPanel>div>div,
    .BackpackExpandPanel-giftListWrap>div>div,
    .NobleRank-scroll>div
    {margin-bottom: -16px !important;margin-right: -16px !important;}
    /* 滚动条结束 */

    .BatchGiveForm-manual{background: var(--page-background-color) !important;border: none !important;}
    .ToolbarBackpack-giftItem--count, .BatchGiveForm-num{border: 1px solid var(--ex-night-third-bg) !important;}
    .menu-da2a9e{background: #fff !important;}
    .real-audience{color: rgb(187,187,187) !important;}
    .ChatRankDayWeekList-headerContent{background: transparent !important;display: flex !important;justify-content: space-between !important;align-items: center !important;}
    
    /* 新版鱼吧 */
    .Tab-module__yubatabEntry-sTCdV,.HotTopicList-module__tab-oI09g,.styles-module__commentPublish-8ZTWy{background: #fff !important;}
    .PostCard-module__postCard-7IgN5{background: #fff !important;border-radius: 4px !important;}
    .index-module__pluginItem-PCGnX, .index-module__header-dV497,.index-module__header-UVoJc,.Editor-module__editor--2Cm2{color: rgb(187,187,187) !important;}
    .index-module__header-dV497{border-bottom: 1px solid var(--ex-night-third-bg) !important;}

    /* sc */
    .HighEnergyBarrageContainer{border-top:1px solid transparent !important;}


    .contentTitle, .DropMenuList-name, .videoTitle, .DropPaneList-title{color: rgb(187,187,187) !important;}
    .UserInfo span, .UserInfo a, .UserInfo p, .UserInfo div{color: rgb(187,187,187) !important;}
    .button-7e1395{background: rgb(239,239,239);}
    .Search-Panel-Explore-item, .Search-Panel-Popular-item>span,.Search-Panel-Popular-item>em{color: rgb(187,187,187) !important}
    .Search-Panel-Popular-item:hover{background: rgb(47,48,53) !important;}
    `)}function un(){var e,t,o,n=document.getElementsByClassName("BottomGroup")[0].getElementsByTagName("iframe")[0];null!=n&&(n=n.contentWindow.document,e="Ex_Style_NightModeIframe",t=`
    body,#groupListBox,.mainbg,.wb_card-wbCardDetail-1wzCV,.video-imgWrap-3Mf6v{background: rgb(35,36,39) !important;}
    .wb_card-wbCardWrap-22KrE,.wb_card-topListItemBox-1ui_g{border-bottom: 1px solid rgb(47,48,53) !important;}
    .wb_card-wbInfo-19JiQ a,.wb_card-wbText-2fk2Y{color: rgb(204,204,204) !important;}
    .wb_handle-wbRowLine-3OXI6 li,.wb_card-groupnameAndGrouplevel-38MGW{background: rgb(47,48,53) !important;}
    .index-dyPage-260IV a{background-color: rgb(47,48,53)!important;border: 1px solid rgb(47,48,53)!important;}
    .index-topTypeStyle-2ksW4{background-color: rgb(47,48,53)!important;color: rgb(204,204,204) !important;}
    .index-dyPage-260IV span{background-color: rgb(47,48,53)!important;}

    .index-editorArea-3XhrM input[data-input=title]{background-color: rgb(47,48,53)!important;color:rgb(204,204,204)!important;border: 1px solid rgb(47,48,53)!important;}
    .index-dyPageGoNumber-LGN4a{background-color: rgb(47,48,53)!important;color:rgb(204,204,204)!important;}
    span.index-dyPageActive-op79B{color:rgb(204,204,204)!important;}

    .editor-editorPluginsWrapper-HGPzc{background-color: rgb(47,48,53)!important;border-bottom: 1px solid rgb(47,48,53)!important;border-top: 1px solid rgb(47,48,53)!important;}
    .style-voteicon-3aTqD{color:rgb(204,204,204)!important;}
    .editor-editorWrapper-2fChb{border: 1px solid rgb(47,48,53)!important;}
    .editor-editorPluginsWrapper-HGPzc [data-role="menu"]:hover{background-color: rgb(47,48,53)!important;cursor: pointer!important;}
    .editor-editorContentRoot-3PCjH{color: rgb(204,204,204) !important;}
    .editor-editorNotLoginMask-1hCr-{background-color: rgb(47,48,53)!important;color: rgb(204,204,204) !important;}

    .style-newvoteTopwrapper-3PgJY{background: rgb(47,48,53)!important;}
    .style-newvoteHead-j0bH1{color: rgb(204,204,204) !important;}
    .style-newvoteHeadAttendView-1EgXK, .style-newvoteHeadAttendView-1EgXK:focus{background: rgb(47,48,53)!important;}
    .style-optionWrapper-2FhfD{background: rgb(35,36,39) !important;cursor: pointer!important;}
    .style-newvotestyleTitle-32flx{color: rgb(204,204,204) !important;}
    
    .editor-3MzrC{background: rgb(47,48,53)!important;border-top: 1px solid rgb(47,48,53)!important;border-bottom: 1px solid rgb(47,48,53)!important;}
    .editor-2y1wx{border: 1px solid rgb(47,48,53)!important;color:rgb(204,204,204)!important;}

    .VideoRecommendItem-liveTitle,.Bottom-tab--header{color:rgb(204,204,204)!important;}

    .wb_card-wbCardDetail-3bz_l{background-color: rgb(35,36,39)!important;}
    .wb_card-topListItemBox-7rXH3{border-bottom: 1px solid rgb(47,48,53)!important;}
    .wb_card-wbCardWrap-2iAew{border-bottom: 1px solid rgb(47,48,53)!important;}
    .wb_card-wbInfo-CLCyv a{color: rgb(204,204,204)!important;}
    .wb_card-groupnameAndGrouplevel-1KuV5{background: rgb(47,48,53)!important;}
    .wb_handle-line-FzKRd{color: rgb(125,125,125)!important;}
    .wb_handle-wbRowLine-2qn-s li{background: rgb(47,48,53)!important;}
    .wb_card-wbText-3sLfN{color: rgb(167,167,167)!important;}

    .editor-editorWrapper-2y1wx{border: 1px solid rgb(47,48,53)!important;}
    .editor-editorPluginsWrapper-3MzrC{border-top: 1px solid rgb(47,48,53)!important;border-bottom: 1px solid rgb(47,48,53)!important;background-color: rgb(47,48,53)!important;}
    .index-dyPageGoNumber-2Ib1r,.index-topTypeStyle-3MKuW,.editor-editorNotLoginMask-35J9d{background-color: rgb(47,48,53)!important;color: rgb(125,125,125)!important;}
    .index-titleInput-1uVJS{border: 1px solid rgb(47,48,53)!important;background: rgb(47,48,53)!important;color: rgb(167,167,167)!important;}
    .index-dyPage-1CwXA span, .index-dyPage-1CwXA a{color: rgb(125,125,125)!important;background-color: rgb(47,48,53)!important;border: 1px solid rgb(47,48,53)!important;}
    .editor-editorContentRoot-3QvJi{color: rgb(167,167,167)!important;}


    .wb_card-wbCardDetail-wYiL6{background: rgb(35,36,39)!important;}
    .wb_handle-wbRowLine-L5WHa>li{background: rgb(47,48,53)!important;}
    .wb_handle-line-lCiNT{color: rgb(125,125,125)!important;}
    .wb_card-wbCardWrap-OQ\\+ac{border-bottom: rgba(47,48,53,1) solid 1px !important;}
    .wb_card-groupnameAndGrouplevel-Q8fGX{background: rgb(47,48,53)!important;color: rgb(125,125,125)!important;}
    .wb_card-hiddenText-oUz98{color: rgb(125,125,125)!important;}
    .wb_card-wbCardWrap-OQ+ac,.wb_card-topListItemBox-wRCrz{border-bottom:1px solid rgba(47,48,53,1)!important;}
    .index-topTypeStyle-WHbMC{background: rgb(47,48,53)!important;color: rgb(125,125,125)!important;}
    .index-tagWrapper-x5Bnl{color: rgb(125,125,125)!important;}

    .index-dyPage-\\+pup\\+ span, .index-dyPage-\\+pup\\+ a{background-color: rgb(47,48,53)!important;border: 1px solid rgb(125,125,125)!important;}
    input[type="text"], textarea{background-color: rgb(47,48,53)!important;border: 1px solid rgb(125,125,125)!important;}

    .style-newvoteHeadAttendView-JwNdc, .style-indexLefttabcontentItemVote-VxGBz{background: rgb(47,48,53)!important;}
    .style-newvoteHead-CetsR strong{color: rgb(125,125,125)!important;}
    .style-optionWrapper-GJ6RJ{background: rgb(125,125,125)!important;}
    .style-newvotestyleTitle-j27SH{color:rgb(47,48,53)!important;}

    .index-wrapperBox-fPzNk{background: rgb(35,36,39)!important;}
    .index-content-pC8LK,.index-hotTopTitle-q1ajK,.index-title-Hmt3k{color:rgb(167,167,167)!important;}
    .index-aboutTitle-gEBas,.index-title-Hmt3k,.index-itemTitle-M\\+\\+1W{color:rgb(167,167,167)!important;}
    .index-itemContent-ti7Xk{background:rgb(47,48,53)!important;}
    .index-controlBgL-tdJKP,.index-controlBg-Pexdr{background: transparent!important;}
    .index-wrapperBox-fPzNk{border:1px solid rgb(125,125,125) !important;}
    .wb_card-wbCardWrap-4JJpr,.wb_card-topListItemBox-035It{border-bottom:1px solid rgb(125,125,125)!important;}

    .index-aboutTopic-akyQd .index-itemWrap-6-qcp{background: rgb(47,48,53)!important;}
    .index-aboutTopic-akyQd .index-topicName-a5Qxh{color:rgb(167,167,167)!important;}

    .wb_card-wbCardDetail-HysKF{background: rgb(35,36,39)!important;}
    .wb_card-wbInfo-a7-LR a,.wb_card-wbText-mwDSN{color:rgb(167,167,167)!important;}
    .wb_card-groupnameAndGrouplevel-EbL7t{background: rgb(47,48,53)!important;color: rgb(125,125,125)!important;}
    .wb_handle-wbRowLine-6D3SZ a{background: rgb(47,48,53)!important;color: rgb(125,125,125)!important;}
    .wb_handle-line-Dd0zJ{color: rgb(125,125,125)!important;}
    `,null==n.getElementById(e))&&((o=n.createElement("style")).id=e,o.innerHTML=t,n.body.append(o))}var A=[];function gn(e,t,o){switch(o){case"Douyu":bn(e,t);break;case"Bilibili":g=e,cl(h=t,"1",0,e=>{if(""!=e||null!=e){var t=document.createElement("div"),o="",o=(t.id="exVideoDiv"+String(g),t.rid=h,t.className="exVideoDiv",o=(o=(o=(o=(o=(o=(o=(o+="<div class='exVideoInfo' id='exVideoInfo"+String(g)+"'><a title='进入直播间' target='_blank' href='https://live.bilibili.com/"+h+"'><span class='exVideoRID' id='exVideoRID"+String(g)+"' style='color:white'>Bilibili - "+h+"</span></a>")+("<select class='exVideoQn' id='exVideoQn"+String(g)+"'><option value='1'>流畅</option><option value='2'>高清</option><option value='3'>超清</option><option value='4'>蓝光</option><option value='5'>原画</option></select>"))+("<select class='exVideoCDN' id='exVideoCDN"+String(g)+"'><option value='1'>主线路</option><option value='2'>备用线路1</option><option value='3'>备用线路2</option><option value='4'>备用线路3</option></select>"))+`<input id='exVideoEmbed${String(g)}' type='button' value='    ' style='height:30px;'>`)+`<input id='exVideoUnEmbed${String(g)}' type='button' value='恢复视频' style='height:30px;display:none;'>`)+`<input id='exVideoCopy${String(g)}' type='button' value='复制直播流' style='height:30px;'>`)+("<a><div class='exVideoClose' id='exVideoClose"+String(g)+"'>X</div></a>")+"</div>")+("<video controls='controls' class='exVideoPlayer' id='exVideoPlayer"+String(g)+"'></video><div class='exVideoScale' id='exVideoScale"+String(g)+"'></div>"),t.innerHTML=o,k([".layout-Main",".playerWrap__8wGvw",".live-next-body"]));o.insertBefore(t,o.childNodes[0]),yn(g),fn(g);{var p=g;var m=h;let e=document.getElementById("exVideoDiv"+String(p)),t=document.getElementById("exVideoPlayer"+String(p)),o=document.getElementById("exVideoInfo"+String(p)),n=document.getElementById("exVideoScale"+String(p)),i=(t.onclick=function(e){e.stopPropagation(),e.preventDefault(),"block"!=n.style.display?(n.style.display="block",o.style.display="block"):(n.style.display="none",o.style.display="none");for(let e=0;e<A.length;e++){var t=document.getElementById("exVideoDiv"+String(e));null!=t&&(e==p?t.style.zIndex=1016:t.style.zIndex=1428)}},document.getElementById("exVideoQn"+String(p))),a=document.getElementById("exVideoCDN"+String(p)),r=document.getElementById("exVideoClose"+String(p)),l=document.getElementById("exVideoEmbed"+String(p)),s=document.getElementById("exVideoUnEmbed"+String(p)),d=document.getElementById("__video2"),c=(i.onchange=function(){cl(m,i.value,a.value,e=>{A[p].destroy(),hn(p,e)})},a.onchange=function(){cl(m,i.value,a.value,e=>{A[p].destroy(),hn(p,e)})},r.onclick=function(){d.style.display="block",A[p].destroy(),t.remove(),e.remove()},l.onclick=function(){d.style.display="none",l.style.display="none",s.style.display="inline",e.style.height="0px",d.parentElement.insertBefore(t,d)},s.onclick=function(){d.style.display="block",s.style.display="none",l.style.display="inline",e.style.height="250px",e.insertBefore(t,e.childNodes[e.childNodes.length-1])},document.getElementById("exVideoCopy"+String(p)));c.onclick=function(){cl(m,i.value,a.value,e=>{GM_setClipboard(e),S("复制成功","success")})}}hn(g,e)}});break;case"Huya":var n=String(t).split("/");m=e,u=n[n.length-1],i=n[n.length-1],ml(u,"1",(e,t)=>{if(""!=e||null!=e)if(""!=t)S(t,"error");else{var t=document.createElement("div"),o="",o=(t.id="exVideoDiv"+String(m),t.rid=u,t.className="exVideoDiv",o=(o=(o=(o=(o=(o=(o+="<div class='exVideoInfo' id='exVideoInfo"+String(m)+"'><a title='进入直播间' target='_blank' href='"+u+"'><span class='exVideoRID' id='exVideoRID"+String(m)+"' style='color:white'>Huya - "+i+"</span></a>")+("<select class='exVideoQn' id='exVideoQn"+String(m)+"'><option value='1'>流畅</option><option value='2'>超清</option><option value='3'>蓝光4M</option><option value='4'>原画</option></select>"))+`<input id='exVideoEmbed${String(m)}' type='button' value='嵌入视频' style='height:30px;'>`)+`<input id='exVideoUnEmbed${String(m)}' type='button' value='恢复视频' style='height:30px;display:none;'>`)+`<input id='exVideoCopy${String(m)}' type='button' value='复制直播流' style='height:30px;'>`)+("<a><div class='exVideoClose' id='exVideoClose"+String(m)+"'>X</div></a>")+"</div>")+("<video controls='controls' class='exVideoPlayer' id='exVideoPlayer"+String(m)+"'></video><div class='exVideoScale' id='exVideoScale"+String(m)+"'></div>"),t.innerHTML=o,k([".layout-Main",".playerWrap__8wGvw",".live-next-body"]));o.insertBefore(t,o.childNodes[0]),yn(m),fn(m);{var c=m;var p=u;let e=document.getElementById("exVideoDiv"+String(c)),t=document.getElementById("exVideoPlayer"+String(c)),o=document.getElementById("exVideoInfo"+String(c)),n=document.getElementById("exVideoScale"+String(c)),i=document.getElementById("exVideoEmbed"+String(c)),a=document.getElementById("exVideoUnEmbed"+String(c)),r=(t.onclick=function(e){e.stopPropagation(),e.preventDefault(),"block"!=n.style.display?(n.style.display="block",o.style.display="block"):(n.style.display="none",o.style.display="none");for(let e=0;e<A.length;e++){var t=document.getElementById("exVideoDiv"+String(e));null!=t&&(e==c?t.style.zIndex=1016:t.style.zIndex=1428)}},document.getElementById("exVideoQn"+String(c))),l=document.getElementById("exVideoClose"+String(c)),s=document.getElementById("__video2"),d=(r.onchange=function(){ml(p,r.value,(e,t)=>{""!=t?S(t,"error"):(A[c].destroy(),hn(c,e))})},l.onclick=function(){s.style.display="block",A[c].destroy(),t.remove(),e.remove()},document.getElementById("exVideoCopy"+String(c)));d.onclick=function(){ml(p,r.value,(e,t)=>{""!=t?S(t,"error"):(GM_setClipboard(e),S("复制成功","success"))})},i.onclick=function(){s.style.display="none",i.style.display="none",a.style.display="inline",e.style.height="0px",s.parentElement.insertBefore(t,s)},a.onclick=function(){s.style.display="block",a.style.display="none",i.style.display="inline",e.style.height="250px",e.insertBefore(t,e.childNodes[e.childNodes.length-1])}}hn(m,e)}});break;default:bn(e,t)}var m,u,i,g,h}function hn(e,t){var o;flvjs.isSupported()&&(o=document.getElementById("exVideoPlayer"+String(e)),t=flvjs.createPlayer({type:"flv",url:t},{fixAudioTimestampGap:!1}),e>A.length-1?A.push(t):A[e]=t,t.attachMediaElement(o),t.load(),t.play())}function fn(e){let i=document.getElementById("exVideoDiv"+String(e));document.getElementById("exVideoScale"+String(e)).onmousedown=function(e){e.stopPropagation(),e.preventDefault();let t={w:i.offsetWidth,h:i.offsetHeight,x:e.clientX,y:e.clientY},o,n;document.onmousemove=function(e){e.stopPropagation(),e.preventDefault(),o=Math.max(400,e.clientX-t.x+t.w),n=Math.max(0,e.clientY-t.y+t.h),o=o>=document.offsetWidth-i.offsetLeft?document.offsetWidth-i.offsetLeft:o,n=n>=document.offsetHeight-i.offsetTop?document.offsetHeight-i.offsetTop:n,i.style.width=o+"px",i.style.height=n+"px"},document.onmouseup=function(e){e.stopPropagation(),e.preventDefault(),document.onmousemove=null,document.onmouseup=null}}}function yn(e){let a=document.getElementById("exVideoDiv"+String(e));a.onmousedown=function(e){e.stopPropagation();let t=e.clientX-a.offsetLeft,o=e.clientY-a.offsetTop,n,i;document.onmousemove=function(e){e.stopPropagation(),n=e.clientX-t,i=e.clientY-o,a.style.left=n+"px",a.style.top=i+"px"},document.onmouseup=function(e){e.stopPropagation(),document.onmousemove=null,document.onmouseup=null}}}function bn(i,a){pl(a,!0,0,"1",t=>{if(""!=t||null!=t)if("None"==t)S("房间未开播或其他错误","error");else{var o=String(t).split("/live");let e="";0<o.length&&(e=o[0]);var o=document.createElement("div"),n="",n=(o.id="exVideoDiv"+String(i),o.rid=a,o.className="exVideoDiv",n=(n=(n=(n=(n=(n=(n=(n=(n+="<div class='exVideoInfo' id='exVideoInfo"+String(i)+"'><a title='进入直播间' target='_blank' href='https://www.douyu.com/"+a+"'><span class='exVideoRID' id='exVideoRID"+String(i)+"' style='color:white'>斗鱼 - "+a+"</span></a>")+("<select class='exVideoQn' id='exVideoQn"+String(i)+"'><option value='2'>高清</option><option value='3'>超清</option><option value='4'>蓝光4M</option><option value='8'>蓝光8M</option></option><option value='0'>原画</option></select>"))+("<select style='display:none' class='exVideoCDN' id='exVideoCDN"+String(i)+"'><option value='1'>主线路</option><option value='2'>备用线路5</option><option value='3'>备用线路6</option></select>"))+("<a style='margin-left:5px' href='"+e+"' target='_blank'>无视频？</a>"))+`<input id='exVideoEmbed${String(i)}' type='button' value='嵌入视频' style='height:30px;'>`)+`<input id='exVideoUnEmbed${String(i)}' type='button' value='恢复视频' style='height:30px;display:none;'>`)+`<input id='exVideoCopy${String(i)}' type='button' value='复制直播流' style='height:30px;'>`)+("<a><div class='exVideoClose' id='exVideoClose"+String(i)+"'>X</div></a>")+"</div>")+("<video controls='controls' class='exVideoPlayer' id='exVideoPlayer"+String(i)+"'></video><div class='exVideoScale' id='exVideoScale"+String(i)+"'></div>"),o.innerHTML=n,k([".layout-Main",".playerWrap__8wGvw",".live-next-body"]));n.insertBefore(o,n.childNodes[0]),yn(i),fn(i),vn(i,a),hn(i,t)}})}function vn(o,e){let t=document.getElementById("exVideoDiv"+String(o)),n=document.getElementById("exVideoPlayer"+String(o)),i=document.getElementById("exVideoInfo"+String(o)),a=document.getElementById("exVideoScale"+String(o)),r=document.getElementById("exVideoEmbed"+String(o)),l=document.getElementById("exVideoUnEmbed"+String(o)),s=document.getElementById("__video2"),d=(n.onclick=function(e){e.stopPropagation(),e.preventDefault(),"block"!=a.style.display?(a.style.display="block",i.style.display="block"):(a.style.display="none",i.style.display="none");for(let e=0;e<A.length;e++){var t=document.getElementById("exVideoDiv"+String(e));null!=t&&(e==o?t.style.zIndex=1016:t.style.zIndex=1428)}},document.getElementById("exVideoQn"+String(o)));var c=document.getElementById("exVideoCDN"+String(o)),p=document.getElementById("exVideoClose"+String(o));d.onchange=function(){pl(e,!0,0,d.value,e=>{A[o].destroy(),hn(o,e)})},c.onchange=function(){pl(e,!0,0,d.value,e=>{A[o].destroy(),hn(o,e)})},p.onclick=function(){s.style.display="block",A[o].destroy(),n.remove(),t.remove()};let m=document.getElementById("exVideoCopy"+String(o))||document.getElementById("exVideoRID"+String(o));m&&(m.onclick=function(){pl(e,!m.innerHTML.includes("斗鱼音频流"),0,d.value,e=>{GM_setClipboard(String(e).replace("https","http")),S("复制成功","success")})}),r&&(r.onclick=function(){s.style.display="none",r.style.display="none",l.style.display="inline",t.style.height="0px",s.parentElement.insertBefore(n,s)}),l&&(l.onclick=function(){s.style.display="block",l.style.display="none",r.style.display="inline",t.style.height="250px",t.insertBefore(n,t.childNodes[t.childNodes.length-1])})}function xn(s,e){if(""!=e&&null!=e){var t=document.createElement("div"),o="",o=(t.id="exVideoDiv"+String(s),t.rid=B,t.className="exVideoDiv",o=(o=(o=(o=(o=(o+="<div class='exVideoInfo' id='exVideoInfo"+String(s)+`'><span class='exVideoRID' id='exVideoRID" + String(id) + "' style='color:white'>直播流${s}</span>`)+`<input id='exVideoEmbed${String(s)}' type='button' value='嵌入视频' style='height:30px;'>`)+`<input id='exVideoUnEmbed${String(s)}' type='button' value='恢复视频' style='height:30px;display:none;'>`)+`<input id='exVideoCopy${String(s)}' type='button' value='复制直播流' style='height:30px;'>`)+("<a><div class='exVideoClose' id='exVideoClose"+String(s)+"'>X</div></a>")+"</div>")+("<video controls='controls' class='exVideoPlayer' id='exVideoPlayer"+String(s)+"'></video><div class='exVideoScale' id='exVideoScale"+String(s)+"'></div>"),t.innerHTML=o,k([".layout-Main",".playerWrap__8wGvw",".live-next-body"]));o.insertBefore(t,o.childNodes[0]),yn(s),fn(s),hn(s,e);{var d=s;let e=document.getElementById("exVideoDiv"+String(d)),t=document.getElementById("exVideoPlayer"+String(d)),o=document.getElementById("exVideoInfo"+String(d)),n=document.getElementById("exVideoScale"+String(d)),i=document.getElementById("exVideoEmbed"+String(d)),a=document.getElementById("exVideoUnEmbed"+String(d)),r=(t.onclick=function(e){e.stopPropagation(),e.preventDefault(),"block"!=n.style.display?(n.style.display="block",o.style.display="block"):(n.style.display="none",o.style.display="none");for(let e=0;e<A.length;e++){var t=document.getElementById("exVideoDiv"+String(e));null!=t&&(e==d?t.style.zIndex=1016:t.style.zIndex=1428)}},document.getElementById("exVideoClose"+String(d))),l=document.getElementById("__video2");r.onclick=function(){l.style.display="block",A[d].destroy(),t.remove(),e.remove()},i.onclick=function(){l.style.display="none",i.style.display="none",a.style.display="inline",e.style.height="0px",l.parentElement.insertBefore(t,l)},a.onclick=function(){l.style.display="block",a.style.display="none",i.style.display="inline",e.style.height="250px",e.insertBefore(t,e.childNodes[e.childNodes.length-1])}}}}let D={view:"",showtime:1428,danmu_person_count:"",gift_person_count:"",paid_person_count:"",isShow:2,money_yc:0,money_bag:0,money_total:0,noble_count:""},wn=!1;function _n(e){var t=Number(e);return isNaN(t)?e:1e4<=t?(e=t/1e4,Number.isInteger(e)?e+"万":parseFloat(e.toFixed(1))+"万"):String(t)}async function kn(){null!=document.querySelector(".MatchSystemChatRoomEntry")&&(document.querySelector(".MatchSystemChatRoomEntry").style.display="none");e=B;var e,n,t=await new Promise((t,o)=>{GM_xmlhttpRequest({method:"POST",url:"https://www.doseeing.com/xeee/room/aggr",headers:{Connection:"keep-alive","Content-Type":"application/json;charset=UTF-8",Origin:"https://www.doseeing.com",Referer:"https://www.doseeing.com/room/"+e,"User-Agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1 Edg/91.0.4472.114"},data:`{"m":"${window.btoa(`rid=${e}&dt=0`).split("").reverse().join("")}"}`,responseType:"json",onload:e=>{t(e.response)},onerror:e=>{o(e)}})}),o=(n=B,await new Promise((t,o)=>{fetch("https://www.douyu.com/japi/interactnc/web/fsjk/getCardTaskInfo?rid="+n,{method:"GET",mode:"no-cors",credentials:"include"}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{o(e)})}));let i=0;i=2==D.isShow||1428==D.showtime?0:Math.floor(Date.now()/1e3)-Number(D.showtime),D.view=t.data["active.uv"]||0,D.danmu_person_count=t.data["chat.uv"]||0,D.gift_person_count=t.data["gift.all.uv"]||0,D.paid_person_count=t.data["gift.paid.uv"]||0,D.money_yc=Number(t.data["gift.paid.price"]/100||0).toFixed(2),D.money_total=Number(t.data["gift.all.price"]/100||0).toFixed(2),document.getElementById("real-audience__total").innerText=D.view,document.getElementById("real-audience__t").title="今日累计活跃人数:"+D.view+" 弹幕人数:"+D.danmu_person_count+" 送礼人数:"+D.gift_person_count+" 付费人数:"+D.paid_person_count,document.getElementById("real-audience__barrage").innerText=D.danmu_person_count,document.getElementById("real-audience__money_yc").innerText=D.money_yc,document.getElementById("real-audience__money").title="总礼物价值:"+D.money_total+" 鱼翅礼物:"+D.money_yc,""!==D.noble_count&&(document.getElementById("real-audience__noble").innerText=_n(D.noble_count)),document.getElementById("real-audience__time").innerText="已播:"+y(i),document.getElementById("real-audience__time").title="开播时间:"+String(_("yyyy年MM月dd日hh时mm分ss秒 ",new Date(Number(D.showtime+"000"))))+"\n已观看:"+y(o.data.todayWatch),0==o.error&&(document.getElementById("real-audience__watchtime").innerText="已观看:"+y(o.data.todayWatch),document.getElementById("real-audience__watchtime").title="开播时间:"+String(_("yyyy年MM月dd日hh时mm分ss秒 ",new Date(Number(D.showtime+"000"))))+"\n已观看:"+y(o.data.todayWatch))}function En(){var e=document.getElementById("real-audience__time"),t=document.getElementById("real-audience__watchtime");"none"==e.style.display?(e.style.display="block",t.style.display="none"):(e.style.display="none",t.style.display="block")}function Bn(){var e={barrageFrame:{status:"none"==document.getElementsByClassName("layout-Player-rank")[0].style.display},video:{status:Nn()},barrage:{status:1==In}};localStorage.setItem("ExSave_Refresh",JSON.stringify(e))}let In=0;function Sn(){_l("Ex_Style_RefreshBarrage",`
    .UserCsgoGameDataMedal,.Barrage-honor,.Barrage-listItem .Barrage-icon,.Barrage-listItem .FansMedal.is-made,.Barrage-listItem .RoomLevel,.Barrage-listItem .Motor,.Barrage-listItem .ChatAchievement,.Barrage-listItem .Barrage-hiIcon,.Barrage-listItem .Medal,.Barrage-listItem .MatchSystemTeamMedal{display:none !important;}
    /*.Barrage-listItem .UserLevel{display:none !important;}*/
    .Barrage-listItem .Baby{display:none !important;}
    .FansMedalWrap{display:none !important;}
    `),In=1,document.getElementById("refresh-barrage").classList.add("ex-active"),document.getElementById("refresh-barrage__text").style.color="#fff",document.getElementById("refresh-barrage__text").innerText="前缀";var e=document.getElementById("refresh-barrage__svg");e&&(e=e.getElementsByTagName("path")[0])&&e.setAttribute("fill","#ffffff")}let Cn=0;function Tn(e){var t=document.getElementById("ex-refresh-switch"),o=document.getElementById("ex-refresh-switch-circle");t&&o&&(e?(t.style.background="#f60",o.style.left="14px"):(t.style.background="rgba(255,255,255,0.3)",o.style.left="2px"))}function Nn(){return"hidden"==document.getElementsByClassName("PlayerToolbar-ContentRow")[0].style.visibility}function Mn(){_l("Ex_Style_VideoRefresh",`
    .PELact,.pushTower-wrapper-gf1HG,.PkView-9f6a2c,.MorePk,.RandomPKBar,.LiveRoomLoopVideo,.LiveRoomDianzan,.maiMaitView-68e80c,.PkView{display:none !important;}
    `)}function Ln(){_l("Ex_Style_RemoveAD",`
    .ScreenBannerAd,.XinghaiAd,.CustomGroupGuide,.FudaiGiftToolBarTips,.UserInfo-tryEnterHiddenLead,.BargainingKit,.AnchorPocketTips,.FishShopTip,.FollowGuide,#js-bottom-right-cloudGame,.CloudGameLink,.RoomText-icon-horn,.RoomText-list,.Search-ad,.RedEnvelopAd,.noHandlerAd-0566b9,.PcDiversion,.DropMenuList-ad,.DropPane-ad,.WXTipsBox,.igl_bg-b0724a,.closure-ab91fb,.VideoAboveVivoAd,.css-widgetWrapper-EdVVC,.watermark-442a18,.FollowGuide-FadeOut,.MatchSystemChatRoomEntry-roomTabs,.FansMedalDialog-normal,.GameLauncher,.recommendAD-54569e,.recommendApp-0e23eb,.Title-ad,.Bottom-ad,.SignBarrage,.corner-ad-495ade,.SignBaseComponent-sign-ad,.SuperFansBubble,.is-noLogin,.PlayerToolbar-signCont,#js-widget,.Frawdroom,.HeaderGif-right,.HeaderGif-left,.liveos-workspace{display:none !important;}
    .Barrage-topFloater{z-index:999}
    .danmuAuthor-3d7b4a, .danmuContent-25f266{overflow: initial}
    .BattleShipTips{display:none !important;}
    .LastLiveTime,.recommendView-3e8b62{display:none !important;}
    .TurntableLottery-actTips{display:none !important;}
    .feedback-e27241{display:none !important;}
    .FansMedalEnter-maxFlag{display:none !important;}
    .Header-follow-listBox{max-height:640px !important;}

    .GuessGameMiniPanelB-wrapper{display:none !important;}

    .ZoomTip{display:none !important;}

    /*福利券*/
    .PlayerToolbar-couponInfo{display:none !important;}
    /*太空探险tips*/
    .AroundStarsActTips-actTips,.AroundStarsMoonBoxTips,.AroundStarsPlanetTips{display:none !important;}
    /*优化页面*/
    #js-barrage-list-parent{scrollbar-width: none;-ms-overflow-style: none;width:98%;height:100%}
    #js-barrage-list-parent::-webkit-scrollbar{display: none;}
    /*陪玩*/
    .InteractPlayWithEnter-enterTips1{display:none !important;}

    /*恢复emoji彩色 chrome加粗情况下emoji会变灰，需要找一个fontweight起始值在500的字体库才可以兼容*/

    /*右侧分享*/
    .SharePanel,.CommonShareToolkit{
        display: none!important;
    }
    /*去除还在电脑面前的mask*/
    .mask1-63237a,.mask2-a8df6e,.panel1-1484c9,.panel2-5ece0e{
        display: none!important;
    }
    /*左侧悬浮二维码广告*/
    .IconCardAdCard{
        display: none!important;
    }
    /*视频右侧的游戏手柄按钮AD*/
    .IconCardAd {
        display: none!important;
    }
    /*视频区视频广告*/
    .CloseVideoPlayerAd,.IconCardAdBoundsBox{
        display: none!important;
    }
    /*直播间顶部广告*/
    .room-top-banner-box {
        display: none!important;
    }
    /*弹幕框底部进场弹幕信息*/
    #js-barrage-extend-container {
        display: none!important;
        display: var(--enter-display, none) !important;
    }
    /*直播间右侧广告*/
    .LadderNav {
        display: none!important;
    }
    #js-bottom-right-recommendAd {
        display: none!important;
    }
    /*弹幕框顶部广告*/
    .aside-top-uspension-box {
        display: none!important;
    }
    #js-player-asideMain {
        top: 0!important;
    }
    /*右下角联系客服*/
    .bacpCommonKeFu {
        display: none!important;
    }

    .werbungContainer__2sv7h{display:none !important;}
    #js-player-asideTopSuspension{display:none !important;}
    .Search-Panel-Advert{display:none !important;}
    `)}let An=0;function Dn(){_l("Ex_Style_RemoveMsgNotice",".UserInfo .Badge,.ChatLetter-PopUnread{display:none!important;}")}function jn(){var t=zn(window.location.href),o=new URLSearchParams(window.location.search).get("exRestore");if(o&&t!==(o=Number(o))){{var s=t;var d=o;let e=["web/group/head","/follow/topic","group/unfollowGroup"];function c(t){return"string"==typeof t&&e.some(e=>t.includes(e))}let a=unsafeWindow.XMLHttpRequest.prototype.open,r=unsafeWindow.XMLHttpRequest.prototype.send,l=(unsafeWindow.XMLHttpRequest.prototype.open=function(e,t,o,n,i){return"string"==typeof t&&t.includes(s)&&!c(t)&&(t=t.replace(new RegExp(s,"g"),d)),a.call(this,e,t,o,n,i)},unsafeWindow.XMLHttpRequest.prototype.send=function(e){var t=this.responseURL||this._url||"";if(!c(t))if(e&&"string"==typeof e&&e.includes(s))e=e.replace(new RegExp(s,"g"),d);else if(e&&e instanceof FormData){var o,n=new FormData;for(o of e.entries()){var i=o[0];let e=o[1];"string"==typeof e&&e.includes(s)&&(e=e.replace(new RegExp(s,"g"),d)),n.append(i,e)}e=n}return r.call(this,e)},unsafeWindow.fetch);unsafeWindow.fetch=function(e,t){let o="";if("string"==typeof e?(o=e).includes(s)&&!c(e)&&(e=e.replace(new RegExp(s,"g"),d)):e instanceof Request&&(o=e.url).includes(s)&&!c(o)&&(e=new Request(o.replace(new RegExp(s,"g"),d),e)),!c(o)&&t&&t.body)if("string"==typeof t.body&&t.body.includes(s))t.body=t.body.replace(new RegExp(s,"g"),d);else if(t.body instanceof FormData){var n,i=new FormData;for(n of t.body.entries()){var a=n[0];let e=n[1];"string"==typeof e&&e.includes(s)&&(e=e.replace(new RegExp(s,"g"),d)),i.append(a,e)}t.body=i}return l.call(unsafeWindow,e,t)}}(async o=>{if(o=await(e=>new Promise(t=>{fetch("https://yuba.douyu.com/wbapi/web/group/managersdetail?group_id="+e).then(e=>e.json()).then(e=>{t(e)}).catch(()=>{t(null)})}))(o)){o=o.data.generalOP[0];let e=o.avatar,t=o.nick_name;function n(){document.querySelector(".groupavatar__9mD1S .image__GNnZC").src=e,document.getElementsByClassName("groupname__BUzOM")[0].innerText=t,document.getElementsByClassName("groupdesc__b8-53")[0].innerText=t+"的鱼吧",document.title=t+"的鱼吧"}n(),new G(".groupavatar__9mD1S",!1,()=>{n()})}})(o)}}function Pn(){let t=zn(window.location.href);var e;t&&(e=t,new Promise((t,o)=>{fetch("https://yuba.douyu.com/wbapi/web/group/head?group_id="+e).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{o(e)})}).then(e=>{3002==e.status_code&&(e="https://yuba.douyu.com/discussion/4815048/posts?exRestore="+t,window.location.href=e)}))}function zn(e){e=e.match(/\/discussion\/(\d+)/);return e&&e[1]?e[1]:null}let On=5;let Rn=!!(l=localStorage.getItem("ExSave_isRemoveDanmakuBackground"))&&1===Number(l);function Fn(){document.getElementsByClassName("FilterKeywords")[0].insertAdjacentHTML("afterbegin",`<div class="FilterSwitchStatus" id="ex-removeDanmakuBackground">
    <h3>屏蔽弹幕背景</h3>
    <div>
      <span class="FilterSwitchStatus-status ${Rn?"is-checked":"is-noChecked"}">${Rn?"已开启":"未开启"}</span>
      <span class="FilterSwitchStatus-switch ${Rn?"is-checked":"is-noChecked"}">
        <span class="FilterSwitchStatus-switch-inner"></span>
      </span>
    </div>
  </div>`);var e=document.getElementById("ex-removeDanmakuBackground");let t=e.querySelector(".FilterSwitchStatus-status"),o=e.querySelector(".FilterSwitchStatus-switch");e.addEventListener("click",()=>{(Rn=!Rn)?(Hn(),t.className=t.className.replace("is-noChecked","is-checked"),t.textContent="已开启",o.className=o.className.replace("is-noChecked","is-checked")):(V("Ex_Style_RemoveDanmakuBackground"),t.className=t.className.replace("is-checked","is-noChecked"),t.textContent="未开启",o.className=o.className.replace("is-checked","is-noChecked")),localStorage.setItem("ExSave_isRemoveDanmakuBackground",Rn?1:0)})}function Hn(){_l("Ex_Style_RemoveDanmakuBackground",`
      .danmuItem-a8616a {
        background: none !important;
      }
      .danmuItem-a8616a div{
        background: none;
      }
      .danmuItem-a8616a > img {
        display: none;
      }
      .danmuItem-a8616a div > img {
        display: none;
      }
      .super-text-f60bfa {
        background: none !important;
      }
      .danmuItem-a8616a .noble-d35c82 {
        background: none !important;
      }
      .customBarrage {
        background: none !important;
        text-shadow: none !important;
      }
      .customBarrage > div {
        background: none !important;
      }
      .PlayerCustomBarrage-prefixPlugin--text {
        display: none !important;
      }
  `)}Rn&&Hn(),(t=localStorage.getItem("ExSave_isRemoveDanmakuImage"))&&Number(t);let Gn=!!(l=localStorage.getItem("ExSave_isRemoveEnterBarrage"))&&1===Number(l);function Vn(){var o=document.getElementsByClassName("FilterKeywords")[0],n=window.CSS&&window.CSS.supports&&window.CSS.supports("--enter-display","none");let i=document.getElementById("js-barrage-extend-container");if(null!=o&&n){o.insertAdjacentHTML("afterbegin",`<div class="FilterSwitchStatus" id="ex-removeEnterBarrage">
    <h3>屏蔽进场弹幕</h3>
    <div>
      <span class="FilterSwitchStatus-status ${Gn?"is-checked":"is-noChecked"}">${Gn?"已开启":"未开启"}</span>
      <span class="FilterSwitchStatus-switch ${Gn?"is-checked":"is-noChecked"}">
        <span class="FilterSwitchStatus-switch-inner"></span>
      </span>
    </div>
  </div>`),Gn?i&&i.style.setProperty("--enter-display","none","important"):i&&i.style.setProperty("--enter-display","block","important");n=document.getElementById("ex-removeEnterBarrage");let e=n.querySelector(".FilterSwitchStatus-status"),t=n.querySelector(".FilterSwitchStatus-switch");n.addEventListener("click",()=>{(Gn=!Gn)?(i&&i.style.setProperty("--enter-display","none","important"),e.className=e.className.replace("is-noChecked","is-checked"),e.textContent="已开启",t.className=t.className.replace("is-noChecked","is-checked")):(i&&i.style.setProperty("--enter-display","block","important"),e.className=e.className.replace("is-checked","is-noChecked"),e.textContent="未开启",t.className=t.className.replace("is-checked","is-noChecked")),localStorage.setItem("ExSave_isRemoveEnterBarrage",Gn?1:0)})}}let qn="1"===localStorage.getItem("ExSave_isRemoveRepeatedDanmaku"),Un=(()=>{var e=localStorage.getItem("ExSave_repeatedDanmakuSeconds");if(e){e=parseInt(e);if(!isNaN(e)&&1<=e&&e<=60)return e}return 5})(),Wn=null!==(t=localStorage.getItem("ExSave_isEnlargeDanmaku"))&&"1"===t,Yn={},Qn={},Jn={},Zn={},Xn=new WeakMap,Kn=null,$n=null;function ei(){document.getElementsByClassName("FilterKeywords")[0].insertAdjacentHTML("afterbegin",`<div class="FilterSwitchStatus" id="ex-removeRepeatedDanmaku">
    <h3>屏蔽重复弹幕</h3>
    <div>
      <span class="FilterSwitchStatus-status ${qn?"is-checked":"is-noChecked"}">${qn?"已开启":"未开启"}</span>
      <span class="FilterSwitchStatus-switch ${qn?"is-checked":"is-noChecked"}">
        <span class="FilterSwitchStatus-switch-inner"></span>
      </span>
    </div>
  </div>
  <p class="FilterKeywords-intelligentText" style="display: flex; align-items: center;justify-content: space-between;">
    <span>
      <input type="number" id="ex-repeatedDanmakuSeconds" min="1" max="300" value="${Un}" style="width: 38px; height: 14px; text-align: center;" />
      <span>秒内重复的弹幕只显示一次</span>
    </span>
    <label style="margin-left: 10px;display: inline-flex; align-items: center;">
      <input type="checkbox" id="ex-enlargeDanmaku" ${Wn?"checked":""} style="margin-right: 4px;" />
      放大重复弹幕
    </label>
  </p>`);var e=document.getElementById("ex-removeRepeatedDanmaku");let t=e.querySelector(".FilterSwitchStatus-status"),o=e.querySelector(".FilterSwitchStatus-switch"),n=document.getElementById("ex-repeatedDanmakuSeconds"),i=document.getElementById("ex-enlargeDanmaku");n.addEventListener("click",e=>{e.stopPropagation()}),i.addEventListener("click",e=>{e.stopPropagation()}),n.addEventListener("input",()=>{let e=parseInt(n.value);var t;isNaN(e)||e<1?(e=1,n.value=1):300<e&&(e=300,n.value=300),Un=e,t=e,localStorage.setItem("ExSave_repeatedDanmakuSeconds",t.toString()),qn&&($n&&($n.closeHook(),$n=null),ni(),ti())}),i.addEventListener("change",()=>{var e;Wn=i.checked,e=Wn,localStorage.setItem("ExSave_isEnlargeDanmaku",e?"1":"0")}),e.addEventListener("click",()=>{(qn=!qn)?(ti(),t.className=t.className.replace("is-noChecked","is-checked"),t.textContent="已开启",o.className=o.className.replace("is-noChecked","is-checked")):($n&&($n.closeHook(),$n=null),ni(),V("Ex_Style_RemoveRepeatedDanmaku"),V("Ex_Style_RemoveRepeatedDanmaku_Count"),t.className=t.className.replace("is-checked","is-noChecked"),t.textContent="未开启",o.className=o.className.replace("is-checked","is-noChecked"));var e=qn;localStorage.setItem("ExSave_isRemoveRepeatedDanmaku",e?"1":"0")})}function ti(){_l("Ex_Style_RemoveRepeatedDanmaku_Count",`
    /* 弹幕计数显示样式 */
    [data-repeat-count]::before {
      content: "x" attr(data-repeat-count);
      font-weight: bold;
      display: inline-block;
      position: absolute;
      right: -18px;
      bottom: 0;
      font-size: 16px;
      font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
      color: inherit;
    }
    
    /* 计数跳动动画 */
    @keyframes danmaku-combo-bounce {
      0% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.5);
      }
      100% {
        transform: scale(1);
      }
    }
    
    /* 应用动画的类 */
    .danmaku-combo-animation::before {
      animation: danmaku-combo-bounce 0.2s ease-out;
    }
    `);let e=setInterval(()=>{document.querySelector(".danmu-fbb2a3")&&(clearInterval(e),Kn=Kn||setInterval(oi,2e4),$n=new G(".danmu-fbb2a3",!1,i=>{if(!(i.length<=0)&&qn)if(i[0].addedNodes.length<=0&&0<i[0].removedNodes.length){var n=i[0].removedNodes[0];let e=n.comment.uuid;var a=n.comment.startTime+n.comment.duration;let t=Date.now();if(t>a)return;Qn[e]=t+1e3*Un;let o=n.textContent?n.textContent.trim():"";void(o&&Jn[o]===n&&(delete Jn[o],delete Zn[o],delete Yn[o]))}else if(!(i[0].addedNodes.length<=0)){a=i[0].addedNodes[0];if(a){let e=Date.now(),t=a.comment.uuid;n=Qn[t];if(!(n&&e<=n)){let n=a.textContent?a.textContent.trim():"";if(n&&0!==n.length){i=Yn[n];if(i&&e<=i){if(a.className+=" repeated-danmaku",Zn[n]=(Zn[n]||1)+1,Wn){let o=Jn[n];o&&o.parentNode?requestAnimationFrame(()=>{var e,t;o.parentNode&&(Xn.has(o)||(t=window.getComputedStyle(o),Xn.set(o,t.fontSize)),t=Xn.get(o),t=parseFloat(t)||20,e=Zn[n],t=Math.min(t+2*(e-1),40),o.style.fontSize=t+"px",o.setAttribute("data-repeat-count",e),o.classList.remove("danmaku-combo-animation"),requestAnimationFrame(()=>{o.parentNode&&o.classList.add("danmaku-combo-animation")}))}):o&&o.parentNode||(delete Jn[n],delete Zn[n])}}else Yn[n]=e+1e3*Un,Jn[n]=a,Zn[n]=1}}}}}))},1e3)}function oi(){var e,t,o=Date.now();for([e,t]of Object.entries(Yn))t<=o&&(delete Yn[e],delete Jn[e],delete Zn[e]);for(let[e,t]of Object.entries(Qn))t<=o&&delete Qn[e]}function ni(){Kn&&(clearInterval(Kn),Kn=null),Yn={},Qn={},Jn={},Zn={}}function ii(){ei(),Vn(),Fn()}function ai(e){return-1===e.indexOf("player_barrage")?e:e.replace(/player_barrage\\":0/g,'player_barrage\\":1').replace(/"player_barrage":0/g,'"player_barrage":1')}function ri(e){(async()=>{let t=[],o=await vi(1),n=(t=t.concat(o.list),Number(o.count_page)-1);if(1<=n)for(let e=0;e<n;e++){var i=2+e;o=await vi(i),t=t.concat(o.list)}hi=t.length,GM_xmlhttpRequest({method:"POST",url:"https://mapi-yuba.douyu.com/wb/v3/fastSign",responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded",client:"android",token:m},onload:function(e){""==e.response.message&&0!=e.response.data||e.response.data}});for(let e=0;e<t.length;e++)!async function t(o,n){GM_xmlhttpRequest({method:"POST",url:"https://yuba.douyu.com/ybapi/topic/sign",data:"group_id="+o,responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded","dy-client":"pc","dy-token":n,Referer:"https://yuba.douyu.com/group/"+o},onload:async function(e){10<=yi[o]||("签到失败"==e.response.message?(await b(2e3),t(o,n)):(yi[o]?yi[o]++:yi[o]=1,fi++,""==e.response.message&&gi++,bi(o),fi==hi&&(0<gi?hi-gi==0?S("【鱼吧】"+String(gi)+"个鱼吧签到完成","success"):S("【鱼吧】"+String(gi)+"个鱼吧签到完成，"+String(hi-gi)+"个鱼吧已签到","success"):S("【鱼吧】"+String(hi)+"个鱼吧已签到","warning"),gi=null,hi=null,fi=null)))}})}(t[e].group_id,m)})(),GM_xmlhttpRequest({method:"POST",url:"https://apiv2.douyucdn.cn/h5nc/sign/sendSign",data:"token="+m,responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded"},onload:function(e){var o=e.response;if(0==o.data.length)S("【客户端】今日已签到","warning");else if(0!=o.data.sign_pl.length){let t="";for(let e=0;e<o.data.sign_pl.length;e++)t=t+o.data.sign_pl[e].cnt+"个"+o.data.sign_pl[e].name+",";S("【客户端】签到成功! 获得物品:"+t,"success")}else S("【客户端】签到成功! 可惜没有获得东西","success")}}),e=e;{var r=e;let t=0,i=0,a=0;fetch("https://www.douyu.com/wgapi/livenc/liveweb/follow/list?page=1428",{method:"GET",mode:"no-cors",cache:"default",credentials:"include"}).then(e=>e.json()).then(e=>{t=Number(e.data.pageCount);for(let e=1;e<=t;e++)fetch("https://www.douyu.com/wgapi/livenc/liveweb/follow/list?page="+String(e),{method:"GET",mode:"no-cors",cache:"default",credentials:"include"}).then(e=>e.json()).then(t=>{var o,n=Number(t.data.list.length);for(let e=0;e<n;e++)(0!=r||"1"==t.data.list[e].show_status)&&(ui(t.data.list[e].room_id),i++),++a==t.data.total&&e==n-1&&(o=Number(t.data.total)-i,S("【房间签到】"+String(i)+"个房间签到已完成，"+String(o)+"个房间未签到","success"))}).catch(e=>{console.log("请求失败!",e)});S("【房间签到】"+e.data.total+"个房间正在签到中...","info")}).catch(e=>{console.log("请求失败!",e)})}(async()=>{if("data"in li!=0)for(let e=0;e<li.data.length;e++){var o=li.data[e],n=o.name;for(let e=0;e<o.script.length;e++){var i,a=o.script[e],r=a.value;let t;switch(a.name){case"signAct":"0"==(t=await(e=>new Promise(t=>{fetch("https://www.douyu.com/japi/carnival/nc/signAct/signIn",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"token="+m+"&signAlias="+e}).then(e=>e.json()).then(e=>{t(e)})}))(r)).error?S(`【${n}】签到完毕`,"success"):S(`【${n}】`+t.msg,"error");break;case"userStatus":if(0==(t=await(e=>new Promise(t=>{fetch("https://www.douyu.com/japi/carnival/nc/actTask/userStatus",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`tasks=${e}&token=`+m}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})}))(r)).error)for(var l in t.data){var s=t.data[l],d=s.curCompleteNum-s.curDeliverNum,c=n+"-"+s.taskName;for(let e=0;e<d;e++){var p=await(e=>new Promise(t=>{fetch("https://www.douyu.com/japi/carnival/nc/actTask/takePrize",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`token=${m}&aid=android&taskAlias=`+e}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})}))(l);"0"==p.error?S(`【${c}】获得`+p.data.sendRes.items[0].prizeName+"*"+p.data.sendRes.items[0].prizeNum,"success"):S(`【${c}】`+p.msg,"error")}}break;case"addFollowRoom":await Kr(r);break;case"removeFollowRoom":await $r(r);break;case"shareAct":await(e=>new Promise(t=>{fetch("https://www.douyu.com/japi/carnival/common/share",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`actAlias=${e}&token=`+m}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})}))(r);break;case"doSign":await(e=>new Promise(t=>{fetch("https://www.douyu.com/japi/carnival/nc/hostSnowSign/doSign",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`actAlias=${e}&token=${m}&ctn=`+x()}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})}))(r);break;case"getActRemaining":if("0"==(t=await(e=>new Promise(t=>{fetch("https://www.douyu.com/japi/carnival/nc/lottery/remaining?activityId="+e,{method:"GET",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/json;charset=UTF-8"}}).then(e=>e.json()).then(e=>{t(e)})}))(r)).error)for(let e=0;e<t.data.freeCount;e++)"0"==(i=await(e=>new Promise(t=>{fetch("https://www.douyu.com/japi/carnival/nc/lottery/jackpot",{method:"POST",headers:{"Content-Type":"application/json;charset=UTF-8"},body:`{"activityId":"${e}","token":"${m}"}`}).then(e=>e.json()).then(e=>{t(e)})}))(r)).error&&S(`【${n}】礼盒开启：`+i.data.giftName,"success")}}}})(),(async()=>{let e=["5189167","290935","6979222","5132174","4042402"],t=await si(_("yyyyMM",new Date)),o=(t||(a=new Date,n=a.getMonth()+1,i=a.getMonth()-1,i=new Date(a.getFullYear(),i,1),a=new Date(a.getFullYear(),n,1),t=(t=await si(_("yyyyMM",i)))||await si(_("yyyyMM",a))),await di(_("yyyyMM",new Date)));var n,i,a,r,l,s;o||(n=new Date,i=n.getMonth()+1,a=n.getMonth()-1,l=new Date(n.getFullYear(),a,1),r=new Date(n.getFullYear(),i,1),o=(o=await di(_("yyyyMM",l)))||await di(_("yyyyMM",r)));for(s of l=[t,o])for(var d of e){var c=await((e,n)=>new Promise((t,o)=>{fetch("https://www.douyu.com/japi/revenuenc/web/actqzs/userTask/signIn",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&activity_id=${e}&rid=`+n}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}))(s,d),c=(0==c.error&&S("【一键签到】右侧活动直播间已签到，获得"+c.data.awards.map(e=>e.name+"x"+e.num).join("、"),"success"),await((e,n)=>new Promise((t,o)=>{fetch("https://www.douyu.com/japi/revenuenc/web/cardArena/userTask/signIn",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&activity_id=${e}&rid=`+n}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}))(s,d));0==c.error&&S("【一键签到】右侧活动直播间已签到，获得"+c.data.awards.map(e=>e.name+"x"+e.num).join("、"),"success")}})(),(async()=>{for(let e=0;e<5;e++)await!GM_xmlhttpRequest({method:"GET",url:"https://yuba.douyu.com/wbapi/web/post/detail/555691541586843641?cid=&timestamp="+(new Date).getTime(),responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded","dy-token":m,"dy-client":"pc"},onload:function(e){}}),await b(2e3)})(),(async()=>{var e="3186571",n=(await(e=>new Promise((t,o)=>{fetch("https://www.douyu.com/wgapi/livenc/liveweb/follow/add",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&rid=`+e}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}))(e),e);await new Promise((t,o)=>{fetch("https://www.douyu.com/wgapi/livenc/liveweb/follow/rm",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&rid=`+n}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})})})(),(async()=>{for(let e=0;e<Fo.length;e++){var t=Fo[e],o=await(e=>new Promise((t,o)=>{fetch("https://www.douyu.com/japi/interactnc/web/fanshome/sign",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&rid=`+e}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}))(t);0!==o.error?S("【粉丝家园】"+t+o.msg,"error"):S(`【粉丝家园】${t}签到成功！`,"success")}})(),(async()=>{for(let e=0;e<Fo.length;e++){var t=Fo[e];0===(await(e=>new Promise((t,o)=>{fetch("https://www.douyu.com/japi/interactnc/web/dfansact/userSign",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&rid=`+e}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}))(t)).error&&S(`【钻粉联赛签到】${t}签到成功！`,"success")}})(),(async()=>{var e;0==(e=await(e=>new Promise((t,o)=>{fetch("https://www.douyu.com/japi/carnivalApi/sign/doSign",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`csrfToken=${e}&signAlias=20250521OPFOY_qd2&useJiYan=false`}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}))(e=await new Promise(i=>{GM_xmlhttpRequest({method:"POST",url:"https://www.douyu.com/japi/carnival/nc/common/generateCsrf",headers:{"Content-Type":"application/json",Cookie:document.cookie},anonymous:!1,withCredentials:!0,onload:function(e){var t;let o="";for(t of e.responseHeaders.match(/set-cookie:[^\n\r]+/gi)){var n=t.match(/cvl_csrf_token=([^;]+)/);if(n){o=n[1];break}}i(o)},onerror:function(e){i("")}})}))).error||31200==e.error?S("【积分任务】"+e.msg,"success"):S("【积分任务】"+e.msg,"error")})(),(async()=>{var t=(await new Promise((t,o)=>{fetch(`https://www.douyu.com/japi/livebiznc/web/anchorstardiscover/rank/info?rid=${B}&type=5&track=3`,{method:"GET",mode:"no-cors",credentials:"include"}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}).catch(()=>{})).data.rankItemList;if(t&&0!=t.length){for(let e=0;e<3;e++){var o=t[e].rid;o&&(await(e=>new Promise((t,o)=>{fetch("https://www.douyu.com/japi/livebiznc/web/anchorstardiscover/user/task/report",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&type=5&rid=`+e}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}))(o),await b(500))}S("【星推】签到任务完成","success");for(let e=0;e<5;e++){var n,i=t[e].rid;i&&(n=await Kr(i),await b(500),1==n.error?(await $r(i),await b(500),await Kr(i)):await $r(i),await b(500))}S("【星推】关注任务完成","success")}})()}qn&&ti();let li={};function si(e){return new Promise(o=>{fetch(`https://webconf.douyucdn.cn/resource/common/activity/actqzs${e}_w.json`).then(e=>e.text()).then(e=>{let t=e.substring(String("DYConfigCallback(").length,e.length);t=t.substring(0,t.lastIndexOf(")"));try{t=JSON.parse(t),o(t.data.activity_setting.activity_id)}catch(e){o(null)}}).catch(e=>{o(null)})})}function di(e){return new Promise(o=>{fetch(`https://webconf.douyucdn.cn/resource/common/activity/cardArena${e}_w.json`).then(e=>e.text()).then(e=>{let t=e.substring(String("DYConfigCallback(").length,e.length);t=t.substring(0,t.lastIndexOf(")"));try{t=JSON.parse(t),o(t.data.activity_setting.activity_id)}catch(e){o(null)}}).catch(e=>{o(null)})})}function ci(t){let o="";var n=document.cookie.split("; ");for(let e=0;e<n.length;e++){var i=n[e].split("=");t==i[0]&&(o=i[1])}return""==o&&(o=Math.random().toString(36).substr(2),document.cookie="post-csrfToken="+escape(o)+";path=/"),o}async function pi(){var e,o,n,t=await new Promise(t=>{GM_xmlhttpRequest({method:"GET",url:"https://msg.douyu.com/v3/login/getusersig?t="+String((new Date).getTime())+"&timestamp="+Math.random().toFixed(17),data:'{"State":"Online"}',responseType:"json",headers:{"dy-device-id":"-","dy-client":"web","dy-csrf-token":ci("post-csrfToken"),"Content-Type":"application/x-www-form-urlencoded"},onload:function(e){t(e.response)}})}),i=await((e,t)=>{let o="https://webim.tim.qq.com/v4/openim/login?identifier="+e+"&usersig="+t+"&contenttype=json&sdkappid=1400029396";return new Promise(t=>{GM_xmlhttpRequest({method:"POST",url:o,data:'{"State":"Online"}',responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},onload:function(e){t(e.response)}})})})(t.data.uid,t.data.sig);e=i.TinyId,o=i.A2Key,n=t.data.uid;let a=await new Promise(t=>{GM_xmlhttpRequest({method:"POST",url:"https://webim.tim.qq.com/v4/group_open_http_svc/get_joined_group_list?tinyid="+e+"&a2="+o+"&contenttype=json&sdkappid=1400029396",data:'{"Member_Account":"'+n+'"}',responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded"},onload:function(e){e.response.GroupIdList&&0<e.response.GroupIdList.length?t(e.response.GroupIdList[0].GroupId):t("")}})});a&&""!=a?(console.log("mid是：",a),a=encodeURIComponent(a),GM_xmlhttpRequest({method:"GET",url:"https://msg.douyu.com/v3/motorcade/signs/weekly?mid="+a+"&timestamp="+Math.random().toFixed(17),responseType:"json",headers:{"dy-device-id":"-","dy-client":"web","dy-csrf-token":ci("post-csrfToken"),"Content-Type":"application/x-www-form-urlencoded"},onload:function(e){e=e.response;console.log("weekly:",e),"1"==e.data.is_sign?J():GM_xmlhttpRequest({method:"POST",url:"https://msg.douyu.com/v3/msign/add?timestamp="+Math.random().toFixed(17),data:"to_mid="+a+"&expression="+String(Number(e.data.total)+1),responseType:"json",headers:{"dy-device-id":"-","dy-client":"web","dy-csrf-token":ci("post-csrfToken"),"Content-Type":"application/x-www-form-urlencoded"},onload:function(e){2==Math.floor(e.response.status_code/100)?console.log("【车队】签到成功"):console.log(e.response.message),J()}})}})):J()}async function mi(){var e=await new Promise((t,o)=>{fetch("https://www.douyu.com/wgapi/activitync/gametask/viewStatus",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&actAlias=20250521OPFOY`}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e),o(e)})}),t=e.data.taskList,o=e.data.startTime;if(t)for(var n in t)2===t[n].status&&(0==(n=await((e,o)=>new Promise(t=>{fetch("https://www.douyu.com/wgapi/activitync/gametask/takeGift",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`ctn=${x()}&id=${e}&actAlias=20250521OPFOY&startTime=`+o}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})}))(n,o)).error?S("【积分任务】观时积分领取成功","success"):S("【积分任务】"+n.msg,"error"))}function ui(e){GM_xmlhttpRequest({method:"POST",url:"https://apiv2.douyucdn.cn/japi/roomuserlevel/apinc/checkIn?client_sys=android",data:"rid="+e,responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded",token:m,aid:"android1"},onload:function(e){}})}let gi=0,hi=0,fi=0,yi={};async function bi(t){var o=await xi(t);for(let e=0;e<o.data.supplementary_cards;e++)await xi(t)}function vi(e){return new Promise(t=>{GM_xmlhttpRequest({method:"GET",url:"https://yuba.douyu.com/wbapi/web/group/myFollow?page="+String(e)+"&limit=30",responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded","dy-client":"pc","dy-token":m},onload:function(e){t(e.response.data)}})})}function xi(e){return new Promise(t=>{GM_xmlhttpRequest({method:"POST",url:"https://mapi-yuba.douyu.com/wb/v3/supplement",responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded",client:"android",token:m},data:"group_id="+e,onload:function(e){t(e.response)}})})}var wi="2026.06.03.01",_i=!1,ki="";async function Ei(t=!1){let o=[];_i=(o=await new Promise((t,o)=>{GM_xmlhttpRequest({method:"GET",url:"https://src.douyuex.com/src/douyuex_version.txt?t="+(new Date).getTime(),responseType:"text",onload:function(e){e=e.response;null!=e&&e!=wi&&t([!0,e]),t(!1)},onerror:function(e){console.error("请求失败",e),o()}})}).catch(e=>{o=[!1,wi],_i=o[0],ki=o[1],_i?(Si(),_i&&Ii(!0)):t&&S(`【版本更新】当前版本${wi}已为最新，<a href="https://html.douyuex.com/update/" target="_blank">点击查看更新内容</a>`,"success")}))[0],ki=o[1],_i?(Si(),_i&&Ii(!0)):t&&S(`【版本更新】当前版本${wi}已为最新，<a href="https://html.douyuex.com/update/" target="_blank">点击查看更新内容</a>`,"success")}function Bi(){w("https://html.douyuex.com/install/web.html",!0)}function Ii(t){let o=0,n=setInterval(()=>{var e=document.getElementById("ex-update__tip");if(60<++o)return clearInterval(n);e&&(clearInterval(n),t?"block"!=e.style.display&&(e.style.display="block"):e.style.display="none")},1e3)}function Si(){S(`【版本更新】最新版本：${ki}，点击<a href="https://html.douyuex.com/install/web.html" target="_blank">官方源</a>或者<a href="https://greasyfork.org/zh-CN/scripts/394497" target="_blank">GreasyFork源</a>更新，<a href="https://html.douyuex.com/update/" target="_blank">点击查看更新内容</a>`,"error",{timeout:50})}let Ci=0,Ti=null,Ni=null,Mi=null,Li=0,Ai="";function Di(){var e=(()=>{try{var e=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("share-hover").getAttribute("hashid");if(e)return e}catch(e){}return(e=String(window.location.pathname).split("/"))[e.length-1]})();if(e){let t=Ai=e;fetch("https://v.douyu.com/video/video/getVideoUrl?vid="+e,{method:"GET",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"}}).then(e=>e.json()).then(e=>{t===Ai&&(e=v(e.data.viewthumb[0].url,"--","/"),Ci=new Date(e.replace(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/,"$1-$2-$3 $4:$5:$6")).getTime())}).catch(e=>{console.log("请求失败!",e)})}}function ji(){var e=document.getElementsByTagName("demand-video")[0].shadowRoot.getElementById("demandcontroller-bar").shadowRoot.querySelector("demand-video-controller-progress").shadowRoot.querySelector("demand-video-controller-preview").getAttribute("showtime");return Number(e).toFixed(0)}function Pi(e){var t=document.getElementsByTagName("demand-video")[0].shadowRoot.getElementById("demandcontroller-bar").shadowRoot.querySelector("demand-video-controller-progress").shadowRoot.querySelector("demand-video-controller-preview").shadowRoot.querySelector(".Preview label");t&&(t.style.position="relative",t.style.bottom="60px",t.style.backgroundColor="rgba(0,0,0,0.4)",t.innerHTML=e)}function zi(){var e=localStorage.getItem("ExSave_Camera_Hidden");if(e)return e=parseInt(e),Date.now()<e}function Oi(){let o=setInterval(()=>{if(null!=(H=document.getElementsByTagName("demand-video")[0].shadowRoot.getElementById("__video"))&&H.videoWidth){clearInterval(o),Vi=document.getElementsByTagName("demand-video-anchor")[0].shadowRoot.querySelector(".anchor-name").innerText,Hi=.25*H.videoWidth,Gi=.25*H.videoHeight,(Fi=document.createElement("canvas")).width=Hi,Fi.height=Gi,(j=document.createElement("canvas")).width=H.videoWidth,j.height=H.videoHeight;var e=document.createElement("div"),t=(e.id="ex-camera",e.title="单击截图 长按录制gif",e.innerHTML=`
    <svg t="1620266708389" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2080" width="38" height="38"><path d="M512 337.371136c-119.543808 0-216.800256 97.255424-216.800256 216.798208 0 119.543808 97.256448 216.800256 216.800256 216.800256s216.800256-97.256448 216.800256-216.800256C728.800256 434.625536 631.543808 337.371136 512 337.371136zM680.479744 554.16832c0 92.911616-75.579392 168.501248-168.479744 168.501248-92.900352 0-168.480768-75.589632-168.480768-168.501248 0-92.923904 75.579392-168.521728 168.480768-168.521728C604.899328 385.646592 680.479744 461.24544 680.479744 554.16832z" p-id="2081" fill="#ffffff"></path><path d="M831.209472 337.349632l-47.167488 0c-13.647872 0-24.751104 11.083776-24.751104 24.707072 0 13.635584 11.103232 24.7296 24.751104 24.7296l47.167488 0c13.646848 0 24.75008-11.094016 24.75008-24.7296C855.959552 348.433408 844.85632 337.349632 831.209472 337.349632z" p-id="2082" fill="#ffffff"></path><path d="M700.505088 171.497472c4.235264 0 6.403072 0.405504 7.232512 0.612352 1.47968 1.514496 4.790272 6.218752 11.717632 20.685824 2.83648 5.910528 8.6272 18.86208 15.888384 35.533824l11.788288 27.063296 29.518848 0 96.535552 0c35.122176 0 63.695872 28.535808 63.695872 63.609856l0 469.933056c0 35.05152-28.573696 63.567872-63.695872 63.567872L150.811648 852.503552c-35.121152 0-63.694848-28.516352-63.694848-63.567872L87.1168 319.0016c0-35.062784 28.573696-63.589376 63.694848-63.589376l99.35872 0 29.110272 0 11.964416-26.537984c4.698112-10.421248 8.416256-19.063808 11.058176-25.70752 9.86112-24.829952 15.207424-30.125056 16.239616-30.974976 0.52736-0.161792 2.64192-0.695296 7.673856-0.695296L700.505088 171.496448M700.505088 126.441472 326.216704 126.441472c-32.519168 0-47.275008 13.479936-65.787904 60.096512-3.180544 7.999488-7.689216 18.122752-10.257408 23.819264l-99.35872 0c-59.96544 0-108.750848 48.738304-108.750848 108.645376l0 469.933056c0 59.894784 48.785408 108.623872 108.750848 108.623872l722.37568 0c59.96544 0 108.751872-48.729088 108.751872-108.623872L981.940224 319.0016c0-59.91936-48.786432-108.665856-108.751872-108.665856l-96.535552 0c-4.458496-10.236928-12.420096-28.372992-16.574464-37.031936C744.823808 141.448192 733.973504 126.441472 700.505088 126.441472L700.505088 126.441472z" p-id="2083" fill="#ffffff"></path></svg>
    <div id="ex-camera-close">×</div>
    `,document.getElementsByClassName("Video")[0]);t.insertBefore(e,t.childNodes[0]);{let e=document.getElementsByTagName("demand-video")[0],t=document.getElementsByClassName("Video")[0],o=document.getElementById("ex-camera"),n=document.getElementById("ex-camera-close"),i=null,a=0,r=0,l,s=0,d=!1;n.addEventListener("click",e=>{e.stopPropagation(),confirm("是否7天内不再显示？")?localStorage.setItem("ExSave_Camera_Hidden",Date.now()+6048e5):d=!0,o.style.display="none"}),Ri()||(e.addEventListener("mouseenter",()=>{d||Ri()||(o.style.display="flex",s=setTimeout(()=>{o.style.display="none"},2e3))}),e.addEventListener("mousemove",()=>{d||Ri()||(o.style.display="flex",clearTimeout(s),s=setTimeout(()=>{o.style.display="none"},2e3))}),o.addEventListener("mouseenter",()=>{d||Ri()||(o.style.display="flex",clearTimeout(s))}),e.addEventListener("mouseleave",()=>{o.style.display="none",clearTimeout(s)}),t&&t.addEventListener("mouseleave",()=>{o.style.display="none",clearTimeout(s)}),o.addEventListener("mousedown",e=>{if("ex-camera-close"!==e.target.id){if(clearInterval(a),i&&"function"==typeof i.abort)try{i.abort()}catch(e){}i=null,r=(new Date).getTime(),j.width=H.videoWidth,j.height=H.videoHeight,j.getContext("2d").drawImage(H,0,0,j.width,j.height),l=j.toDataURL("image/png"),i=new GIF({workers:5,quality:3,width:Hi,height:Gi,workerScript:qi}),Wi(H,Fi,i,Ui),a=setInterval(()=>{Wi(H,Fi,i,Ui)},Ui)}}),o.addEventListener("mouseup",e=>{if("ex-camera-close"!==e.target.id){e=(new Date).getTime();if(clearInterval(a),800<=e-r)S("【录制】正在生成gif...","info"),i.on("finished",e=>{var t=document.createElement("a");let o=URL.createObjectURL(e);t.href=o,t.download=`【${Vi}】`+_("yyyy-MM-dd hh-mm-ss",new Date),document.body.appendChild(t);e=document.createEvent("MouseEvents");e.initEvent("click",!1,!1),t.dispatchEvent(e),document.body.removeChild(t),setTimeout(function(){try{URL.revokeObjectURL(o)}catch(e){}},1500)}),i.render();else{if(i&&"function"==typeof i.abort)try{i.abort()}catch(e){}i=null;var e=document.createElement("a"),t=(e.download=`【${Vi}】`+_("yyyy-MM-dd hh-mm-ss",new Date),e.href=l,document.body.appendChild(e),document.createEvent("MouseEvents"));t.initEvent("click",!1,!1),e.dispatchEvent(t),document.body.removeChild(e)}}}))}}},1e3)}function Ri(){var e=localStorage.getItem("ExSave_Camera_Hidden");if(e)return e=parseInt(e),Date.now()<e}var Fi,j,Hi,Gi,Vi,o=`(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){var NeuQuant=require("./TypedNeuQuant.js");var LZWEncoder=require("./LZWEncoder.js");function ByteArray(){this.page=-1;this.pages=[];this.newPage()}ByteArray.pageSize=4096;ByteArray.charMap={};for(var i=0;i<256;i++)ByteArray.charMap[i]=String.fromCharCode(i);ByteArray.prototype.newPage=function(){this.pages[++this.page]=new Uint8Array(ByteArray.pageSize);this.cursor=0};ByteArray.prototype.getData=function(){var rv="";for(var p=0;p<this.pages.length;p++){for(var i=0;i<ByteArray.pageSize;i++){rv+=ByteArray.charMap[this.pages[p][i]]}}return rv};ByteArray.prototype.writeByte=function(val){if(this.cursor>=ByteArray.pageSize)this.newPage();this.pages[this.page][this.cursor++]=val};ByteArray.prototype.writeUTFBytes=function(string){for(var l=string.length,i=0;i<l;i++)this.writeByte(string.charCodeAt(i))};ByteArray.prototype.writeBytes=function(array,offset,length){for(var l=length||array.length,i=offset||0;i<l;i++)this.writeByte(array[i])};function GIFEncoder(width,height){this.width=~~width;this.height=~~height;this.transparent=null;this.transIndex=0;this.repeat=-1;this.delay=0;this.image=null;this.pixels=null;this.indexedPixels=null;this.colorDepth=null;this.colorTab=null;this.neuQuant=null;this.usedEntry=new Array;this.palSize=7;this.dispose=-1;this.firstFrame=true;this.sample=10;this.dither=false;this.globalPavarte=false;this.out=new ByteArray}GIFEncoder.prototype.setDelay=function(milliseconds){this.delay=Math.round(milliseconds/10)};GIFEncoder.prototype.setFrameRate=function(fps){this.delay=Math.round(100/fps)};GIFEncoder.prototype.setDispose=function(disposalCode){if(disposalCode>=0)this.dispose=disposalCode};GIFEncoder.prototype.setRepeat=function(repeat){this.repeat=repeat};GIFEncoder.prototype.setTransparent=function(color){this.transparent=color};GIFEncoder.prototype.addFrame=function(imageData){this.image=imageData;this.colorTab=this.globalPavarte&&this.globalPavarte.slice?this.globalPavarte:null;this.getImagePixels();this.analyzePixels();if(this.globalPavarte===true)this.globalPavarte=this.colorTab;if(this.firstFrame){this.writeLSD();this.writePavarte();if(this.repeat>=0){this.writeNetscapeExt()}}this.writeGraphicCtrlExt();this.writeImageDesc();if(!this.firstFrame&&!this.globalPavarte)this.writePavarte();this.writePixels();this.firstFrame=false};GIFEncoder.prototype.finish=function(){this.out.writeByte(59)};GIFEncoder.prototype.setQuality=function(quality){if(quality<1)quality=1;this.sample=quality};GIFEncoder.prototype.setDither=function(dither){if(dither===true)dither="FloydSteinberg";this.dither=dither};GIFEncoder.prototype.setGlobalPavarte=function(pavarte){this.globalPavarte=pavarte};GIFEncoder.prototype.getGlobalPavarte=function(){return this.globalPavarte&&this.globalPavarte.slice&&this.globalPavarte.slice(0)||this.globalPavarte};GIFEncoder.prototype.writeHeader=function(){this.out.writeUTFBytes("GIF89a")};GIFEncoder.prototype.analyzePixels=function(){if(!this.colorTab){this.neuQuant=new NeuQuant(this.pixels,this.sample);this.neuQuant.buildColormap();this.colorTab=this.neuQuant.getColormap()}if(this.dither){this.ditherPixels(this.dither.replace("-serpentine",""),this.dither.match(/-serpentine/)!==null)}else{this.indexPixels()}this.pixels=null;this.colorDepth=8;this.palSize=7;if(this.transparent!==null){this.transIndex=this.findClosest(this.transparent,true)}};GIFEncoder.prototype.indexPixels=function(imgq){var nPix=this.pixels.length/3;this.indexedPixels=new Uint8Array(nPix);var k=0;for(var j=0;j<nPix;j++){var index=this.findClosestRGB(this.pixels[k++]&255,this.pixels[k++]&255,this.pixels[k++]&255);this.usedEntry[index]=true;this.indexedPixels[j]=index}};GIFEncoder.prototype.ditherPixels=function(kernel,serpentine){var kernels={FalseFloydSteinberg:[[3/8,1,0],[3/8,0,1],[2/8,1,1]],FloydSteinberg:[[7/16,1,0],[3/16,-1,1],[5/16,0,1],[1/16,1,1]],Stucki:[[8/42,1,0],[4/42,2,0],[2/42,-2,1],[4/42,-1,1],[8/42,0,1],[4/42,1,1],[2/42,2,1],[1/42,-2,2],[2/42,-1,2],[4/42,0,2],[2/42,1,2],[1/42,2,2]],Atkinson:[[1/8,1,0],[1/8,2,0],[1/8,-1,1],[1/8,0,1],[1/8,1,1],[1/8,0,2]]};if(!kernel||!kernels[kernel]){throw"Unknown dithering kernel: "+kernel}var ds=kernels[kernel];var index=0,height=this.height,width=this.width,data=this.pixels;var direction=serpentine?-1:1;this.indexedPixels=new Uint8Array(this.pixels.length/3);for(var y=0;y<height;y++){if(serpentine)direction=direction*-1;for(var x=direction==1?0:width-1,xend=direction==1?width:0;x!==xend;x+=direction){index=y*width+x;var idx=index*3;var r1=data[idx];var g1=data[idx+1];var b1=data[idx+2];idx=this.findClosestRGB(r1,g1,b1);this.usedEntry[idx]=true;this.indexedPixels[index]=idx;idx*=3;var r2=this.colorTab[idx];var g2=this.colorTab[idx+1];var b2=this.colorTab[idx+2];var er=r1-r2;var eg=g1-g2;var eb=b1-b2;for(var i=direction==1?0:ds.length-1,end=direction==1?ds.length:0;i!==end;i+=direction){var x1=ds[i][1];var y1=ds[i][2];if(x1+x>=0&&x1+x<width&&y1+y>=0&&y1+y<height){var d=ds[i][0];idx=index+x1+y1*width;idx*=3;data[idx]=Math.max(0,Math.min(255,data[idx]+er*d));data[idx+1]=Math.max(0,Math.min(255,data[idx+1]+eg*d));data[idx+2]=Math.max(0,Math.min(255,data[idx+2]+eb*d))}}}}};GIFEncoder.prototype.findClosest=function(c,used){return this.findClosestRGB((c&16711680)>>16,(c&65280)>>8,c&255,used)};GIFEncoder.prototype.findClosestRGB=function(r,g,b,used){if(this.colorTab===null)return-1;if(this.neuQuant&&!used){return this.neuQuant.lookupRGB(r,g,b)}var c=b|g<<8|r<<16;var minpos=0;var dmin=256*256*256;var len=this.colorTab.length;for(var i=0,index=0;i<len;index++){var dr=r-(this.colorTab[i++]&255);var dg=g-(this.colorTab[i++]&255);var db=b-(this.colorTab[i++]&255);var d=dr*dr+dg*dg+db*db;if((!used||this.usedEntry[index])&&d<dmin){dmin=d;minpos=index}}return minpos};GIFEncoder.prototype.getImagePixels=function(){var w=this.width;var h=this.height;this.pixels=new Uint8Array(w*h*3);var data=this.image;var srcPos=0;var count=0;for(var i=0;i<h;i++){for(var j=0;j<w;j++){this.pixels[count++]=data[srcPos++];this.pixels[count++]=data[srcPos++];this.pixels[count++]=data[srcPos++];srcPos++}}};GIFEncoder.prototype.writeGraphicCtrlExt=function(){this.out.writeByte(33);this.out.writeByte(249);this.out.writeByte(4);var transp,disp;if(this.transparent===null){transp=0;disp=0}else{transp=1;disp=2}if(this.dispose>=0){disp=dispose&7}disp<<=2;this.out.writeByte(0|disp|0|transp);this.writeShort(this.delay);this.out.writeByte(this.transIndex);this.out.writeByte(0)};GIFEncoder.prototype.writeImageDesc=function(){this.out.writeByte(44);this.writeShort(0);this.writeShort(0);this.writeShort(this.width);this.writeShort(this.height);if(this.firstFrame||this.globalPavarte){this.out.writeByte(0)}else{this.out.writeByte(128|0|0|0|this.palSize)}};GIFEncoder.prototype.writeLSD=function(){this.writeShort(this.width);this.writeShort(this.height);this.out.writeByte(128|112|0|this.palSize);this.out.writeByte(0);this.out.writeByte(0)};GIFEncoder.prototype.writeNetscapeExt=function(){this.out.writeByte(33);this.out.writeByte(255);this.out.writeByte(11);this.out.writeUTFBytes("NETSCAPE2.0");this.out.writeByte(3);this.out.writeByte(1);this.writeShort(this.repeat);this.out.writeByte(0)};GIFEncoder.prototype.writePavarte=function(){this.out.writeBytes(this.colorTab);var n=3*256-this.colorTab.length;for(var i=0;i<n;i++)this.out.writeByte(0)};GIFEncoder.prototype.writeShort=function(pValue){this.out.writeByte(pValue&255);this.out.writeByte(pValue>>8&255)};GIFEncoder.prototype.writePixels=function(){var enc=new LZWEncoder(this.width,this.height,this.indexedPixels,this.colorDepth);enc.encode(this.out)};GIFEncoder.prototype.stream=function(){return this.out};module.exports=GIFEncoder},{"./LZWEncoder.js":2,"./TypedNeuQuant.js":3}],2:[function(require,module,exports){var EOF=-1;var BITS=12;var HSIZE=5003;var masks=[0,1,3,7,15,31,63,127,255,511,1023,2047,4095,8191,16383,32767,65535];function LZWEncoder(width,height,pixels,colorDepth){var initCodeSize=Math.max(2,colorDepth);var accum=new Uint8Array(256);var htab=new Int32Array(HSIZE);var codetab=new Int32Array(HSIZE);var cur_accum,cur_bits=0;var a_count;var free_ent=0;var maxcode;var clear_flg=false;var g_init_bits,ClearCode,EOFCode;function char_out(c,outs){accum[a_count++]=c;if(a_count>=254)flush_char(outs)}function cl_block(outs){cl_hash(HSIZE);free_ent=ClearCode+2;clear_flg=true;output(ClearCode,outs)}function cl_hash(hsize){for(var i=0;i<hsize;++i)htab[i]=-1}function compress(init_bits,outs){var fcode,c,i,ent,disp,hsize_reg,hshift;g_init_bits=init_bits;clear_flg=false;n_bits=g_init_bits;maxcode=MAXCODE(n_bits);ClearCode=1<<init_bits-1;EOFCode=ClearCode+1;free_ent=ClearCode+2;a_count=0;ent=nextPixel();hshift=0;for(fcode=HSIZE;fcode<65536;fcode*=2)++hshift;hshift=8-hshift;hsize_reg=HSIZE;cl_hash(hsize_reg);output(ClearCode,outs);outer_loop:while((c=nextPixel())!=EOF){fcode=(c<<BITS)+ent;i=c<<hshift^ent;if(htab[i]===fcode){ent=codetab[i];continue}else if(htab[i]>=0){disp=hsize_reg-i;if(i===0)disp=1;do{if((i-=disp)<0)i+=hsize_reg;if(htab[i]===fcode){ent=codetab[i];continue outer_loop}}while(htab[i]>=0)}output(ent,outs);ent=c;if(free_ent<1<<BITS){codetab[i]=free_ent++;htab[i]=fcode}else{cl_block(outs)}}output(ent,outs);output(EOFCode,outs)}function encode(outs){outs.writeByte(initCodeSize);remaining=width*height;curPixel=0;compress(initCodeSize+1,outs);outs.writeByte(0)}function flush_char(outs){if(a_count>0){outs.writeByte(a_count);outs.writeBytes(accum,0,a_count);a_count=0}}function MAXCODE(n_bits){return(1<<n_bits)-1}function nextPixel(){if(remaining===0)return EOF;--remaining;var pix=pixels[curPixel++];return pix&255}function output(code,outs){cur_accum&=masks[cur_bits];if(cur_bits>0)cur_accum|=code<<cur_bits;else cur_accum=code;cur_bits+=n_bits;while(cur_bits>=8){char_out(cur_accum&255,outs);cur_accum>>=8;cur_bits-=8}if(free_ent>maxcode||clear_flg){if(clear_flg){maxcode=MAXCODE(n_bits=g_init_bits);clear_flg=false}else{++n_bits;if(n_bits==BITS)maxcode=1<<BITS;else maxcode=MAXCODE(n_bits)}}if(code==EOFCode){while(cur_bits>0){char_out(cur_accum&255,outs);cur_accum>>=8;cur_bits-=8}flush_char(outs)}}this.encode=encode}module.exports=LZWEncoder},{}],3:[function(require,module,exports){var ncycles=100;var netsize=256;var maxnetpos=netsize-1;var netbiasshift=4;var intbiasshift=16;var intbias=1<<intbiasshift;var gammashift=10;var gamma=1<<gammashift;var betashift=10;var beta=intbias>>betashift;var betagamma=intbias<<gammashift-betashift;var initrad=netsize>>3;var radiusbiasshift=6;var radiusbias=1<<radiusbiasshift;var initradius=initrad*radiusbias;var radiusdec=30;var alphabiasshift=10;var initalpha=1<<alphabiasshift;var alphadec;var radbiasshift=8;var radbias=1<<radbiasshift;var alpharadbshift=alphabiasshift+radbiasshift;var alpharadbias=1<<alpharadbshift;var prime1=499;var prime2=491;var prime3=487;var prime4=503;var minpicturebytes=3*prime4;function NeuQuant(pixels,samplefac){var network;var netindex;var bias;var freq;var radpower;function init(){network=[];netindex=new Int32Array(256);bias=new Int32Array(netsize);freq=new Int32Array(netsize);radpower=new Int32Array(netsize>>3);var i,v;for(i=0;i<netsize;i++){v=(i<<netbiasshift+8)/netsize;network[i]=new Float64Array([v,v,v,0]);freq[i]=intbias/netsize;bias[i]=0}}function unbiasnet(){for(var i=0;i<netsize;i++){network[i][0]>>=netbiasshift;network[i][1]>>=netbiasshift;network[i][2]>>=netbiasshift;network[i][3]=i}}function altersingle(alpha,i,b,g,r){network[i][0]-=alpha*(network[i][0]-b)/initalpha;network[i][1]-=alpha*(network[i][1]-g)/initalpha;network[i][2]-=alpha*(network[i][2]-r)/initalpha}function alterneigh(radius,i,b,g,r){var lo=Math.abs(i-radius);var hi=Math.min(i+radius,netsize);var j=i+1;var k=i-1;var m=1;var p,a;while(j<hi||k>lo){a=radpower[m++];if(j<hi){p=network[j++];p[0]-=a*(p[0]-b)/alpharadbias;p[1]-=a*(p[1]-g)/alpharadbias;p[2]-=a*(p[2]-r)/alpharadbias}if(k>lo){p=network[k--];p[0]-=a*(p[0]-b)/alpharadbias;p[1]-=a*(p[1]-g)/alpharadbias;p[2]-=a*(p[2]-r)/alpharadbias}}}function contest(b,g,r){var bestd=~(1<<31);var bestbiasd=bestd;var bestpos=-1;var bestbiaspos=bestpos;var i,n,dist,biasdist,betafreq;for(i=0;i<netsize;i++){n=network[i];dist=Math.abs(n[0]-b)+Math.abs(n[1]-g)+Math.abs(n[2]-r);if(dist<bestd){bestd=dist;bestpos=i}biasdist=dist-(bias[i]>>intbiasshift-netbiasshift);if(biasdist<bestbiasd){bestbiasd=biasdist;bestbiaspos=i}betafreq=freq[i]>>betashift;freq[i]-=betafreq;bias[i]+=betafreq<<gammashift}freq[bestpos]+=beta;bias[bestpos]-=betagamma;return bestbiaspos}function inxbuild(){var i,j,p,q,smallpos,smallval,previouscol=0,startpos=0;for(i=0;i<netsize;i++){p=network[i];smallpos=i;smallval=p[1];for(j=i+1;j<netsize;j++){q=network[j];if(q[1]<smallval){smallpos=j;smallval=q[1]}}q=network[smallpos];if(i!=smallpos){j=q[0];q[0]=p[0];p[0]=j;j=q[1];q[1]=p[1];p[1]=j;j=q[2];q[2]=p[2];p[2]=j;j=q[3];q[3]=p[3];p[3]=j}if(smallval!=previouscol){netindex[previouscol]=startpos+i>>1;for(j=previouscol+1;j<smallval;j++)netindex[j]=i;previouscol=smallval;startpos=i}}netindex[previouscol]=startpos+maxnetpos>>1;for(j=previouscol+1;j<256;j++)netindex[j]=maxnetpos}function inxsearch(b,g,r){var a,p,dist;var bestd=1e3;var best=-1;var i=netindex[g];var j=i-1;while(i<netsize||j>=0){if(i<netsize){p=network[i];dist=p[1]-g;if(dist>=bestd)i=netsize;else{i++;if(dist<0)dist=-dist;a=p[0]-b;if(a<0)a=-a;dist+=a;if(dist<bestd){a=p[2]-r;if(a<0)a=-a;dist+=a;if(dist<bestd){bestd=dist;best=p[3]}}}}if(j>=0){p=network[j];dist=g-p[1];if(dist>=bestd)j=-1;else{j--;if(dist<0)dist=-dist;a=p[0]-b;if(a<0)a=-a;dist+=a;if(dist<bestd){a=p[2]-r;if(a<0)a=-a;dist+=a;if(dist<bestd){bestd=dist;best=p[3]}}}}}return best}function learn(){var i;var lengthcount=pixels.length;var alphadec=30+(samplefac-1)/3;var samplepixels=lengthcount/(3*samplefac);var delta=~~(samplepixels/ncycles);var alpha=initalpha;var radius=initradius;var rad=radius>>radiusbiasshift;if(rad<=1)rad=0;for(i=0;i<rad;i++)radpower[i]=alpha*((rad*rad-i*i)*radbias/(rad*rad));var step;if(lengthcount<minpicturebytes){samplefac=1;step=3}else if(lengthcount%prime1!==0){step=3*prime1}else if(lengthcount%prime2!==0){step=3*prime2}else if(lengthcount%prime3!==0){step=3*prime3}else{step=3*prime4}var b,g,r,j;var pix=0;i=0;while(i<samplepixels){b=(pixels[pix]&255)<<netbiasshift;g=(pixels[pix+1]&255)<<netbiasshift;r=(pixels[pix+2]&255)<<netbiasshift;j=contest(b,g,r);altersingle(alpha,j,b,g,r);if(rad!==0)alterneigh(rad,j,b,g,r);pix+=step;if(pix>=lengthcount)pix-=lengthcount;i++;if(delta===0)delta=1;if(i%delta===0){alpha-=alpha/alphadec;radius-=radius/radiusdec;rad=radius>>radiusbiasshift;if(rad<=1)rad=0;for(j=0;j<rad;j++)radpower[j]=alpha*((rad*rad-j*j)*radbias/(rad*rad))}}}function buildColormap(){init();learn();unbiasnet();inxbuild()}this.buildColormap=buildColormap;function getColormap(){var map=[];var index=[];for(var i=0;i<netsize;i++)index[network[i][3]]=i;var k=0;for(var l=0;l<netsize;l++){var j=index[l];map[k++]=network[j][0];map[k++]=network[j][1];map[k++]=network[j][2]}return map}this.getColormap=getColormap;this.lookupRGB=inxsearch}module.exports=NeuQuant},{}],4:[function(require,module,exports){var GIFEncoder,renderFrame;GIFEncoder=require("./GIFEncoder.js");renderFrame=function(frame){var encoder,page,stream,transfer;encoder=new GIFEncoder(frame.width,frame.height);if(frame.index===0){encoder.writeHeader()}else{encoder.firstFrame=false}encoder.setTransparent(frame.transparent);encoder.setRepeat(frame.repeat);encoder.setDelay(frame.delay);encoder.setQuality(frame.quality);encoder.setDither(frame.dither);encoder.setGlobalPavarte(frame.globalPavarte);encoder.addFrame(frame.data);if(frame.last){encoder.finish()}if(frame.globalPavarte===true){frame.globalPavarte=encoder.getGlobalPavarte()}stream=encoder.stream();frame.data=stream.pages;frame.cursor=stream.cursor;frame.pageSize=stream.constructor.pageSize;if(frame.canTransfer){transfer=function(){var i,len,ref,results;ref=frame.data;results=[];for(i=0,len=ref.length;i<len;i++){page=ref[i];results.push(page.buffer)}return results}();return self.postMessage(frame,transfer)}else{return self.postMessage(frame)}};self.onmessage=function(event){return renderFrame(event.data)}},{"./GIFEncoder.js":1}]},{},[4]);`,qi=URL.createObjectURL(new Blob([o],{type:"application/javascript"}));let Ui=83;function Wi(e,t,o,n){t.getContext("2d").drawImage(e,0,0,t.width,t.height),o.addFrame(t,{copy:!0,delay:n})}function Yi(e){var t=String(parseInt(H.style.width)/2.39)+"px",e=(V("Ex_Style_Cinema"),`
    .layout-Player-videoEntity video{object-fit:${e} !important;height:${t} !important;}
    `);_l("Ex_Style_Cinema",e)}let Qi='<img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjJweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMjIgMjAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+am95c291bmQvc2VsZWN0ZWQ8L3RpdGxlPgogICAgPGRlZnM+CiAgICAgICAgPGxpbmVhckdyYWRpZW50IHgxPSI1MCUiIHkxPSIwJSIgeDI9IjUwJSIgeTI9IjEwMCUiIGlkPSJsaW5lYXJHcmFkaWVudC0xIj4KICAgICAgICAgICAgPHN0b3Agc3RvcC1jb2xvcj0iI0YwQ0I5NSIgb2Zmc2V0PSIwJSI+PC9zdG9wPgogICAgICAgICAgICA8c3RvcCBzdG9wLWNvbG9yPSIjRTlCRTgwIiBvZmZzZXQ9IjEwMCUiPjwvc3RvcD4KICAgICAgICA8L2xpbmVhckdyYWRpZW50PgogICAgPC9kZWZzPgogICAgPGcgaWQ9ImpveXNvdW5kL3NlbGVjdGVkIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0i57yW57uEIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyLjc4NTc1MCwgMC43MTQyMjUpIiBmaWxsPSJ1cmwoI2xpbmVhckdyYWRpZW50LTEpIiBmaWxsLXJ1bGU9Im5vbnplcm8iPgogICAgICAgICAgICA8cGF0aCBkPSJNMTYuNDI4NiwwIEwxNi40Mjg2LDkuNjQzIEMxNi40Mjg2LDE0LjEzNDU1MjcgMTIuODIzMzY2NywxNy43ODQyODggOC4zNDg5MzYxOCwxNy44NTYxNjk2IEw4LjE4NzE4MTUzLDE3Ljg1NzI1NjEgTDguMTg3MTgxNTMsMTcuODU3MjU2MSBMNy44NTcxLDE3Ljg1NzI1NjEgTDcuODU3MTM4OTYsMTcuODQ5NjQxIEMzLjQ5MjM4MDEzLDE3LjY2MjA3NDQgMCwxNC4wNTMxMzQxIDAsOS42NDMwNSBDMCw1LjExMzExNTA1IDMuNjg0NDAwMiwxLjQyODU1IDguMjE0MjUsMS40Mjg1NSBDOS43MDA3OTkxMywxLjQyODU1IDExLjA5NjI5ODUsMS44MjUzNTUwMiAxMi4zMDA0MTUxLDIuNTE4NjIzMzEgQzEyLjc0OTU2ODcsMS4wNjAxNjYwMSAxNC4xMDgyMjM2LDAgMTUuNzE0MzUsMCBMMTYuNDI4NiwwIFogTTguMjE0MjUsMi40Mjg1NSBDNC4yMzY2OTQ5NiwyLjQyODU1IDEsNS42NjUzODk3OCAxLDkuNjQzMDUgQzEsMTMuNTAwNzUwOCA0LjA0NDc3MzgsMTYuNjYxNzMzMyA3Ljg1NzA4ODk5LDE2Ljg0ODU2NjggTDcuODU3MDYyNTQsMTQuNTc1MDE3IEM2Ljc3Mjk4NjcxLDE0LjQ5NzMxMDMgNS43ODQ2MTcxOSwxNC4wNjg3NDc3IDUuMDA1MTgzMTEsMTMuNDAyNTU3OCBMNC45MjI0NzY5NywxMy4zMzAyNzYyIEw0LjgwNDkyNDY4LDEzLjIyMTc5NDEgQzMuODU5Mjk3NTksMTIuMzIwNjI4MyAzLjI2OTI1LDExLjA0OTU0OTYgMy4yNjkyNSw5LjY0MzAyNSBDMy4yNjkyNSw2LjkxNTg4MjYzIDUuNDg3MTA3NjMsNC42OTgwMjUgOC4yMTQyNSw0LjY5ODAyNSBDOS44MTQwMDc1Niw0LjY5ODAyNSAxMS4yMzg0NTI3LDUuNDYxMjEyMzMgMTIuMTQyNzY0NSw2LjY0MjcxMjE1IEwxMi4xNDI3NjQ1LDMuNTk0NjQ0OTEgQzExLjAxMTU4OTYsMi44NTczNjc2NSA5LjY2MTk5NDQ5LDIuNDI4NTUgOC4yMTQyNSwyLjQyODU1IFogTTguMjE0MjUsNS42OTgwMjUgQzYuMDM5MzkyMzcsNS42OTgwMjUgNC4yNjkyNSw3LjQ2ODE2NzM3IDQuMjY5MjUsOS42NDMwMjUgQzQuMjY5MjUsMTEuNjY5NTM3MyA1LjgwNjQ4MjY0LDEzLjM0NDc0OTggNy43NzU4ODgxNSwxMy41NjM1NjcyIEw3Ljg1NzEsMTMuNTcxNSBMOC4yMTQzNSwxMy41NzE1IEMxMC4zNDk2LDEzLjU3MTUgMTIuMDg2ODUsMTEuODY4IDEyLjE0MTYsOS43NDYgTDEyLjE0MjY0NjgsOS42NDMgTDEyLjE0MjY0NjgsOS4yODIzMzIzMyBDMTEuOTU5ODU4NSw3LjI3NTc1MDI2IDEwLjI2NzQ4MjMsNS42OTgwMjUgOC4yMTQyNSw1LjY5ODAyNSBaIE04LjIxNDI1LDcuNTAwMDI1IEM5LjM5NjE5Mjg0LDcuNTAwMDI1IDEwLjM1Nyw4LjQ2MDkzMzA5IDEwLjM1Nyw5LjY0MzAyNSBDMTAuMzU3LDEwLjgyNDkxNzQgOS4zOTYxNDIzNywxMS43ODU3NzUgOC4yMTQyNSwxMS43ODU3NzUgQzcuMDMyMTgyMTUsMTEuNzg1Nzc1IDYuMDcxNSwxMC44MjQ5OTE5IDYuMDcxNSw5LjY0MzAyNSBDNi4wNzE1LDguNDYwODU4NTUgNy4wMzIxMzE2OSw3LjUwMDAyNSA4LjIxNDI1LDcuNTAwMDI1IFogTTguMjE0MjUsOC41MDAwMjUgQzcuNTg0NDYzNDgsOC41MDAwMjUgNy4wNzE1LDkuMDEzMDk2MjcgNy4wNzE1LDkuNjQzMDI1IEM3LjA3MTUsMTAuMjcyNzMwNyA3LjU4NDQ5MDQyLDEwLjc4NTc3NSA4LjIxNDI1LDEwLjc4NTc3NSBDOC44NDM4NTc2MywxMC43ODU3NzUgOS4zNTcsMTAuMjcyNjMyNiA5LjM1Nyw5LjY0MzAyNSBDOS4zNTcsOS4wMTMxOTQzMyA4Ljg0Mzg4NDU3LDguNTAwMDI1IDguMjE0MjUsOC41MDAwMjUgWiIgaWQ9IuW9oueKtiI+PC9wYXRoPgogICAgICAgIDwvZz4KICAgIDwvZz4KPC9zdmc+" alt="joysound-on"/>',Ji='<img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjJweCIgaGVpZ2h0PSIyMHB4IiB2aWV3Qm94PSIwIDAgMjIgMjAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+am95c291bmQvbm9ybWFsPC90aXRsZT4KICAgIDxnIGlkPSJqb3lzb3VuZC9ub3JtYWwiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxnIGlkPSLnvJbnu4QiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDIuNzg1NzUwLCAwLjcxNDIyNSkiIGZpbGw9IiNGRkZGRkYiIGZpbGwtcnVsZT0ibm9uemVybyI+CiAgICAgICAgICAgIDxwYXRoIGQ9Ik0xNi40Mjg2LDAgTDE2LjQyODYsOS42NDMgQzE2LjQyODYsMTQuMTM0NTUyNyAxMi44MjMzNjY3LDE3Ljc4NDI4OCA4LjM0ODkzNjE4LDE3Ljg1NjE2OTYgTDguMTg3MTgxNTMsMTcuODU3MjU2MSBMOC4xODcxODE1MywxNy44NTcyNTYxIEw3Ljg1NzEsMTcuODU3MjU2MSBMNy44NTcxMzg5NiwxNy44NDk2NDEgQzMuNDkyMzgwMTMsMTcuNjYyMDc0NCAwLDE0LjA1MzEzNDEgMCw5LjY0MzA1IEMwLDUuMTEzMTE1MDUgMy42ODQ0MDAyLDEuNDI4NTUgOC4yMTQyNSwxLjQyODU1IEM5LjcwMDc5OTEzLDEuNDI4NTUgMTEuMDk2Mjk4NSwxLjgyNTM1NTAyIDEyLjMwMDQxNTEsMi41MTg2MjMzMSBDMTIuNzQ5NTY4NywxLjA2MDE2NjAxIDE0LjEwODIyMzYsMCAxNS43MTQzNSwwIEwxNi40Mjg2LDAgWiBNOC4yMTQyNSwyLjQyODU1IEM0LjIzNjY5NDk2LDIuNDI4NTUgMSw1LjY2NTM4OTc4IDEsOS42NDMwNSBDMSwxMy41MDA3NTA4IDQuMDQ0NzczOCwxNi42NjE3MzMzIDcuODU3MDg4OTksMTYuODQ4NTY2OCBMNy44NTcwNjI1NCwxNC41NzUwMTcgQzYuNzcyOTg2NzEsMTQuNDk3MzEwMyA1Ljc4NDYxNzE5LDE0LjA2ODc0NzcgNS4wMDUxODMxMSwxMy40MDI1NTc4IEw0LjkyMjQ3Njk3LDEzLjMzMDI3NjIgTDQuODA0OTI0NjgsMTMuMjIxNzk0MSBDMy44NTkyOTc1OSwxMi4zMjA2MjgzIDMuMjY5MjUsMTEuMDQ5NTQ5NiAzLjI2OTI1LDkuNjQzMDI1IEMzLjI2OTI1LDYuOTE1ODgyNjMgNS40ODcxMDc2Myw0LjY5ODAyNSA4LjIxNDI1LDQuNjk4MDI1IEM5LjgxNDAwNzU2LDQuNjk4MDI1IDExLjIzODQ1MjcsNS40NjEyMTIzMyAxMi4xNDI3NjQ1LDYuNjQyNzEyMTUgTDEyLjE0Mjc2NDUsMy41OTQ2NDQ5MSBDMTEuMDExNTg5NiwyLjg1NzM2NzY1IDkuNjYxOTk0NDksMi40Mjg1NSA4LjIxNDI1LDIuNDI4NTUgWiBNOC4yMTQyNSw1LjY5ODAyNSBDNi4wMzkzOTIzNyw1LjY5ODAyNSA0LjI2OTI1LDcuNDY4MTY3MzcgNC4yNjkyNSw5LjY0MzAyNSBDNC4yNjkyNSwxMS42Njk1MzczIDUuODA2NDgyNjQsMTMuMzQ0NzQ5OCA3Ljc3NTg4ODE1LDEzLjU2MzU2NzIgTDcuODU3MSwxMy41NzE1IEw4LjIxNDM1LDEzLjU3MTUgQzEwLjM0OTYsMTMuNTcxNSAxMi4wODY4NSwxMS44NjggMTIuMTQxNiw5Ljc0NiBMMTIuMTQyNjQ2OCw5LjY0MyBMMTIuMTQyNjQ2OCw5LjI4MjMzMjMzIEMxMS45NTk4NTg1LDcuMjc1NzUwMjYgMTAuMjY3NDgyMyw1LjY5ODAyNSA4LjIxNDI1LDUuNjk4MDI1IFogTTguMjE0MjUsNy41MDAwMjUgQzkuMzk2MTkyODQsNy41MDAwMjUgMTAuMzU3LDguNDYwOTMzMDkgMTAuMzU3LDkuNjQzMDI1IEMxMC4zNTcsMTAuODI0OTE3NCA5LjM5NjE0MjM3LDExLjc4NTc3NSA4LjIxNDI1LDExLjc4NTc3NSBDNy4wMzIxODIxNSwxMS43ODU3NzUgNi4wNzE1LDEwLjgyNDk5MTkgNi4wNzE1LDkuNjQzMDI1IEM2LjA3MTUsOC40NjA4NTg1NSA3LjAzMjEzMTY5LDcuNTAwMDI1IDguMjE0MjUsNy41MDAwMjUgWiBNOC4yMTQyNSw4LjUwMDAyNSBDNy41ODQ0NjM0OCw4LjUwMDAyNSA3LjA3MTUsOS4wMTMwOTYyNyA3LjA3MTUsOS42NDMwMjUgQzcuMDcxNSwxMC4yNzI3MzA3IDcuNTg0NDkwNDIsMTAuNzg1Nzc1IDguMjE0MjUsMTAuNzg1Nzc1IEM4Ljg0Mzg1NzYzLDEwLjc4NTc3NSA5LjM1NywxMC4yNzI2MzI2IDkuMzU3LDkuNjQzMDI1IEM5LjM1Nyw5LjAxMzE5NDMzIDguODQzODg0NTcsOC41MDAwMjUgOC4yMTQyNSw4LjUwMDAyNSBaIiBpZD0i5b2i54q2Ij48L3BhdGg+CiAgICAgICAgPC9nPgogICAgPC9nPgo8L3N2Zz4=" alt="joysound-off"/>';function Zi(){var e=document.getElementById("vtoolbar-joysound-switch"),t=document.getElementById("vtoolbar-joysound-icon");e&&(unsafeWindow.hasInstalledJoysound&&1==localStorage.getItem("Ex_isJoysound")?(e.classList.add("is-on"),t&&(t.innerHTML=Qi)):(e.classList.remove("is-on"),t&&(t.innerHTML=Ji)))}let P=null;let Xi='<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAB2klEQVR4AcyUgXHCMAxF7S7SsglsApMAk0AngU1gE/qeiRxMgFC43jXnH8mK9b9sJflIf3z9P4HT6fQFpoGxA3h6BxBKvIHwAHYB4gewZH5zPCUAwZxsibW46ZhS2qfz9YURmOEYFYB8SpqVY5Kkk5zzJPWXYt/9tPVGBVge5Nuc8yznfETUI1JY8gWxPTGPcIdtjuuhAIvnCMT21/gxJNev5Ew8QuPmMD2PhwIs+QSOFVVabUJUEmNHYqVyJpJjynAnsSaNCUT1JbO7KSQkklj4yP4I/YoxAYnqYh2qNjbD10YBpT/EYo57HmMCkRC2ZF2ITPAdC47ONSIRqDu5K0CCzRKSDl5DSOyBu/C5qG+bk8BNgY48EsqbEgnXlrX2wlczGtsUMxAgwaovybdB6jOwBBugldgmr7o1fif1eIw1AiRZxV1yEnwmmUVoBeHkUQ3IE1cjwNwvFJM8lqZygpJjkqQ+E/qutdlN5am7qkBXvWGbZ7K+H5bVBrlkaxqsFfp1bUm4ulUB4m4T0w9Er8kfkvWZvVcFqEoBt+lb4T/e5l1W/mtyZaqAE7AARQTrR6OoR/ESORztv8hdAH8D/u99K2zey+QDAQMCERvtTpy+hesjeovsVvIPAAAA//+5v3LIAAAABklEQVQDAFMMzjFiZ8i8AAAAAElFTkSuQmCC"/>',Ki='<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAs0lEQVR4AeyU3Q2AIAyE1UkcRTfTyXQTR8GW5MgFCCQFXwxELD/HfaRpWKaP248AzrnL9WsPMs8p2rDYIa7wYIBfmxubN6FfAqC9LsMBqKaxmCJULVxqc+g4FgEstI6LAFQszGtz6DgWASy0jgegmrkkRVKKq3TzyxoTE4AI9KltfVlv8fFfDqAbN0rSGHc10Z4DHGIaBCpq6TFgF/OzxTA+ywA1D7mLhdZ5AMjNu5vrpV4AAAD//9kfWOoAAAAGSURBVAMAe2CtMQj8RU0AAAAASUVORK5CYII="/>',$i=null,z={fontSize:18,speed:2.5,area:"full",trackHeight:28,mergeMode:"combo",lowPowerMode:!1,filterRobotDanmaku:!0,opacity:1,danmakuVisible:!0},ea=null,ta=null,oa=null,na=null,r=null,ia=null,aa=null,ra=null,la=null,sa=null,da=null,ca=null,pa=!1,ma='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="5" width="18" height="12" rx="2" stroke="currentColor" stroke-width="1.5"/><rect x="13" y="13" width="7" height="5" rx="1" stroke="currentColor" stroke-width="1.5"/></svg>',ua='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="5" width="18" height="12" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M7 10h5.5M7 13h3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',ga='<svg width="24" height="24" viewBox="0 0 1024 1024" fill="none" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path fill="#fff" d="M513.34 831.74C337.03 831.74 193.6 688.31 193.6 512c0-71.09 23.31-138.85 65.53-194.03v51.61c0 17.67 14.33 32 32 32s32-14.33 32-32V239.45c0-5.87-1.59-11.36-4.34-16.09-0.06-0.1-0.11-0.2-0.17-0.3-0.16-0.28-0.34-0.55-0.51-0.82-0.13-0.2-0.26-0.41-0.39-0.61-0.08-0.13-0.17-0.25-0.26-0.37a35.5 35.5 0 0 0-1.58-2.13c-6.81-8.35-16.96-12.35-26.95-11.69h-130c-17.67 0-32 14.33-32 32s14.33 32 32 32h55.35C159.8 339 129.6 423.35 129.6 512c0 51.79 10.15 102.05 30.17 149.38 19.33 45.7 46.99 86.74 82.23 121.97 35.23 35.23 76.27 62.9 121.97 82.23 47.33 20.02 97.59 30.17 149.38 30.17 17.67 0 32-14.33 32-32s-14.34-32.01-32.01-32.01zM855.38 762.3h-51.23c19.81-23 36.93-48.3 50.75-75.22 27.6-53.74 42.18-114.28 42.18-175.08 0-51.79-10.15-102.05-30.17-149.38-19.33-45.7-46.99-86.73-82.23-121.97-35.23-35.23-76.27-62.9-121.97-82.23-47.33-20.02-97.59-30.17-149.38-30.17-17.67 0-32 14.33-32 32s14.33 32 32 32c176.31 0 319.74 143.44 319.74 319.74 0 78.31-27.68 151.61-77.6 209.05l0.24-56.04c0.08-17.67-14.19-32.06-31.86-32.14h-0.14c-17.61 0-31.92 14.24-32 31.86l-0.55 129.43a31.988 31.988 0 0 0 9.32 22.71 31.68 31.68 0 0 0 5.33 4.3c0.02 0.01 0.04 0.02 0.06 0.04 0.48 0.31 0.97 0.61 1.47 0.89l0.15 0.09c0.5 0.28 1 0.54 1.51 0.8 0.03 0.01 0.05 0.03 0.08 0.04 1.64 0.8 3.34 1.46 5.1 1.98 0.01 0 0.02 0.01 0.03 0.01 0.55 0.16 1.1 0.3 1.66 0.43 0.07 0.02 0.15 0.03 0.22 0.05 0.5 0.11 1 0.21 1.5 0.3 0.1 0.02 0.2 0.04 0.3 0.05 0.48 0.08 0.96 0.15 1.44 0.21 0.11 0.01 0.23 0.03 0.34 0.04 0.48 0.05 0.95 0.09 1.43 0.12l0.34 0.03c0.53 0.03 1.07 0.04 1.61 0.05h132.31c17.67 0 32-14.33 32-32s-14.31-31.99-31.98-31.99z"/></svg>';function ha(e){e=e||window.__pip_window__;if(e&&!e.closed){var t=e.document.getElementById("danmaku"),e=e.document.getElementById("combo-container"),o=null==(o=z.opacity)||Number.isNaN(o)?1:Math.min(1,Math.max(.3,o)),n=!1!==z.danmakuVisible;if(t&&(t.style.opacity=String(o),t.style.visibility=n?"visible":"hidden",!n))for(;t.firstChild;)t.removeChild(t.firstChild);e&&(e.style.opacity=String(o),e.style.display=n?"":"none",n||(e.textContent=""))}}function fa(e){var t,e=(e||window.__pip_window__)?.document.getElementById("pip-danmaku-toggle");e&&(t=!1!==z.danmakuVisible,e.textContent="弹",e.title=t?"隐藏弹幕":"显示弹幕",e.classList.toggle("is-off",!t))}function ya(e,t){if(window.__pip_is_active__){window.__pip_is_active__=!1,window.__pip_window__=null,e?.__pip_keydown_handler__&&(e.document.removeEventListener("keydown",e.__pip_keydown_handler__),e.__pip_keydown_handler__=null),ka(),Ya(!1),Wa(!1),Qa(),or(),window.__pip_track_state__=[],Za&&(clearInterval(Za),Za=null),Ja.clear();try{t&&(t.srcObject=null)}catch(e){}if(e&&!e.closed)try{e.close()}catch(e){}}}function ba(e,t=!0){var o,e=e||window.__pip_window__,n=e?.__pip_source_video__||document.getElementById("__video2");t&&window.__pip_is_active__&&(o=e?.document?.getElementById("pip-video"),ya(e,o));try{window.focus()}catch(e){}if(n){try{n.scrollIntoView({block:"nearest",behavior:"smooth"})}catch(e){}!t&&window.__pip_is_active__?xa(n).catch(()=>{}):t&&n.play().catch(()=>{})}}function va(){var e=ra;if(null!=la&&e&&"function"==typeof e.cancelVideoFrameCallback)try{e.cancelVideoFrameCallback(la)}catch(e){}else null!=la&&clearTimeout(la);la=null,ra=null}async function xa(n){if(!n)return!1;var e=n.paused,t=(await n.play().catch(()=>{}),"0.01"===n.style.getPropertyValue("opacity"));t&&n.style.removeProperty("opacity");try{window.focus()}catch(e){}await new Promise(e=>{let t=!1,o=()=>{t||(t=!0,e())};"function"==typeof n.requestVideoFrameCallback&&n.requestVideoFrameCallback(()=>{n.requestVideoFrameCallback(o)}),setTimeout(o,150)});try{2<=n.readyState&&sa&&sa.getContext("2d",{willReadFrequently:!0}).drawImage(n,0,0,2,2)}catch(e){}return t&&n.style.setProperty("opacity","0.01","important"),e&&n.pause(),!0}async function wa(e,t){var o=e?.__pip_source_video__||document.getElementById("__video2");if(!o||!t)return!1;await xa(o);try{var n=t.srcObject;n&&n.getTracks().forEach(e=>e.stop())}catch(e){}let i=null;try{i=o.captureStream()}catch(e){return!1}t.srcObject=i,o.paused?t.pause():await t.play().catch(()=>{});try{e&&!e.closed&&e.focus()}catch(e){}return!0}function _a(e,t,o){if(Ft()){var n=e;if(va(),n&&window.__pip_is_active__){ra=n,sa||((sa=document.createElement("canvas")).width=2,sa.height=2);let e=sa.getContext("2d",{willReadFrequently:!0}),t=()=>{if(window.__pip_is_active__&&ra===n){try{2<=n.readyState&&e.drawImage(n,0,0,2,2)}catch(e){}la="function"==typeof n.requestVideoFrameCallback?n.requestVideoFrameCallback(t):setTimeout(t,200)}};t()}var i=t,a=o,r=(da&&(document.removeEventListener("visibilitychange",da),da=null),da=()=>{window.__pip_is_active__&&"visible"===document.visibilityState&&wa(i,a)},document.addEventListener("visibilitychange",da),e),l=t,s=o;if(ca&&(clearTimeout(ca),ca=null),"function"==typeof r.requestVideoFrameCallback){let e=performance.now(),t=!1,o=()=>{window.__pip_is_active__&&(e=performance.now(),r.requestVideoFrameCallback(o))},n=(r.requestVideoFrameCallback(o),()=>{window.__pip_is_active__&&(ca=setTimeout(n,2500),t||r.paused||r.readyState<2||performance.now()-e<4500||(t=!0,wa(l,s).finally(()=>{e=performance.now(),t=!1})))});ca=setTimeout(n,2500)}}}function ka(){va(),da&&(document.removeEventListener("visibilitychange",da),da=null),ca&&(clearTimeout(ca),ca=null)}function Ea(e){var t,e=e||window.__pip_window__;e&&!e.closed&&(t=e.document.getElementById("input-panel"),e=e.document.getElementById("pip-input-field"),t)&&e&&(t.classList.add("active"),e.focus())}function Ba(){ea&&(ea.closeHook(),ea=null),document.getElementById("js-player-controlbar")&&(ea=new G("#js-player-controlbar",!0,La))}function Ia(){var e=document.getElementById("js-player-controlbar");return r&&r.isConnected&&e&&e.contains(r)}function Sa(){ta&&("function"==typeof ta.closeHook?ta.closeHook():ta.disconnect?.(),ta=null),null!=na&&(cancelAnimationFrame(na),na=null)}function Ca(){ta||Ia()||(ta=new G("body",!0,t=>{if(Ia())Sa();else{let e=!1;for(var o of t){for(var n of o.addedNodes){if(Ta(n)){e=!0,Va(n);break}if(1===n.nodeType){for(var i of n.children)if(Ta(i)){e=!0,Va(i);break}if(e)break}}if(e)break}e&&Na()}}))}function Ta(e){return 1===e?.nodeType&&e.classList?.contains("mantine-Tooltip-tooltip")&&"开启画中画"===(e.textContent||"").trim()}function Na(){Ia()||null==na&&(na=requestAnimationFrame(()=>{na=null,Ia()||(Da(),ja())}))}function Ma(){Ia()||null==oa&&(oa=requestAnimationFrame(()=>{oa=null,(Ia()||(r&&!r.isConnected&&(r=null),Da(),Ia()))&&Sa()}))}function La(e){Ia()||(Ba(),r&&!r.isConnected&&(r=null),e&&!(e=>{for(var t of e)if("childList"===t.type){for(var o of t.addedNodes)if((e=>{if(1===e.nodeType){if(e.matches?.("button, [role='button']"))if((e.getAttribute("aria-label")||e.title||"").trim().includes("画中画"))return 1;return e.querySelector?.("button[aria-label*='画中画'], [role='button'][aria-label*='画中画']")}})(o))return 1;for(let e of t.removedNodes){if(e===r)return 1;if(1===e.nodeType&&r&&e.contains(r))return 1}}else if("attributes"===t.type){var n=t.target;if(n===r)return 1;if(1===n.nodeType&&("aria-label"===t.attributeName||"title"===t.attributeName||"aria-describedby"===t.attributeName))if((n.getAttribute("aria-label")||n.title||"").trim().includes("画中画"))return 1}})(e))||(Ca(),Ma())}function Aa(){var e,t=document.getElementById("js-player-controlbar");if(t)for(e of t.querySelectorAll("button, [role='button']"))if((e.getAttribute("aria-label")||e.title||"").trim().includes("画中画"))return e;return null}function Da(){let e=Aa();(e=e||(()=>{var e;for(e of document.querySelectorAll(".mantine-Tooltip-tooltip"))if("开启画中画"===(e.textContent||"").trim()&&e.id){var t=document.querySelector(`[aria-describedby="${e.id}"]`);if(t)return t}return null})())&&"1"!==e.dataset.exPipBound&&(e.dataset.exPipBound="1",(r=e).addEventListener("mouseenter",za),e.addEventListener("mouseleave",Ga),e.addEventListener("focus",za),e.addEventListener("blur",Ga),qa(e),Sa(),ja())}function ja(){var e=r;e&&e.matches(":hover")&&(qa(aa=e),Ra(e))}function Pa(){var e;document.getElementById("ex-pip-menu-panel")||((e=document.createElement("div")).id="ex-pip-menu-panel",e.className="ex-pip-menu-root",e.setAttribute("role","menu"),e.innerHTML=`
        <div class="ex-pip-menu">
            <ul class="ex-pip-menu__list" role="presentation">
                <li>
                    <button type="button" class="ex-pip-opt" data-ex-pip-mode="native">
                        <span class="ex-pip-opt__icon">${ma}</span>
                        <span class="ex-pip-opt__label">原版画中画</span>
                    </button>
                </li>
                <li>
                    <button type="button" class="ex-pip-opt ex-pip-opt--ex" data-ex-pip-mode="enhanced">
                        <span class="ex-pip-opt__icon">${ua}</span>
                        <span class="ex-pip-opt__body">
                            <span class="ex-pip-opt__row">
                                <span class="ex-pip-opt__label">增强版画中画</span>
                                <span class="ex-pip-opt__mark">DouyuEx</span>
                            </span>
                            <span class="ex-pip-opt__hint">带弹幕，可窗口发弹幕</span>
                        </span>
                    </button>
                </li>
            </ul>
        </div>
    `,document.body.appendChild(e),e.addEventListener("mouseenter",Ha),e.addEventListener("mouseleave",Ga),e.querySelector('[data-ex-pip-mode="native"]').addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),Fa(),(e=r||Aa())?e.click():(e=document.getElementById("__video2")||document.querySelector(".layout-Player-videoEntity video"))&&"function"==typeof e.requestPictureInPicture?e.requestPictureInPicture().catch(()=>{S("【画中画】无法开启原版画中画","error")}):S("【画中画】未找到原版画中画按钮","error")}),e.querySelector('[data-ex-pip-mode="enhanced"]').addEventListener("click",e=>{e.preventDefault(),e.stopPropagation(),Fa(),Ua()}))}function za(e){qa(aa=e.currentTarget),Ra(aa)}function Oa(){Pa(),Ba(),Ca(),Na(),setTimeout(()=>{Na()},250)}function Ra(t){Pa(),Ha();var o=document.getElementById("ex-pip-menu-panel");if(o&&t){o.classList.add("is-visible","is-measuring"),o.style.removeProperty("visibility"),o.style.left="-9999px",o.style.top="0";var t=t.getBoundingClientRect(),n=o.offsetWidth,i=o.offsetHeight,a=t.left+t.width/2-n/2;let e=t.top-i-4;a=Math.max(8,Math.min(a,window.innerWidth-n-8)),e<8&&(e=t.bottom+4),o.classList.remove("is-measuring"),o.style.left=a+"px",o.style.top=e+"px"}}function Fa(){var e=document.getElementById("ex-pip-menu-panel");e&&e.classList.remove("is-visible","is-measuring"),aa=null}function Ha(){ia&&(clearTimeout(ia),ia=null)}function Ga(){Ha(),ia=setTimeout(()=>{var e=document.getElementById("ex-pip-menu-panel");e&&e.classList.contains("is-visible")&&(e.matches(":hover")||aa&&aa.matches(":hover")||Fa())},180)}function Va(e){e&&"1"!==e.dataset.exPipTooltipHidden&&(e.dataset.exPipTooltipHidden="1",e.style.setProperty("display","none","important"))}function qa(e){if(e){e=e.getAttribute("aria-describedby");if(e){e=document.getElementById(e);if(e&&"开启画中画"===(e.textContent||"").trim())return void Va(e)}}document.querySelectorAll(".mantine-Tooltip-tooltip").forEach(e=>{"开启画中画"===(e.textContent||"").trim()&&Va(e)})}function Ua(){if(document.getElementById("__video2"))if(window.documentPictureInPicture){var e=localStorage.getItem("ExSave_PipSet");if(e)try{var t=JSON.parse(e);Object.assign(z,t)}catch(e){}(async()=>{let o=document.getElementById("__video2"),r=(Qa(),or(),window.__pip_track_state__=[],await documentPictureInPicture.requestWindow({width:670,height:380,disallowReturnToOpener:!0,preferInitialWindowPlacement:!0})),n=(r.document.body.innerHTML=`
        <style>
            html,body{margin:0;width:100%;height:100%;overflow:hidden;background:black;font-family: sans-serif;}
            #wrap{position:relative;width:100%;height:100%;display:flex;flex-direction:column;}
            #main-view{position:relative;flex:1;width:100%;overflow:hidden;}
            video{width:100%;height:100%;object-fit:contain;}
            #danmaku{position:absolute;inset:0;pointer-events:none;overflow:hidden;}
            
            #pip-back-opener {
                position: absolute;
                top: 10px;
                right: -140px;
                left: auto;
                z-index: 10001;
                padding: 6px 12px;
                font-size: 15px;
                font-weight: 600;
                line-height: 1.25;
                color: #fff;
                background: rgba(0, 0, 0, 0.65);
                border: 1px solid rgba(255, 255, 255, 0.35);
                border-radius: 6px;
                cursor: pointer;
                font-family: "Microsoft YaHei", "SimHei", sans-serif;
                transition: right 0.3s, background 0.2s, border-color 0.2s;
                white-space: nowrap;
                user-select: none;
            }
            #pip-back-opener:hover {
                background: rgba(0, 0, 0, 0.88);
                border-color: rgba(255, 255, 255, 0.55);
            }
            #wrap:hover #pip-back-opener {
                right: 10px;
            }

            #combo-container {
                position: absolute;
                top: 6px;
                left: 6px;
                right: 6px;
                display: flex;
                flex-direction: row;
                flex-wrap: wrap;
                align-items: flex-start;
                align-content: flex-start;
                gap: 4px;
                max-height: 44px;
                overflow: hidden;
                pointer-events: none;
                z-index: 9999;
            }
            .combo-item {
                background: rgba(0, 0, 0, 0.55);
                color: #fff;
                padding: 2px 8px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 600;
                line-height: 1.3;
                max-width: calc(50% - 4px);
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                border: 1px solid rgba(255, 193, 7, 0.45);
                text-shadow: 0 1px 2px #000;
                box-sizing: border-box;
            }
            .combo-item--more {
                max-width: none;
                flex-shrink: 0;
                color: #d4d4d8;
                border-color: rgba(255, 255, 255, 0.2);
                background: rgba(0, 0, 0, 0.4);
                font-size: 10px;
                font-weight: 500;
            }
            .combo-count {
                color: #ffeb3b;
                margin-left: 4px;
                font-weight: 700;
            }

            .dm{
                position:absolute;
                white-space:nowrap;
                will-change:transform;
                box-sizing: border-box;
                font-weight: 700;
                line-height: 1.2;
                font-family: "SimHei", "Microsoft YaHei", "Arial Black", "Segoe UI Historic", sans-serif;
                text-shadow:
                    1px 0 1px rgba(0, 0, 0, 0.85),
                    -1px 0 1px rgba(0, 0, 0, 0.85),
                    0 1px 1px rgba(0, 0, 0, 0.85),
                    0 -1px 1px rgba(0, 0, 0, 0.85);
            }
            
            .dm-self {
                background-color: rgba(0, 0, 0, 0.35);
                border: 1px solid #00ff66 !important;
                padding: 2px 8px;
                border-radius: 4px;
                box-shadow: 0 0 4px rgba(0, 255, 102, 0.4), inset 0 0 4px rgba(0, 255, 102, 0.15);
            }

            #pip-btns{
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                display: flex;
                justify-content: center;
                left: -50px;
                padding: 4px;
                z-index: 1000;
                transition: all 0.3s;
                flex-direction: column;
            }

            .pip-btn {
                width: 36px;
                height: 36px;
                min-width: 36px;
                min-height: 36px;
                padding: 0;
                box-sizing: border-box;
                flex-shrink: 0;
                border: 2px solid #FFF;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                background: #00000094;
                cursor: pointer;
                z-index: 1000;
                transition: all 0.3s;
                margin: 5px 0;
            }

            .pip-btn img,
            .pip-btn svg {
                display: block;
                width: 24px;
                height: 24px;
                color: #fff;
            }

            .pip-btn:hover {background:#000000c4;}
            .pip-btn-danmaku {
                position: relative;
                font-size: 15px;
                font-weight: 700;
                color: #fff;
                line-height: 1;
                font-family: "Microsoft YaHei", "SimHei", sans-serif;
            }
            .pip-btn-danmaku.is-off {
                opacity: 0.65;
                border-color: #999;
                color: #ccc;
            }
            .pip-btn-danmaku.is-off::after {
                content: "";
                position: absolute;
                left: 18%;
                top: 50%;
                width: 64%;
                height: 2px;
                background: rgba(255, 255, 255, 0.95);
                transform: translateY(-50%) rotate(-45deg);
                border-radius: 1px;
                pointer-events: none;
            }
            #wrap:hover #pip-btns {left:10px}

            #pip-toast{
                position:absolute;
                left:50%;top:50%;
                transform:translate(-50%,-50%);
                background:rgba(0,0,0,.75);
                color:#fff;
                padding:10px 16px;
                border-radius:10px;
                font-size:14px;
                z-index:99999;
                opacity:0;
                transition:opacity .3s;
                pointer-events:none;
                text-align:center;
            }
            #pip-toast.show{opacity:1;}

            #input-panel {
                display: none;
                background: #18181c;
                padding: 8px 12px;
                box-sizing: border-box;
                border-top: 1px solid #2f2f35;
                align-items: center;
                gap: 10px;
                z-index: 10000;
                position: absolute;
                bottom: 0;
                width: 100%;
            }
            #input-panel.active {
                display: flex;
            }
            #pip-input-field {
                flex: 1;
                background: #2a2a30;
                border: 1px solid #3f3f46;
                border-radius: 6px;
                color: #fff;
                padding: 6px 10px;
                font-size: 14px;
                outline: none;
            }
            #pip-input-field:focus {
                border-color: #ff5d23;
            }
            #pip-submit-btn {
                background: #ff5d23;
                color: #fff;
                border: none;
                padding: 6px 14px;
                border-radius: 6px;
                font-size: 14px;
                cursor: pointer;
                font-weight: bold;
                transition: background 0.2s;
            }
            #pip-submit-btn:hover {
                background: #e04e1b;
            }
        </style>

        <div id="wrap">
            <div id="main-view">
                <div id="pip-back-opener"></div>
                <div id="pip-btns">
                    <div id="pip-reload" class="pip-btn pip-btn-reload">${ga}</div>
                    <div id="pip-danmaku-toggle" class="pip-btn pip-btn-danmaku"></div>
                    <div id="pip-set" class="pip-btn">${Xi}</div>
                    <div id="pip-send" class="pip-btn">${Ki}</div>
                </div>
                <video id="pip-video" autoplay muted playsinline></video>
                <div id="danmaku"></div>
                <div id="combo-container"></div>
                <div id="pip-toast"></div>
            </div>
            
            <div id="input-panel">
                <input type="text" id="pip-input-field" placeholder="" maxlength="50" autocomplete="off" />
                <button id="pip-submit-btn" type="button"></button>
            </div>
        </div>
    `,(window.__pip_window__=r).__pip_source_video__=o,r.document.getElementById("pip-video")),t=r.document.getElementById("danmaku"),e=r.document.getElementById("main-view"),i=r.document.getElementById("input-panel"),a=r.document.getElementById("pip-set"),l=r.document.getElementById("pip-send"),s=r.document.getElementById("pip-danmaku-toggle"),d=r.document.getElementById("pip-reload"),c=r.document.getElementById("pip-back-opener"),p=r.document.getElementById("pip-toast");ha(r);var m=r,u=m.document,g=u.getElementById("pip-input-field"),h=u.getElementById("pip-submit-btn"),f=(g&&g.setAttribute("placeholder","发条弹幕吧..."),h&&(h.textContent="发送"),(g=u.getElementById("pip-reload"))&&(g.title="刷新画面（恢复卡屏）"),(h=u.getElementById("pip-back-opener"))&&(h.textContent="回到网页",h.title="退出画中画并返回直播页"),fa(m),Ya(!1),Wa(!0),!0===z.lowPowerMode&&Ya(!0),n.srcObject=o.captureStream(),await n.play().catch(()=>{}),s&&s.addEventListener("click",e=>{e.stopPropagation(),z.danmakuVisible=!1===z.danmakuVisible,localStorage.setItem("ExSave_PipSet",JSON.stringify(z)),ha(r),fa(r)}),d&&d.addEventListener("click",async e=>{e.stopPropagation();e=await wa(r,n);p.innerText=e?"画面已刷新":"刷新失败，请检查主页视频",p.classList.add("show"),clearTimeout(p._timer),p._timer=setTimeout(()=>p.classList.remove("show"),2e3)}),c&&c.addEventListener("click",e=>{e.stopPropagation(),ba(r)}),a.addEventListener("click",u=>{u.stopPropagation(),ba(r,!1);{let d=document.getElementById("pip-setting-panel"),c={fontSize:18,speed:2.5,area:"full",trackHeight:28,mergeMode:"combo",lowPowerMode:!1,filterRobotDanmaku:!0,opacity:1,danmakuVisible:!0},p=()=>{localStorage.setItem("ExSave_PipSet",JSON.stringify(z))},m=()=>{document.getElementById("pip-area").value=z.area,document.getElementById("pip-mergemode").value=z.mergeMode||"combo",document.getElementById("pip-lowpowermode").value=!0===z.lowPowerMode?"on":"off",document.getElementById("pip-filterrobot").value=!1!==z.filterRobotDanmaku?"on":"off",document.getElementById("pip-tabswitch").value=Ft()?"on":"off",document.getElementById("pip-fontsize").value=z.fontSize,document.getElementById("pip-fontsize-value").innerText=z.fontSize,document.getElementById("pip-trackheight").value=z.trackHeight||28,document.getElementById("pip-trackheight-value").innerText=z.trackHeight||28,document.getElementById("pip-speed").value=z.speed,document.getElementById("pip-speed-value").innerText=z.speed;var e=Math.round(100*(null!=z.opacity?z.opacity:1));document.getElementById("pip-opacity").value=e,document.getElementById("pip-opacity-value").innerText=e+"%"};if(d)d.style.display="block",m();else{(d=document.createElement("div")).id="pip-setting-panel",d.innerHTML=`
        <div class="pip-setting-header">
            <div class="pip-setting-title">画中画弹幕设置</div>
            <div class="pip-setting-header-actions">
                <span class="pip-setting-reset">恢复默认</span>
                <button type="button" class="pip-setting-dismiss" aria-label="关闭">×</button>
            </div>
        </div>

        <div class="pip-setting-item">
            <span>弹幕字号</span>
            <input id="pip-fontsize" type="range" min="12" max="48" value="${z.fontSize}">
            <span id="pip-fontsize-value">${z.fontSize}</span>
        </div>

        <div class="pip-setting-item">
            <span>弹幕上下间距</span>
            <input id="pip-trackheight" type="range" min="14" max="60" value="${z.trackHeight||28}">
            <span id="pip-trackheight-value">${z.trackHeight||28}</span>
        </div>

        <div class="pip-setting-item">
            <span>弹幕速度</span>
            <input id="pip-speed" type="range" min="1" max="10" step="0.5" value="${z.speed}">
            <span id="pip-speed-value">${z.speed}</span>
        </div>

        <div class="pip-setting-item">
            <span>弹幕透明度</span>
            <input id="pip-opacity" type="range" min="30" max="100" value="${Math.round(100*(null!=z.opacity?z.opacity:1))}">
            <span id="pip-opacity-value">${Math.round(100*(null!=z.opacity?z.opacity:1))}%</span>
        </div>

        <div class="pip-setting-item">
            <span>弹幕显示区域</span>
            <select id="pip-area">
                <option value="full">全屏</option>
                <option value="half">1/2</option>
                <option value="quarter">1/4</option>
            </select>
        </div>

        <div class="pip-setting-item item-vertical">
            <div class="item-label-row">
                <span>重复弹幕合并</span>
                <select id="pip-mergemode">
                    <option value="all">全部显示</option>
                    <option value="single">只显示一条</option>
                    <option value="combo">合并显示（如X5）</option>
                </select>
            </div>
            <div class="pip-setting-tip">短时间内多条相同弹幕内容时的显示方式</div>
        </div>

        <div class="pip-setting-item item-vertical">
            <div class="item-label-row">
                <span>屏蔽机器人弹幕</span>
                <select id="pip-filterrobot">
                    <option value="on">开启</option>
                    <option value="off">关闭</option>
                </select>
            </div>
            <div class="pip-setting-tip">开启后过滤无用户标识的机器人弹幕</div>
        </div>

        <div class="pip-setting-item item-vertical">
            <div class="item-label-row">
                <span>原网页低功耗</span>
                <select id="pip-lowpowermode">
                    <option value="on">开启</option>
                    <option value="off">关闭</option>
                </select>
            </div>
            <div class="pip-setting-tip">开启后，拉起画中画时将隐藏原网页视频区、飘屏弹幕与礼物动画，保留右侧弹幕列表，以降低 CPU 占用</div>
        </div>

        <div class="pip-setting-item item-vertical">
            <div class="item-label-row">
                <span>页签防冻结</span>
                <select id="pip-tabswitch">
                    <option value="on">开启</option>
                    <option value="off">关闭</option>
                </select>
            </div>
            <div class="pip-setting-tip">与扩展工具「防页签冻结」共用设置；开启后画中画期间保持源页解码并自动缓解卡屏（关闭需刷新页面后完全生效）</div>
        </div>

    `,document.getElementById("pip-setting-style")||((g=document.createElement("style")).id="pip-setting-style",g.innerHTML=`
            #pip-setting-panel {
                position: fixed;
                width: 440px;
                background: rgba(255, 255, 255, 0.98);
                border: 1px solid rgba(212, 212, 216, 1);
                box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
                border-radius: 12px;
                padding: 24px;
                z-index: 999999;
                font-family: "Helvetica Neue", Helvetica, Arial, "Microsoft Yahei", sans-serif;
                color: #18181b;
                box-sizing: border-box;
                backdrop-filter: blur(10px);
            }

            .pip-setting-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                margin: -24px -24px 24px;
                padding: 24px 24px 0;
                cursor: move;
                user-select: none;
            }

            .pip-setting-title {
                flex: 1;
                min-width: 0;
                font-size: 16px;
                font-weight: 600;
                color: #000000;
                letter-spacing: 0.5px;
                margin: 0;
            }

            .pip-setting-header-actions {
                display: flex;
                align-items: center;
                gap: 12px;
                flex-shrink: 0;
            }

            .pip-setting-reset {
                font-size: 13px;
                color: #71717a;
                cursor: pointer;
                transition: color 0.2s;
                text-decoration: underline;
                user-select: none;
                font-weight: 500;
                white-space: nowrap;
            }

            .pip-setting-reset:hover {
                color: #ff5d23;
            }

            .pip-setting-dismiss {
                flex-shrink: 0;
                width: 28px;
                height: 28px;
                margin: 0;
                padding: 0;
                border: none;
                border-radius: 6px;
                background: transparent;
                color: #71717a;
                font-size: 22px;
                line-height: 1;
                cursor: pointer;
                user-select: none;
                transition: background 0.2s, color 0.2s;
            }

            .pip-setting-dismiss:hover {
                background: #f4f4f5;
                color: #18181b;
            }

            .pip-setting-item {
                margin-bottom: 18px;
                display: flex;
                align-items: center;
                font-size: 13px;
            }

            .pip-setting-item.item-vertical {
                margin-bottom: 20px;
                flex-direction: column;
                align-items: flex-start;
            }

            .item-label-row {
                width: 100%;
                display: flex;
                align-items: center;
            }

            .pip-setting-item span:first-child {
                width: 100px;
                color: #3f3f46;
                font-weight: 600;
            }

            .pip-setting-item input[type="range"] {
                flex: 1;
                margin: 0 14px;
                -webkit-appearance: none;
                background: #d4d4d8;
                height: 4px;
                border-radius: 2px;
                outline: none;
            }

            .pip-setting-item input[type="range"]::-webkit-slider-thumb {
                -webkit-appearance: none;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                background: #ff5d23;
                cursor: pointer;
                transition: transform 0.1s;
            }

            .pip-setting-item input[type="range"]::-webkit-slider-thumb:hover {
                transform: scale(1.2);
            }

            .pip-setting-item select {
                flex: 1;
                background: #f4f4f5;
                color: #18181b;
                padding: 6px 10px;
                border-radius: 6px;
                border: 1px solid #cdcdd6;
                outline: none;
                font-size: 13px;
                cursor: pointer;
                transition: border-color 0.2s, background 0.2s;
                font-weight: 500;
            }

            .pip-setting-item select:focus {
                border-color: #ff5d23;
                background: #ffffff;
            }

            .pip-setting-item span:last-child {
                width: 32px;
                text-align: right;
                color: #ff5d23;
                font-weight: bold;
                font-family: monospace;
            }

            .pip-setting-tip {
                font-size: 11px;
                color: #52525b;
                margin-top: 6px;
                margin-left: 100px;
                line-height: 1.4;
            }

        `,document.head.appendChild(g)),document.body.appendChild(d);var g=Math.max(8,(window.innerWidth-d.offsetWidth)/2),u=Math.max(8,(window.innerHeight-d.offsetHeight)/2);d.style.left=g+"px",d.style.top=u+"px",(d=>{var e=d.querySelector(".pip-setting-header");if(e){let o=!1,n=0,i=0,a=0,r=0,l=e=>{var t;o&&(t=e.clientX-n,e=e.clientY-i,d.style.left=Math.max(0,a+t)+"px",d.style.top=Math.max(0,r+e)+"px")},s=()=>{o=!1,document.removeEventListener("mousemove",l),document.removeEventListener("mouseup",s)};e.addEventListener("mousedown",e=>{var t;0!==e.button||e.target.closest(".pip-setting-dismiss, .pip-setting-reset")||(o=!0,t=d.getBoundingClientRect(),d.style.left=t.left+"px",d.style.top=t.top+"px",n=e.clientX,i=e.clientY,a=t.left,r=t.top,document.addEventListener("mousemove",l),document.addEventListener("mouseup",s),e.preventDefault())})}})(d);let e=document.getElementById("pip-fontsize"),t=document.getElementById("pip-trackheight"),o=document.getElementById("pip-speed"),n=document.getElementById("pip-area"),i=document.getElementById("pip-mergemode"),a=document.getElementById("pip-lowpowermode"),r=document.getElementById("pip-filterrobot"),l=document.getElementById("pip-tabswitch"),s=document.getElementById("pip-opacity");n.value=z.area,i.value=z.mergeMode||"combo",a.value=!0===z.lowPowerMode?"on":"off",r.value=!1!==z.filterRobotDanmaku?"on":"off",l.value=Ft()?"on":"off",e.addEventListener("input",()=>{z.fontSize=parseInt(e.value),document.getElementById("pip-fontsize-value").innerText=z.fontSize,p()}),t.addEventListener("input",()=>{z.trackHeight=parseInt(t.value),document.getElementById("pip-trackheight-value").innerText=z.trackHeight,p()}),o.addEventListener("input",()=>{z.speed=parseFloat(o.value),document.getElementById("pip-speed-value").innerText=z.speed,p()}),s.addEventListener("input",()=>{z.opacity=parseInt(s.value,10)/100,document.getElementById("pip-opacity-value").innerText=s.value+"%",p(),window.__pip_is_active__&&ha()}),n.addEventListener("change",()=>{z.area=n.value,p()}),i.addEventListener("change",()=>{z.mergeMode=i.value,p()}),r.addEventListener("change",()=>{z.filterRobotDanmaku="on"===r.value,p()}),a.addEventListener("change",()=>{z.lowPowerMode="on"===a.value,p(),window.__pip_is_active__&&Ya(z.lowPowerMode)}),l.addEventListener("change",()=>{var e,t,o,n="on"===l.value;Ht(n),n?Gt():S("已关闭页签防冻结，请刷新页面后完全生效","info"),window.__pip_is_active__&&(t=(e=window.__pip_window__)?.document.getElementById("pip-video"),o=e?.__pip_source_video__,n?_a(o,e,t):ka())}),d.querySelector(".pip-setting-reset").addEventListener("click",()=>{confirm("确定要将画中画设置恢复为默认配置吗？")&&(Object.assign(z,c),p(),m(),window.__pip_is_active__)&&(Ya(z.lowPowerMode),ha(),fa())}),d.querySelector(".pip-setting-dismiss").addEventListener("click",()=>{d.style.display="none"})}}p.innerText="已在斗鱼直播页面打开设置面板",p.classList.add("show"),clearTimeout(p._timer),p._timer=setTimeout(()=>p.classList.remove("show"),5e3)}),l.addEventListener("click",e=>{e.stopPropagation(),i.classList.contains("active")?i.classList.remove("active"):Ea(r)}),e=>{var t;"Enter"===e.key&&(t=r.document.getElementById("pip-input-field"),r.document.activeElement!==t)&&(e.preventDefault(),Ea(r))});r.document.addEventListener("keydown",f),r.__pip_keydown_handler__=f,e.addEventListener("click",()=>{i.classList.contains("active")&&i.classList.remove("active")});{var y=r,b=t;let o=y.document.getElementById("pip-input-field"),e=y.document.getElementById("pip-submit-btn"),n=y.document.getElementById("input-panel");async function v(){var t=o.value.trim();if(t){o.value="",n.classList.remove("active");let e=y.document.getElementById("pip-toast");e.innerText="发送成功",e.classList.add("show"),clearTimeout(e._timer),e._timer=setTimeout(()=>e.classList.remove("show"),2e3),ir({text:t,color:0},y,b,!0);try{(async e=>{let t=document.querySelector("div.ChatSend-txt"),o=document.querySelector(".ChatSend-button");t.innerText=e,o.click()})(t)}catch(e){console.error("弹幕发送接口调用失败:",e)}}}o.addEventListener("keydown",e=>{"Enter"===e.key&&v()}),e.addEventListener("click",()=>{v()})}var x=o,w=n;function _(){x.paused?w.pause():w.play().catch(()=>{})}x.addEventListener("play",_),x.addEventListener("pause",_),_a(o,r,n),Za&&clearInterval(Za),Za=setInterval(()=>{let t=Date.now();for(var[e,o]of Ja.entries())o.timestamps.filter(e=>t-e<=8e3).length<2&&Ja.delete(e);nr()},1e3),$i=new El(B,e=>{if(window.__pip_is_active__&&!(e=>{var t=Date.now(),o=Xa.get(e);if(null!=o&&t-o<er)return 1;if(Xa.set(e,t),Xa.size>tr)for(var[n,i]of Xa)t-i>er&&Xa.delete(n)})(e)){var e=(e=>{if(!e||!e.startsWith("type@=chatmsg/"))return null;var t,o={},n=e.split("/");for(let e=0;e<n.length;e++){var i=n[e],a=i.indexOf("@=");-1!==a&&(o[i.substring(0,a)]=i.substring(a+2))}return(e=o.txt?decodeURIComponent(o.txt):"")&&(!1===z.filterRobotDanmaku||o.dms)?(t=o.hash||o.cid||o.dmid||"",{text:e,color:o.col?parseInt(o.col):0,uid:o.uid||"",msgId:t,dedupKey:t||o.uid+"|"+e}):null})(e),o=r,n=t;if(e&&e.text&&!1!==z.danmakuVisible&&(!I||e.uid!==I)){var i=z.mergeMode||"combo";if("all"===i)ir(e,o,n);else{let t=Date.now();var a=(e=>{if(!Ja.has(e)){var t=e=>e.replace(/\s+/g,"").split("").filter((e,t,o)=>o.indexOf(e)===t).join(""),o=t(e);if(o)for(var n of Ja.keys()){var i=t(n);if(o===i&&Math.abs(e.length-n.length)<=6)return n;if((e.includes(n)||n.includes(e))&&Math.abs(e.length-n.length)<=4)return n}}return e})(e.text),a=(Ja.has(a)||Ja.set(a,{timestamps:[],dom:null,displayCount:0}),Ja.get(a));a.timestamps.push(t),"single"===i?1<a.timestamps.filter(e=>t-e<=4e3).length||ir(e,o,n):(a.timestamps=a.timestamps.filter(e=>t-e<=8e3),1===(i=a.timestamps.length)?(a.displayCount=0,ir(e,o,n)):a.displayCount=i,nr(o))}}}});{o;var k=r,E=n;window.__pip_is_active__=!0;let e=()=>ya(k,E),t=(k.addEventListener("pagehide",e),setInterval(()=>{k.closed&&(clearInterval(t),e())},2e3))}})()}else S("【画中画增强】当前浏览器不支持画中画增强功能，建议使用 Chrome 116+ 或 Edge 116+","error");else S("【画中画增强】当前直播间不支持画中画增强功能","error")}function Wa(e){var t=document.getElementById("__video2");t&&(e?(t.style.setProperty("opacity","0.01","important"),t.style.setProperty("pointer-events","none","important")):(t.style.removeProperty("opacity"),t.style.removeProperty("pointer-events")))}function Ya(t){[".layout-Player-video",".layout-Player-videoEntity",".room-html5-player",".DiamondsFansRankList",".wm-view",".wm-tabv2",".comment-37342a",".DanmuEffectDom",".layout-Player-asideMainTop"].forEach(e=>{e=document.querySelector(e);e&&(t?e.style.setProperty("display","none","important"):e.style.removeProperty("display"))}),[".ChatSend-txt",".ChatSend-button"].forEach(e=>{e=document.querySelector(e);e&&(t?(e.style.setProperty("opacity","0.01","important"),e.style.setProperty("pointer-events","none","important")):(e.style.removeProperty("opacity"),e.style.removeProperty("pointer-events")))}),t||[".layout-Player",".Barrage-list"].forEach(e=>{e=document.querySelector(e);e&&e.style.removeProperty("display")})}function Qa(){if($i){var e=$i;$i=null,e.msgHandler=()=>{};try{e.close()}catch(e){}}}let Ja=new Map,Za=null,Xa=new Map,Ka=2,$a=18,er=3e3,tr=800;function or(){Xa.clear()}function nr(n){var i=n||((n=window.__pip_window__)&&!n.closed?n:null),a=i?.document.getElementById("combo-container");if(a){let t=Date.now();var e,o,r=[];for([e,o]of Ja.entries()){var l,s=o.timestamps.filter(e=>t-e<=8e3).length;s<2?o.dom=null:(o.displayCount=s,l=o.timestamps[o.timestamps.length-1]||0,r.push({key:e,info:o,count:s,lastTs:l}))}r.sort((e,t)=>t.count-e.count||t.lastTs-e.lastTs),a.innerHTML="";for(let[,e]of Ja)e.dom=null;var d,c,n=r.slice(0,Ka),p=r.length-n.length;for(let{key:e,info:t,count:o}of n){var m=i.document.createElement("div");m.className="combo-item",m.title=e,m.innerHTML=`${d=e,c=$a,!d||d.length<=c?d||"":d.slice(0,c)+"…"}<span class="combo-count">×${o}</span>`,a.appendChild(m),t.dom=m}0<p&&((n=i.document.createElement("div")).className="combo-item combo-item--more",n.textContent=`+${p} 组重复`,a.appendChild(n))}}function ir(t,i,a,r=!1){if(t&&t.text){let e=i.document.createElement("div");e.className="dm"+(r?" dm-self":""),e.innerText=t.text,e.style.fontSize=z.fontSize+"px",e.style.color=r?"#00ff66":(e=>{switch(e){case 1:return"#ff3b30";case 2:return"#0a84ff";case 3:return"#34c759";case 4:return"#ff9500";case 5:return"#af52de";case 6:return"#ff2d55";default:return"#ffffff"}})(t.color),e.style.visibility="hidden",a.appendChild(e);var r=e.offsetWidth,t=i.innerWidth,a=((e,t)=>{let o=Math.floor(e.innerHeight/z.trackHeight);"half"===z.area?o=Math.floor(o/2):"quarter"===z.area&&(o=Math.floor(o/4)),o=Math.max(1,o),window.__pip_track_state__||(window.__pip_track_state__=[]);var n=window.__pip_track_state__,i=e.innerWidth,e=15/z.speed,a=Math.max(.7*e,Math.min(1.4*e,e+t/120/z.speed)),r=(i+t)/a;let l=-1;for(let e=0;e<o;e++){var s=n[e];if(!s)return n[e]={textWidth:t,speed:r,startTime:Date.now(),duration:1e3*a},e;var d=Date.now()-s.startTime;if(d>=s.duration)return n[e]={textWidth:t,speed:r,startTime:Date.now(),duration:1e3*a},e;var c=i-s.speed*(d/1e3),p=c+s.textWidth;if(!(i-16<p)){if(r>s.speed){p=s.duration-d;if(1e3*(c/(r-s.speed))<p)continue}l=e;break}}if(-1===l){let t=1/0;for(let e=0;e<o;e++){var m=n[e];if(!m){l=e;break}var u=Date.now()-m.startTime,u=i-m.speed*(u/1e3)+m.textWidth;u<t&&(t=u,l=e)}}return n[l]={textWidth:t,speed:r,startTime:Date.now(),duration:1e3*a},l})(i,r),l=a*z.trackHeight,a=window.__pip_track_state__[a].duration/1e3;e.style.top=l+"px",e.style.left=t+"px",e.style.visibility="visible";let o="exPipMove_"+Math.random().toString(36).substring(2,9);l=i.document;let n=l.getElementById("ex-danmaku-styles");n||((n=l.createElement("style")).id="ex-danmaku-styles",l.head.appendChild(n)),n.sheet.insertRule(`
        @keyframes ${o} {
            from { transform: translateX(0); }
            to { transform: translateX(-${t+r+30}px); }
        }
    `,0),e.style.animation=o+` ${a}s linear forwards`,e.addEventListener("animationend",()=>{e.remove();try{var t=n.sheet;for(let e=0;e<t.cssRules.length;e++)if(t.cssRules[e].name===o){t.deleteRule(e);break}}catch(e){}})}}let ar=!1,rr=null,lr=2,sr=1,dr=1;function cr(){if(ar=!ar){let o=document.querySelector("#ex-framechase-container .status-indicator"),e=document.querySelector("#ex-framechase-container .xg-icon"),n=0;e.querySelector(".xgplayer-icon").style.background="rgba(0,255,0,0.2)",e.querySelector(".xgplayer-icon").style.boxShadow="0 0 6px rgba(0,255,0,0.3)",rr=setInterval(()=>{var e,t=H.buffered;0!==t.length&&(t=t.end(t.length-1)-H.currentTime,500<(e=Date.now())-n&&(o.textContent=t.toFixed(1)+"s",n=e),t>dr?H.playbackRate=lr:H.playbackRate=sr)},200)}else{clearInterval(rr);var e=document.querySelector("#ex-framechase-container .status-indicator"),t=document.querySelector("#ex-framechase-container .xg-icon");H.playbackRate=sr,e&&(e.textContent=""),t.querySelector(".xgplayer-icon").style.background="rgba(255,255,255,0.1)",t.querySelector(".xgplayer-icon").style.boxShadow="none"}}let pr="",mr="",ur="",O="",gr=!1,hr=0,fr=!1,R={rotateY:"",rotate:"",scale:""},yr=null;function br(){return/Edg/i.test(navigator.userAgent)}function vr(){var e=document.querySelector("#ex-vtoolbar-filter-host .filter__wrap");e&&(e.style.display="block")}function xr(){var e=document.querySelector("#ex-vtoolbar-filter-host .filter__wrap");e&&(e.style.display="none")}function wr(){V("Ex_Style_Filter"),document.getElementById("filter__select").selectedIndex=0,H.style.filter="",hr=0,R={rotateY:"",rotate:"",scale:""},H.parentNode.style.transform="",document.getElementById("bar__bright").style.left="100px",document.getElementById("bar__contrast").style.left="100px",document.getElementById("bar__saturate").style.left="100px",document.getElementById("mask__bright").style.width="100px",document.getElementById("mask__contrast").style.width="100px",document.getElementById("mask__saturate").style.width="100px",br()&&(fr=!1,t=document.getElementById("slider__enhance"),e=document.getElementById("switch__enhance"),t&&(t.style.left="0px"),e&&(e.style.background="#ccc"),H.style.imageRendering="",t=document.getElementsByClassName("enhance-modal__panel-wrap")[0])&&(t.style.display="none");var e=document.getElementById("ex-panorama"),t=(e&&(e.remove(),yr=null),document.getElementsByClassName("layout-Player-videoEntity")[0]);t.style.transform="",t.style.transformOrigin="",Ur=1,V("Ex_Style_Cinema"),H.playbackRate=1}function F(e){V("Ex_Style_Filter"),_l("Ex_Style_Filter",e),xr()}function _r(e,t,o,n){let i=e,a=t,r=o,l=0;a.onmousedown=function(e){let t=(e||window.event).clientX-this.offsetLeft,o=this;document.onmousemove=function(e){e=e||window.event;(l=e.clientX-t)<0?l=0:l>i.offsetWidth-a.offsetWidth&&(l=i.offsetWidth-a.offsetWidth),r.style.width=l+"px",o.style.left=l+"px",n(parseInt(l/(i.offsetWidth-a.offsetWidth)*255)),window.getSelection?window.getSelection().removeAllRanges():document.selection.empty()}}}var H,kr=null;let Er=!1,Br=!1,Ir=null;function Sr(){return document.getElementById("ex-vtoolbar-menu")}function Cr(){clearTimeout(Ir),Ar()}function Tr(){clearTimeout(Ir),Er||Ar()}function Nr(e){var t,e=e.relatedTarget;e=e,(t=Sr())&&e&&t.contains(e)||(clearTimeout(Ir),Ir=setTimeout(()=>{Dr()},80))}function Mr(e,t){e&&(t?(e.addEventListener("mouseenter",Cr),e.addEventListener("pointerenter",Cr)):(e.addEventListener("mouseenter",Tr),e.addEventListener("pointerenter",Tr)),e.addEventListener("mouseleave",Nr),e.addEventListener("pointerleave",Nr))}function Lr(e){"Escape"===e.key&&(Dr(),jr())}function Ar(){var e=document.getElementById("ex-vtoolbar-menu");e&&(Er=!0,e.classList.add("is-open"),e.querySelector(".vtoolbar-menu__trigger").setAttribute("aria-expanded","true"))}function Dr(){var e=document.getElementById("ex-vtoolbar-menu");e&&(clearTimeout(Ir),Er=!1,e.classList.remove("is-open"),e.querySelector(".vtoolbar-menu__trigger").setAttribute("aria-expanded","false"),jr())}function jr(){var e=document.getElementById("ex-vtoolbar-filter-host"),t=document.getElementById("vtoolbar-menu-filter");Br=!1,e&&e.classList.remove("is-visible"),t&&(t.classList.remove("is-active"),t.setAttribute("aria-expanded","false")),xr()}function Pr(){return document.getElementById("ex-vtoolbar-filter-host")}let zr=et,Or='<svg t="1598941324196" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3146"><path d="M921.6 766.634667L257.365333 102.4a68.266667 68.266667 0 0 0-96.597333 0L102.4 160.768a68.266667 68.266667 0 0 0 0 96.597333L766.634667 921.6a68.266667 68.266667 0 0 0 96.597333 0L921.6 863.232a68.266667 68.266667 0 0 0 0-96.597333zM139.605333 199.338667l59.733334-59.733334A13.312 13.312 0 0 1 208.896 136.533333a13.653333 13.653333 0 0 1 9.898667 4.096l83.968 82.944-79.189334 79.189334-83.968-83.968a13.653333 13.653333 0 0 1 0-19.456z m744.789334 625.322666l-59.733334 59.733334a13.312 13.312 0 0 1-9.557333 4.096 13.653333 13.653333 0 0 1-9.898667-4.096L262.144 341.333333 341.333333 262.144l543.061334 543.061333a13.653333 13.653333 0 0 1 0 19.456zM230.058667 589.824l-50.517334 92.501333-92.842666 50.858667 92.842666 50.517333 50.517334 92.842667 50.517333-92.842667 92.842667-50.517333-92.842667-50.858667-50.517333-92.501333zM541.013333 270.336l31.061334-57.344 57.344-31.402667-57.344-31.402666-31.061334-57.002667-31.402666 57.002667-57.344 31.402666 57.344 31.402667 31.402666 57.344zM827.392 377.173333l21.162667-38.912L887.466667 317.098667l-38.912-21.504-21.162667-38.912-21.504 38.912-38.570667 21.504 38.570667 21.162666 21.504 38.912z" p-id="3147" fill="#ffffff"></path></svg>',Rr='<svg class="vtoolbar-menu__chevron" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',Fr='<svg class="icon" viewBox="0 0 1237 1024" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M648.448 946.347l0.256-1.622-0.256 1.622z m84.31 13.354c-0.769 4.608-0.769 4.608-4.182 13.483-8.533 16.768-8.533 16.768-49.835 22.784-24.149-14.293-24.149-14.293-27.605-22.613-2.475-5.718-2.475-5.718-3.541-9.387L476.416 335.36l-103.083 499.2c-1.109 5.12-1.109 5.12-4.821 13.27-6.827 12.117-6.827 12.117-35.285 22.527-30.294-7.253-30.294-7.253-38.742-19.37-4.522-8.15-4.522-8.15-6.058-13.227l-74.582-262.357H0v-85.334h278.272l45.781 161.11 104.022-503.424c1.024-4.694 1.024-4.694 4.394-12.502 6.102-11.989 6.102-11.989 35.968-23.338 31.83 8.533 31.83 8.533 39.254 20.736 4.053 7.808 4.053 7.808 5.376 12.544l165.888 609.237 113.92-716.885c0.896-5.248 0.896-5.248 4.864-14.592 9.088-15.574 9.088-15.574 44.928-22.4C868.48 12.587 868.48 12.587 873.6 22.443c3.285 6.912 3.285 6.912 4.523 11.52l112 446.549h221.738v85.333H923.563l-78.507-312.917-112.299 706.773z" fill="#ffffff"/></svg>',Hr='<svg class="icon" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M496 64A48 48 0 0 1 544 112v800a48 48 0 0 1-96 0v-800A48 48 0 0 1 496 64z m-224 128A48 48 0 0 1 320 240v544a48 48 0 0 1-96 0v-544A48 48 0 0 1 272 192z m448 0A48 48 0 0 1 768 240v544a48 48 0 0 1-96 0v-544A48 48 0 0 1 720 192z m-672 128A48 48 0 0 1 96 368v288a48 48 0 0 1-96 0v-288A48 48 0 0 1 48 320z m896 0a48 48 0 0 1 48 48v288a48 48 0 0 1-96 0v-288a48 48 0 0 1 48-48z" fill="#ffffff"/></svg>',Gr='<svg class="icon vtoolbar-menu__icon-pip" viewBox="3 5 18 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect x="3" y="5" width="18" height="12" rx="2" stroke="#ffffff" stroke-width="1.5"/><path d="M7 10h5.5M7 13h3.5" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round"/></svg>';var Vr=!1;let qr=0;let Ur=1;var Wr=null,Yr=null,Qr=null,Jr=null;function Zr(e){try{var t=document.querySelector(".volume-07c230"),o=document.querySelector(".volume-bar-93f0b0 .front-99e2aa"),n=document.querySelector(".volume-bar-93f0b0 .point-6ef744"),i=document.querySelector(".volume-bar-93f0b0 .tips2-9bb064");o&&(o.style.height=100*e+"px"),n&&(n.style.bottom=100*e+7+"px"),i&&(i.textContent=`音量${Math.round(100*e)}%`),t&&(0===e?(t.classList.add("custom-muted"),t.classList.remove("custom-normal")):(t.classList.add("custom-normal"),t.classList.remove("custom-muted")))}catch(e){}}class Xr{constructor(e){var t={width:1920,height:1080,fontSize:36,alpha:this._prefixInteger(Number(0).toString(16),2),stayTime:10,title:"Default"};this.options={...t,...e,...e&&e.alpha?this._prefixInteger(this.options.alpha.toString(16),2):{}},this.lines=20,this.lineBase=this.options.height/this.lines,this.currentLine=0,this.diffTime=1500}generate(e){var t=e.sort((e,t)=>e.time-t.time);let o=this._getScriptInfo()+this._getV4Styles()+this._getEvents();for(let e=0;e<t.length;e++){0<e&&t[e].time-t[e-1].time<=this.diffTime?this.currentLine++:this.currentLine=0,this.currentLine>=this.lines&&(this.currentLine=0);var n=t[e],i=Number(n.time)+1e3*Number(this.options.stayTime),a=this.lineBase*this.currentLine+this.options.fontSize,r=this.options.fontSize*n.txt.length;o+=`Dialogue: 0,${W(Number(n.time)/1e3)}.00,${W(i/1e3)}.00,Color${n.color},,0,0,0,,{\\move(${this.options.width+r},${a},${-r},${a})}${n.txt}
`}return o}_prefixInteger(e,t){return e=""+e,Array(t+1-e.length).join("0")+e}_getScriptInfo(){return`[Script Info]
; DouyuEx -By qianjiachun
; https://github.com/qianjiachun/douyuEx
ScriptType: v4.00+
Title: ${this.options.title}
PlayResX: ${this.options.width}
PlayResY: ${this.options.height}
`}_getV4Styles(){return`
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Color0,黑体,${this.options.fontSize},&H${this.options.alpha}FFFFFF,&H80000000,&H80000000,&H80000000,0,0,0,0,100,100,0,0,0,0,0,0,0,0,0,134
Style: Color7,黑体,${this.options.fontSize},&H${this.options.alpha}5456FF,&H80000000,&H80000000,&H80000000,0,0,0,0,100,100,0,0,0,0,0,0,0,0,0,134
Style: Color8,黑体,${this.options.fontSize},&H${this.options.alpha}2375FF,&H80000000,&H80000000,&H80000000,0,0,0,0,100,100,0,0,0,0,0,0,0,0,0,134
Style: Color9,黑体,${this.options.fontSize},&H${this.options.alpha}B369FE,&H80000000,&H80000000,&H80000000,0,0,0,0,100,100,0,0,0,0,0,0,0,0,0,134
Style: Color10,黑体,${this.options.fontSize},&H${this.options.alpha}00BCFF,&H80000000,&H80000000,&H80000000,0,0,0,0,100,100,0,0,0,0,0,0,0,0,0,134
Style: Color11,黑体,${this.options.fontSize},&H${this.options.alpha}46C978,&H80000000,&H80000000,&H80000000,0,0,0,0,100,100,0,0,0,0,0,0,0,0,0,134
Style: Color12,黑体,${this.options.fontSize},&H${this.options.alpha}FF7F9E,&H80000000,&H80000000,&H80000000,0,0,0,0,100,100,0,0,0,0,0,0,0,0,0,134
Style: Color13,黑体,${this.options.fontSize},&H${this.options.alpha}FF9B3D,&H80000000,&H80000000,&H80000000,0,0,0,0,100,100,0,0,0,0,0,0,0,0,0,134
`}_getEvents(){return`
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`}}function Kr(e){return new Promise(t=>{fetch("https://www.douyu.com/wgapi/livenc/liveweb/follow/add",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`rid=${e}&ctn=`+x()}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})})}function $r(e){return new Promise(t=>{fetch("https://www.douyu.com/wgapi/livenc/liveweb/follow/rm",{method:"POST",mode:"no-cors",credentials:"include",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:`rid=${e}&ctn=`+x()}).then(e=>e.json()).then(e=>{t(e)}).catch(e=>{console.log("请求失败!",e)})})}class el{constructor(e){this.func_click=null,this.func_dbClick=null,this.func_longClick=null;let t=!1,o,n=0,i;e.onmousedown=e=>{0===e.button&&(t=!1,o=setTimeout(()=>{t=!0,null!==this.func_longClick&&this.func_longClick(e)},700))},e.onmouseup=e=>{0===e.button&&0==t&&(clearTimeout(o),2<=++n?(clearTimeout(i),n=0,null!==this.func_dbClick&&this.func_dbClick(e)):i=setTimeout(()=>{n=0,null!==this.func_click&&this.func_click(e)},0))}}click(e){this.func_click=e}dbClick(e){this.func_dbClick=e}longClick(e){this.func_longClick=e}}class G{constructor(e,t,o){this.selector=e,this.isSubtree=t;e=document.querySelector(this.selector);null!=e&&(t=new MutationObserver(function(e){o(e)}),this.observer=t,this.observer.observe(e,{attributes:!0,childList:!0,subtree:this.isSubtree}))}closeHook(){this.observer&&(this.observer.disconnect(),this.observer=null)}}class tl{constructor(e){this.pointId=e,this.decoder=new TextDecoder}getSign(){var e=parseInt((new Date).getTime()/1e3,10);return unsafeWindow[this.d539fa2cf7732d2a(256042,"9f4f419501570ad13334")](this.pointId,"10000000000000000000000000001501",e)}d539fa2cf7732d2a(e,t){for(var o=(e=CryptoJS.MM(e.toString()).toString())[0].charCodeAt(0),n=e[16].charCodeAt(0),i=[],a=0;a<4;a++)i[a]=o<<24|o<<16|o<<8|o,i[a+4]=n<<24|n<<16|n<<8|n;for(var e=Math.floor(t.length/16)%4,r=[],l=t.length%8,s=Math.floor(t.length/8),a=0;a<s;a++)r[a]=255&parseInt(t.substr(8*a,2),16)|parseInt(t.substr(8*a+2,2),16)<<8&65280|parseInt(t.substr(8*a+4,2),16)<<24>>>8|parseInt(t.substr(8*a+6,2),16)<<24;var d=0==e?e86500e2(r,i):1==e?this.c30070a4(r,i):d831eb20(r,i),c=[];for(a=0;a<d.length;a++){var p=255&d[a],m=d[a]>>>8&255,u=d[a]>>>16&255,g=d[a]>>>24&255;p&&c.push(p),m&&c.push(m),u&&c.push(u),g&&c.push(g)}var h=Math.floor(l/2);for(a=0;a<h;a++)c.push(255&parseInt(t.substr(8*s+2*a,2),16));return this.decoder.decode(new Uint8Array(c))}c30070a4(e,t){for(var o=Math.floor(e.length/2),n=e.slice(0),i=0;i<o;i++){var a=this.f5a40d76(e.slice(2*i,2*i+2),32,t.slice(4*i%8,4*i%8+4));n[2*i+0]=a[0],n[2*i+1]=a[1]}return n}f5a40d76(e,t,o){for(var n=0;n<e.length;n+=2){for(var i=e[n],a=e[n+1],r=2654435769*t,l=0;l<t;l++)i-=((a-=(i<<4^i>>>5)+i^r+o[r>>>11&3])<<4^a>>>5)+a^(r-=2654435769)+o[3&r];e[n]=i,e[n+1]=a}return e}}function ol(){var l=this;function s(e,t,o,n){var s=this;this.aborted=!1,this.threadNum=10,this.step=0,function n(a,i,r,l){let e=[];for(let t=0;t<s.threadNum;t++){if(!a[r+t]){e.push(Promise.resolve());break}e.push(fetch(a[r+t]).catch(e=>{fetch(a[r+t]).catch(e=>{fetch(a[r+t])})}))}s.step=e.length;Promise.all(e).then(function(e){return c(d(e,function(e){return e&&e.blob}),function(e){return e.blob()})}).then(function(e){return Promise.all(e)}).then(function(e){e=c(e,function(n,i){return new Promise(function(t,e){var o=new FileReader;o.readAsArrayBuffer(new Blob([n],{type:"octet/stream"})),o.addEventListener("loadend",function(e){t(o.result),s.onprogress&&s.onprogress({segment:r+i+1,total:a.length,percentage:((r+i+1)/a.length*100).toFixed(3),downloaded:m(+p(c(l,function(e){return e.byteLength}),function(e,t){return e+t},0)),status:"Downloading..."})})})}),Promise.all(e).then(function(e){for(var t=0;t<e.length;t++)l.push(e[t]);let o=s.step;a[r+2],s.aborted?(l=null,s.aborted()):a[r+o]?s.ie?setTimeout(function(){n(a,i,r+o,l)},500):n(a,i,r+o,l):i(l)})}).catch(function(e){s.onerror&&s.onerror("Something went wrong when downloading ts file, nr. "+r+": "+e)})}(e,t,o,n)}function d(e,t){for(var o=[],n=0;n<e.length;n++)t(e[n],n)&&o.push(e[n]);return o}function c(e,t){for(var o=e.slice(0),n=0;n<e.length;n++)o[n]=t(e[n],n);return o}function p(e,o,t){var n=t;return e.forEach(function(e,t){e=+o(n,e,t),n=e}),n}function m(e){for(var t=[{divider:1e18,suffix:"EB"},{divider:1e15,suffix:"PB"},{divider:1e12,suffix:"TB"},{divider:1e9,suffix:"GB"},{divider:1e6,suffix:"MB"},{divider:1e3,suffix:"kB"}],o=0;o<t.length;o++)if(e>=t[o].divider)return(e/t[o].divider).toString().toString().split(".")[0]+t[o].suffix;return e.toString()}this.ie=0<navigator.appVersion.toString().indexOf(".NET"),this.ios=navigator.platform&&/iPad|iPhone|iPod/.test(navigator.platform),this.start=function(e,i){i=i||{};var a,o,n={progress:null,finished:null,error:null,aborted:null};function r(e,t){e&&n[e]&&n[e](t)}return l.ios?r("error","Downloading on IOS is not supported."):(o={on:function(e,t){switch(e){case"progress":n.progress=t;break;case"finished":n.finished=t;break;case"error":n.error=t;break;case"aborted":n.aborted=t}return o},abort:function(){a&&(a.aborted=function(){r("aborted")})}},new Promise(function(o,t){var n=new URL(e);fetch(e).then(function(e){return e.text()}).then(function(e){if(!(e=c(e=d(e.split(/(\r\n|\r|\n)/gi),function(e){return-1<e.indexOf(".ts")}),function(e,t){return 0===e.indexOf("http")||0===e.indexOf("ftp")?e:n.protocol+"//"+n.host+n.pathname+"/./../"+e})).length)return t("Invalid m3u8 playlist"),r("error","Invalid m3u8 playlist");(a=new s(e,function(e){var t;e=new Blob(e,{type:"octet/stream"}),r("progress",{status:"Processing..."}),i.returnBlob?(r("finished",{status:"Successfully downloaded video",data:e}),o(e)):l.ios||(l.ie?(r("progress",{status:"Sending video to Internet Explorer... this may take a while depending on your device's performance."}),window.navigator.msSaveBlob(e,i&&i.filename||"video.mp4")):(r("progress",{status:"Sending video to browser..."}),(t=document.createElementNS("http://www.w3.org/1999/xhtml","a")).href=URL.createObjectURL(e),t.download=i&&i.filename||"video.mp4",t.style.display="none",document.body.appendChild(t),t.click(),r("finished",{status:"Successfully downloaded video",data:e}),o(e)))},0,[])).onprogress=function(e){r("progress",e)}}).catch(function(e){r("error","Something went wrong when downloading m3u8 playlist: "+e)})}),o)}}var nl=0,il=8;function al(e){for(var t=((e,t)=>{e[t>>5]|=128<<t%32,e[14+(t+64>>>9<<4)]=t;for(var o=1732584193,n=-271733879,i=-1732584194,a=271733878,r=0;r<e.length;r+=16){var l=o,s=n,d=i,c=a;o=p(o,n,i,a,e[r+0],7,-680876936),a=p(a,o,n,i,e[r+1],12,-389564586),i=p(i,a,o,n,e[r+2],17,606105819),n=p(n,i,a,o,e[r+3],22,-1044525330),o=p(o,n,i,a,e[r+4],7,-176418897),a=p(a,o,n,i,e[r+5],12,1200080426),i=p(i,a,o,n,e[r+6],17,-1473231341),n=p(n,i,a,o,e[r+7],22,-45705983),o=p(o,n,i,a,e[r+8],7,1770035416),a=p(a,o,n,i,e[r+9],12,-1958414417),i=p(i,a,o,n,e[r+10],17,-42063),n=p(n,i,a,o,e[r+11],22,-1990404162),o=p(o,n,i,a,e[r+12],7,1804603682),a=p(a,o,n,i,e[r+13],12,-40341101),i=p(i,a,o,n,e[r+14],17,-1502002290),n=p(n,i,a,o,e[r+15],22,1236535329),o=u(o,n,i,a,e[r+1],5,-165796510),a=u(a,o,n,i,e[r+6],9,-1069501632),i=u(i,a,o,n,e[r+11],14,643717713),n=u(n,i,a,o,e[r+0],20,-373897302),o=u(o,n,i,a,e[r+5],5,-701558691),a=u(a,o,n,i,e[r+10],9,38016083),i=u(i,a,o,n,e[r+15],14,-660478335),n=u(n,i,a,o,e[r+4],20,-405537848),o=u(o,n,i,a,e[r+9],5,568446438),a=u(a,o,n,i,e[r+14],9,-1019803690),i=u(i,a,o,n,e[r+3],14,-187363961),n=u(n,i,a,o,e[r+8],20,1163531501),o=u(o,n,i,a,e[r+13],5,-1444681467),a=u(a,o,n,i,e[r+2],9,-51403784),i=u(i,a,o,n,e[r+7],14,1735328473),n=u(n,i,a,o,e[r+12],20,-1926607734),o=g(o,n,i,a,e[r+5],4,-378558),a=g(a,o,n,i,e[r+8],11,-2022574463),i=g(i,a,o,n,e[r+11],16,1839030562),n=g(n,i,a,o,e[r+14],23,-35309556),o=g(o,n,i,a,e[r+1],4,-1530992060),a=g(a,o,n,i,e[r+4],11,1272893353),i=g(i,a,o,n,e[r+7],16,-155497632),n=g(n,i,a,o,e[r+10],23,-1094730640),o=g(o,n,i,a,e[r+13],4,681279174),a=g(a,o,n,i,e[r+0],11,-358537222),i=g(i,a,o,n,e[r+3],16,-722521979),n=g(n,i,a,o,e[r+6],23,76029189),o=g(o,n,i,a,e[r+9],4,-640364487),a=g(a,o,n,i,e[r+12],11,-421815835),i=g(i,a,o,n,e[r+15],16,530742520),n=g(n,i,a,o,e[r+2],23,-995338651),o=h(o,n,i,a,e[r+0],6,-198630844),a=h(a,o,n,i,e[r+7],10,1126891415),i=h(i,a,o,n,e[r+14],15,-1416354905),n=h(n,i,a,o,e[r+5],21,-57434055),o=h(o,n,i,a,e[r+12],6,1700485571),a=h(a,o,n,i,e[r+3],10,-1894986606),i=h(i,a,o,n,e[r+10],15,-1051523),n=h(n,i,a,o,e[r+1],21,-2054922799),o=h(o,n,i,a,e[r+8],6,1873313359),a=h(a,o,n,i,e[r+15],10,-30611744),i=h(i,a,o,n,e[r+6],15,-1560198380),n=h(n,i,a,o,e[r+13],21,1309151649),o=h(o,n,i,a,e[r+4],6,-145523070),a=h(a,o,n,i,e[r+11],10,-1120210379),i=h(i,a,o,n,e[r+2],15,718787259),n=h(n,i,a,o,e[r+9],21,-343485551),o=ll(o,l),n=ll(n,s),i=ll(i,d),a=ll(a,c)}return Array(o,n,i,a)})((e=>{for(var t=Array(),o=(1<<il)-1,n=0;n<e.length*il;n+=il)t[n>>5]|=(e.charCodeAt(n/il)&o)<<n%32;return t})(e),e.length*il),o=nl?"0123456789ABCDEF":"0123456789abcdef",n="",i=0;i<4*t.length;i++)n+=o.charAt(t[i>>2]>>i%4*8+4&15)+o.charAt(t[i>>2]>>i%4*8&15);return n}function rl(e,t,o,n,i,a){return ll((t=ll(ll(t,e),ll(n,a)))<<i|t>>>32-i,o)}function p(e,t,o,n,i,a,r){return rl(t&o|~t&n,e,t,i,a,r)}function u(e,t,o,n,i,a,r){return rl(t&n|o&~n,e,t,i,a,r)}function g(e,t,o,n,i,a,r){return rl(t^o^n,e,t,i,a,r)}function h(e,t,o,n,i,a,r){return rl(o^(t|~n),e,t,i,a,r)}function ll(e,t){var o=(65535&e)+(65535&t);return(e=(e>>16)+(t>>16)+(o>>16))<<16|65535&o}l="undefined"!=typeof self?self:this,t=function(){return o=[function(e,t,o){Object.defineProperty(t,"__esModule",{value:!0}),t.noticeJsModalClassName="noticejs-modal",t.closeAnimation="noticejs-fadeOut",t.Defaults={title:"",text:"",type:"success",position:"topRight",timeout:30,progressBar:!0,closeWith:["button"],animation:null,modal:!1,scroll:{maxHeight:300,showOnHover:!0},rtl:!1,callbacks:{beforeShow:[],onShow:[],afterShow:[],onClose:[],afterClose:[],onClick:[],onHover:[],onTemplate:[]}}},function(e,t,o){Object.defineProperty(t,"__esModule",{value:!0}),t.appendNoticeJs=t.addListener=t.CloseItem=t.AddModal=void 0,t.getCallback=r;var n=(e=>{if(e&&e.__esModule)return e;var t={};if(null!=e)for(var o in e)Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o]);return t.default=e,t})(o=o(0));var a=n.Defaults;function r(t,e){t.callbacks.hasOwnProperty(e)&&t.callbacks[e].forEach(function(e){"function"==typeof e&&e.apply(t)})}var l=t.AddModal=function(){var e;document.getElementsByClassName(n.noticeJsModalClassName).length<=0&&((e=document.createElement("div")).classList.add(n.noticeJsModalClassName),e.classList.add("noticejs-modal-open"),document.body.appendChild(e),setTimeout(function(){e.className=n.noticeJsModalClassName},200))},i=t.CloseItem=function(e){r(a,"onClose"),null!==a.animation&&null!==a.animation.close&&(e.className+=" "+a.animation.close),setTimeout(function(){e.remove()},200),!0===a.modal&&1<=document.querySelectorAll("[noticejs-modal='true']").length&&(document.querySelector(".noticejs-modal").className+=" noticejs-modal-close",setTimeout(function(){document.querySelector(".noticejs-modal").remove()},500));var t="."+e.closest(".noticejs").className.replace("noticejs","").trim();setTimeout(function(){var e;document.querySelectorAll(t+" .item").length<=0&&null!=(e=document.querySelector(t))&&e.remove()},500)},s=t.addListener=function(t){a.closeWith.includes("button")&&t.querySelector(".close").addEventListener("click",function(){i(t)}),a.closeWith.includes("click")?(t.style.cursor="pointer",t.addEventListener("click",function(e){"close"!==e.target.className&&(r(a,"onClick"),i(t))})):t.addEventListener("click",function(e){"close"!==e.target.className&&r(a,"onClick")}),t.addEventListener("mouseover",function(){r(a,"onHover")})};t.appendNoticeJs=function(e,t,o){var n=".noticejs-"+a.position,i=document.createElement("div");return i.classList.add("item"),i.classList.add(a.type),!0===a.rtl&&i.classList.add("noticejs-rtl"),e&&""!==e&&i.appendChild(e),i.appendChild(t),o&&""!==o&&i.appendChild(o),["top","bottom"].includes(a.position)&&(document.querySelector(n).innerHTML=""),null!==a.animation&&null!==a.animation.open&&(i.className+=" "+a.animation.open),!0===a.modal&&(i.setAttribute("noticejs-modal","true"),l()),s(i,a.closeWith),r(a,"beforeShow"),r(a,"onShow"),document.querySelector(n).appendChild(i),r(a,"afterShow"),i}},function(e,t,o){Object.defineProperty(t,"__esModule",{value:!0});var n=function(e,t,o){return t&&i(e.prototype,t),o&&i(e,o),e};function i(e,t){for(var o=0;o<t.length;o++){var n=t[o];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}var a=o(3),r=((a=a)&&a.__esModule,d(o(0))),l=o(4),s=d(o(1));function d(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var o in e)Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o]);return t.default=e,t}function c(){var e=0<arguments.length&&void 0!==arguments[0]?arguments[0]:{},t=this,o=c;if(t instanceof o)return this.options=Object.assign(r.Defaults,e),this.component=new l.Components,this.on("beforeShow",this.options.callbacks.beforeShow),this.on("onShow",this.options.callbacks.onShow),this.on("afterShow",this.options.callbacks.afterShow),this.on("onClose",this.options.callbacks.onClose),this.on("afterClose",this.options.callbacks.afterClose),this.on("onClick",this.options.callbacks.onClick),this.on("onHover",this.options.callbacks.onHover),this;throw new TypeError("Cannot call a class as a function")}n(c,[{key:"show",value:function(){var e=this.component.createContainer(),t=(null===document.querySelector(".noticejs-"+this.options.position)&&document.body.appendChild(e),void 0),e=this.component.createHeader(this.options.title,this.options.closeWith),o=this.component.createBody(this.options.text);return!0===this.options.progressBar&&(t=this.component.createProgressBar()),s.appendNoticeJs(e,o,t)}},{key:"on",value:function(e){var t=1<arguments.length&&void 0!==arguments[1]?arguments[1]:function(){};return"function"==typeof t&&this.options.callbacks.hasOwnProperty(e)&&this.options.callbacks[e].push(t),this}}]),t.default=o=c,e.exports=t.default},function(e,t){},function(e,t,o){Object.defineProperty(t,"__esModule",{value:!0}),t.Components=void 0;var n=function(e,t,o){return t&&i(e.prototype,t),o&&i(e,o),e};function i(e,t){for(var o=0;o<t.length;o++){var n=t[o];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}var a=l(o(0)),r=l(o=o(1));function l(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var o in e)Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o]);return t.default=e,t}var s=a.Defaults;function d(){if(!(this instanceof d))throw new TypeError("Cannot call a class as a function")}t.Components=(n(d,[{key:"createContainer",value:function(){var e="noticejs-"+s.position,t=document.createElement("div");return t.classList.add("noticejs"),t.classList.add(e),t}},{key:"createHeader",value:function(){var e,t=void 0;return s.title&&""!==s.title&&((t=document.createElement("div")).setAttribute("class","noticejs-heading"),t.textContent=s.title),s.closeWith.includes("button")&&((e=document.createElement("div")).setAttribute("class","close"),e.innerHTML="&times;",t?t.appendChild(e):t=e),t}},{key:"createBody",value:function(){var e=document.createElement("div"),t=(e.setAttribute("class","noticejs-body"),document.createElement("div"));return t.setAttribute("class","noticejs-content"),t.innerHTML=s.text,e.appendChild(t),null!==s.scroll&&""!==s.scroll.maxHeight&&(e.style.overflowY="auto",e.style.maxHeight=s.scroll.maxHeight+"px",!0===s.scroll.showOnHover)&&(e.style.visibility="hidden"),e}},{key:"createProgressBar",value:function(){var o,n,i=document.createElement("div"),a=(i.setAttribute("class","noticejs-progressbar"),document.createElement("div"));return a.setAttribute("class","noticejs-bar"),i.appendChild(a),!0===s.progressBar&&"boolean"!=typeof s.timeout&&!1!==s.timeout&&(o=100,n=setInterval(function(){var e,t;o<=0?(clearInterval(n),e=i.closest("div.item"),null!==s.animation&&null!==s.animation.close?(e.className=e.className.replace(new RegExp("(?:^|\\s)"+s.animation.open+"(?:\\s|$)")," "),e.className+=" "+s.animation.close,t=parseInt(s.timeout)+500,setTimeout(function(){r.CloseItem(e)},t)):r.CloseItem(e)):(o--,a.style.width=o+"%")},s.timeout)),i}}]),d)}],i={},n.m=o,n.c=i,n.d=function(e,t,o){n.o(e,t)||Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:o})},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="dist/",n(n.s=2);function n(e){var t;return(i[e]||(t=i[e]={i:e,l:!1,exports:{}},o[e].call(t.exports,t,t.exports,n),t.l=!0,t)).exports}var o,i},"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typeof define&&define.amd?define("NoticeJs",[],t):"object"==typeof exports?exports.NoticeJs=t():l.NoticeJs=t();class sl{constructor(e,t){this.domContainer=e,this.domVideo=t,this.camera=null,this.scene=null,this.renderer=null,this.isUserInteracting=!1,this.lon=0,this.lat=0,this.phi=0,this.theta=0,this.distance=50,this.onPointerDownPointerX=0,this.onPointerDownPointerY=0,this.onPointerDownLon=0,this.onPointerDownLat=0,this.onDocumentMouseDown=this.onDocumentMouseDown.bind(this),this.onDocumentMouseMove=this.onDocumentMouseMove.bind(this),this.onDocumentMouseUp=this.onDocumentMouseUp.bind(this),this.onDocumentMouseWheel=this.onDocumentMouseWheel.bind(this),this.onWindowResize=this.onWindowResize.bind(this),this.init()}init(){var e=this.domContainer,t=(this.camera=new THREE.PerspectiveCamera(75,this.domVideo.videoWidth/this.domVideo.videoHeight,1,1100),this.camera.target=new THREE.Vector3(0,0,0),this.scene=new THREE.Scene,new THREE.SphereBufferGeometry(500,60,40)),o=(t.scale(-1,1,1),new THREE.VideoTexture(this.domVideo));o.minFilter=THREE.LinearFilter,o=new THREE.MeshBasicMaterial({map:o}),t=new THREE.Mesh(t,o),this.scene.add(t),this.renderer=new THREE.WebGLRenderer,this.renderer.setPixelRatio(window.devicePixelRatio),this.renderer.setSize(this.domVideo.clientWidth,this.domVideo.clientHeight),e.appendChild(this.renderer.domElement),e.addEventListener("mousedown",this.onDocumentMouseDown,!1),e.addEventListener("mousemove",this.onDocumentMouseMove,!1),e.addEventListener("mouseup",this.onDocumentMouseUp,!1),e.addEventListener("wheel",this.onDocumentMouseWheel,!1),window.addEventListener("resize",this.onWindowResize,!1)}onWindowResize(){this.camera.aspect=this.domVideo.videoWidth/this.domVideo.videoHeight,this.camera.updateProjectionMatrix(),this.renderer.setSize(this.domVideo.clientWidth,this.domVideo.clientHeight)}onDocumentMouseDown(e){this.isUserInteracting=!0,this.onPointerDownPointerX=e.clientX,this.onPointerDownPointerY=e.clientY,this.onPointerDownLon=this.lon,this.onPointerDownLat=this.lat}onDocumentMouseMove(e){!0===this.isUserInteracting&&(this.lon=.1*(this.onPointerDownPointerX-e.clientX)+this.onPointerDownLon,this.lat=.1*(e.clientY-this.onPointerDownPointerY)+this.onPointerDownLat)}onDocumentMouseUp(){this.isUserInteracting=!1}onDocumentMouseWheel(e){this.distance+=.05*e.deltaY,this.distance=THREE.Math.clamp(this.distance,1,50)}update(){this.lat=Math.max(-85,Math.min(85,this.lat)),this.phi=THREE.Math.degToRad(90-this.lat),this.theta=THREE.Math.degToRad(this.lon),this.camera.position.x=this.distance*Math.sin(this.phi)*Math.cos(this.theta),this.camera.position.y=this.distance*Math.cos(this.phi),this.camera.position.z=this.distance*Math.sin(this.phi)*Math.sin(this.theta),this.camera.lookAt(this.camera.target),this.renderer.render(this.scene,this.camera)}}var dl={containerClass:"postbird-box-container active",box:null,textTemplate:{title:"提示信息",content:"提示内容",okBtn:"好的",cancelBtn:"取消",contentColor:"#000000",okBtnColor:"#0e90d2",promptTitle:"请输入内容",promptOkBtn:"确认"},getAlertTemplate:function(){return'<div class="postbird-box-dialog"><div class="postbird-box-content"><div class="postbird-box-header"><span class="postbird-box-close-btn">×</span><span class="postbird-box-title"><span >'+this.textTemplate.title+'</span></span></div><div class="postbird-box-text"><span style="color:'+this.textTemplate.contentColor+';">'+this.textTemplate.content+'</span></div><div class="postbird-box-footer"><button class="btn-footer btn-block-footer btn-footer-ok" style="color:'+this.textTemplate.okBtnColor+';">'+this.textTemplate.okBtn+"</button></div></div></div>"},getConfirmTemplate:function(){return'<div class="postbird-box-container"><div class="postbird-box-dialog"><div class="postbird-box-content"><div class="postbird-box-header"><span class="postbird-box-close-btn">×</span><span class="postbird-box-title"><span >'+this.textTemplate.title+'</span></span></div><div class="postbird-box-text"><span style="color:'+this.textTemplate.contentColor+';">'+this.textTemplate.content+'?</span></div><div class="postbird-box-footer"><button class="btn-footer btn-left-footer btn-footer-cancel" style="color:'+this.textTemplate.cancelBtnColor+';">'+this.textTemplate.cancelBtn+'</button><button class="btn-footer btn-right-footer btn-footer-ok"  style="color:'+this.textTemplate.okBtnColor+';">'+this.textTemplate.okBtn+"</button></div></div></div></div>"},getPromptTemplate:function(){return'<div class="postbird-box-container"><div class="postbird-box-dialog"><div class="postbird-box-content"><div class="postbird-box-header"><span class="postbird-box-close-btn">×</span><span class="postbird-box-title"><span >'+this.textTemplate.title+'</span></span></div><div class="postbird-box-text"><input type="text" class="postbird-prompt-input" autofocus="true" ></div><div class="postbird-box-footer"><button class="btn-footer btn-left-footer btn-footer-cancel" style="color:'+this.textTemplate.cancelBtnColor+';">'+this.textTemplate.cancelBtn+'</button><button class="btn-footer btn-right-footer btn-footer-ok"  style="color:'+this.textTemplate.okBtnColor+';">'+this.textTemplate.okBtn+"</button></div></div></div></div>"},alert:function(e){this.textTemplate.title=e.title||this.textTemplate.title,this.textTemplate.content=e.content||this.textTemplate.content,this.textTemplate.okBtn=e.okBtn||this.textTemplate.okBtn,this.textTemplate.okBtnColor=e.okBtnColor||this.textTemplate.okBtnColor,this.textTemplate.contentColor=e.contentColor||this.textTemplate.contentColor;var t=document.createElement("div"),o=this;t.className=this.containerClass,t.innerHTML=this.getAlertTemplate(),this.box=t,document.body.appendChild(this.box),(t=document.getElementsByClassName("btn-footer-ok"))[t.length-1].focus(),t[t.length-1].onclick=function(){e.onConfirm&&e.onConfirm(),o.removeBox()}},confirm:function(e){this.textTemplate.title=e.title||this.textTemplate.promptTitle,this.textTemplate.promptPlaceholder=e.promptPlaceholder||this.textTemplate.promptPlaceholder,this.textTemplate.okBtn=e.okBtn||this.textTemplate.promptOkBtn,this.textTemplate.okBtnColor=e.okBtnColor||this.textTemplate.okBtnColor,this.textTemplate.cancelBtn=e.cancelBtn||this.textTemplate.cancelBtn,this.textTemplate.cancelBtnColor=e.cancelBtnColor||this.textTemplate.cancelBtnColor,this.textTemplate.content=e.content||this.textTemplate.content;var t=document.createElement("div"),o=this;(this.box=t).className=this.containerClass,t.innerHTML=this.getConfirmTemplate(),document.body.appendChild(t),(t=document.getElementsByClassName("btn-footer-ok"))[t.length-1].focus(),t[t.length-1].onclick=function(){e.onConfirm&&e.onConfirm(),o.removeBox()},(t=document.getElementsByClassName("btn-footer-cancel"))[t.length-1].onclick=function(){e.onCancel&&e.onCancel(),o.removeBox()}},prompt:function(e){this.textTemplate.title=e.title||this.textTemplate.title,this.textTemplate.content=e.content||this.textTemplate.content,this.textTemplate.contentColor=e.contentColor||this.textTemplate.contentColor,this.textTemplate.okBtn=e.okBtn||this.textTemplate.okBtn,this.textTemplate.okBtnColor=e.okBtnColor||this.textTemplate.okBtnColor,this.textTemplate.cancelBtn=e.cancelBtn||this.textTemplate.cancelBtn,this.textTemplate.cancelBtnColor=e.cancelBtnColor||this.textTemplate.cancelBtnColor;var t=document.createElement("div"),o=this;t.className=this.containerClass,t.innerHTML=this.getPromptTemplate(),this.box=t,document.body.appendChild(t);var n=(n=document.getElementsByClassName("postbird-prompt-input"))[n.length-1];null!=e.defaultValue&&(n.value=e.defaultValue),n.focus(),t=document.getElementsByClassName("btn-footer-ok"),n.value,t[t.length-1].focus(),t[t.length-1].onclick=function(){e.onConfirm&&e.onConfirm(n.value),o.removeBox()},(t=document.getElementsByClassName("btn-footer-cancel"))[t.length-1].onclick=function(){e.onCancel&&e.onCancel(n.value),o.removeBox()}},colse:function(){this.removeBox()},removeBox:function(){var e=document.getElementsByClassName(this.containerClass);document.body.removeChild(e[e.length-1])}};function cl(e,t,o,a){let n="80";switch(t){case"1":n="80";break;case"2":n="150";break;case"3":n="250";break;case"4":n="400";break;case"5":n="20000";break;default:n="80"}GM_xmlhttpRequest({method:"GET",url:`https://api.live.bilibili.com/xlive/web-room/v2/index/getRoomPlayInfo?room_id=${e}&platform=web&qn=${n}&protocol=0,1&format=0,1,2&codec=0,1`,responseType:"json",onload:function(e){var t=e.response;let o="";for(let e=0;e<t.data.playurl_info.playurl.stream.length;e++){var n,i=t.data.playurl_info.playurl.stream[e];String(i.protocol_name).includes("stream")&&0<i.format.length&&(n=i.format[0].codec[0].url_info[0],i=i.format[0].codec[0].base_url,o=""+n.host+i+n.extra)}e=t.data.durl;e&&(o=0<e.length?e[0].url:""),a(o)}})}function pl(i,a,e,r,l){let s=Q("dy_did")||"10000000000000000000000000001501";GM_xmlhttpRequest({method:"GET",url:"https://www.douyu.com/wgapi/livenc/liveweb/websec/getEncryption?did="+s,responseType:"json",onload:function(e){if(0!==e.response.error)return l("None");var e=e.response.data,t=Math.round(Date.now()/1e3),o=((e,t,o,n,i,a)=>{let r=1===a?"":""+e+t,l=n;for(let e=0;e<i;e++)l=al(l+o);return al(l+o+r)})(i,(s,t),e.key,e.rand_str,e.enc_time,e.is_special),n="1428"==r?"-1":r,e=`enc_data=${e.enc_data}&tt=${t}&did=${s}&auth=${o}&cdn=&rate=${n}&hevc=0&fa=0&ive=0`;GM_xmlhttpRequest({method:"POST",url:"https://www.douyu.com/lapi/live/getH5PlayV1/"+i,data:e,responseType:"json",headers:{"Content-Type":"application/x-www-form-urlencoded"},onload:function(e){var e=e.response;0===e.error?(e=e.data.rtmp_url+"/"+e.data.rtmp_live,l(a?e:e+"&only-audio=1")):l("None")}})}})}function ml(e,t,n){let o="500";switch(t){case"1":o="500";break;case"2":o="2500";break;case"3":o="4500";break;case"4":o="0";break;default:o="500"}GM_xmlhttpRequest({method:"GET",url:"https://mp.huya.com/cache.php?m=Live&do=profileRoom&roomid="+e,responseType:"json",onload:e=>{let t="",o="";e=e.response.data.stream.flv.multiLine;null!=(o=e.length&&0<e.length?e[0].url.replace("http","https"):o)&&""!=o||(t="房间暂未开播"),n(o,t)}})}let ul=[],gl=new Map;function hl(e){ul.push(e)}function fl(e){if(e)return e.toString().replace(/@S/g,"/").replace(/@A/g,"@")}function yl(e){if(e)return e.includes("//")?e.split("//").filter(e=>""!==e).map(e=>yl(e)):e.includes("@=")?e.split("/").filter(e=>""!==e).reduce((e,t)=>{var[t,o]=t.split("@=");return e[t]=yl(fl(o)),e},{}):e.includes("@A=")?yl(fl(e)):e.toString()}let bl=[];function vl(e){if("SCRIPT"===e.tagName&&!e.src&&e.textContent){var o=bl.filter(e=>e.inline);if(0!==o.length){let t=e.textContent;for(let e=0;e<o.length;e++)t=o[e].callback(t);t!==e.textContent&&(e.textContent=t)}}return e}function xl(e,t,o){var n,i,a=e.src,r=[];for(let e=0;e<bl.length;e++){var l=bl[e];!l.inline&&a.includes(l.url)&&r.push(l)}return 0!==r.length&&(n=r,i=o,GM_xmlhttpRequest({method:"GET",url:a,onload:function(e){let t=e.responseText;for(let e=0;e<n.length;e++)t=n[e].callback(t);e=document.createElement("script");e.type="text/javascript",e.textContent=t,i.appendChild(e)},onerror:function(e){console.error("Error loading script via GM_xmlhttpRequest:",e)}}),1)}function wl(e){bl.push(e)}function _l(e,t){var o;null==document.getElementById(e)&&((o=document.createElement("style")).id=e,o.innerHTML=t,document.body.append(o))}function V(e){null!==document.getElementById(e)&&document.getElementById(e).remove()}function kl(e){var t=(t=>{var o,n,i=new Array;o=t.length;for(let e=0;e<o;e++)65536<=(n=String(t).charCodeAt(e))&&n<=1114111?(i.push(n>>18&7|240),i.push(n>>12&63|128),i.push(n>>6&63|128),i.push(63&n|128)):2048<=n&&n<=65535?(i.push(n>>12&15|224),i.push(n>>6&63|128),i.push(63&n|128)):128<=n&&n<=2047?(i.push(n>>6&31|192),i.push(63&n|128)):i.push(255&n);return i})(e),e=new Uint8Array(t.length+4+4+2+1+1+1),o=new Uint8Array(t.length);for(let e=0;e<o.length;e++)o[e]=t[e];var n=new Uint32Array([t.length+4+2+1+1+1]),i=new Uint32Array([689]);return e.set(new Uint8Array(n.buffer),0),e.set(new Uint8Array(n.buffer),4),e.set(new Uint8Array(i.buffer),8),e.set(o,12),e}class El{constructor(e,t){"WebSocket"in window&&(this.timer=0,this.rid=e,this.msgHandler=t,this.reconnectCount=0,this.maxReconnect=10,this.closed=!1,this.connect())}connect(){this.ws=new WebSocket("wss://danmuproxy.douyu.com:850"+String(Z(2,5))),this.ws.onopen=()=>{this.reconnectCount=0,this.ws.send(kl("type@=loginreq/roomid@="+this.rid)),this.ws.send(kl("type@=joingroup/rid@="+this.rid+"/gid@=-9999/")),this.timer=setInterval(()=>{this.ws.send(kl("type@=mrkl/"))},4e4)},this.ws.onerror=()=>{if(!this.closed&&this.ws)try{this.ws.close()}catch(e){}},this.ws.onmessage=t=>{if(!this.closed){let e=new FileReader;e.onload=()=>{if(!this.closed){var t=String(e.result).split("\0");e=null;for(let e=0;e<t.length;e++)12<t[e].length&&this.msgHandler(t[e])}},e.readAsText(t.data)}},this.ws.onclose=()=>{clearInterval(this.timer),this.timer=0,this.ws=null,this.closed||this.reconnect()}}reconnect(){var e;this.closed||this.reconnectCount>=this.maxReconnect||(this.reconnectCount++,e=Math.min(3e3*Math.pow(1.5,this.reconnectCount-1),6e4),setTimeout(()=>{this.closed||this.connect()},e))}close(){if(!this.closed&&(this.closed=!0,clearInterval(this.timer),this.timer=0,this.ws)){var e=this.ws;this.ws=null,e.onclose=null,e.onerror=null,e.onmessage=null;try{e.readyState!==WebSocket.OPEN&&e.readyState!==WebSocket.CONNECTING||e.close()}catch(e){}}}}function Bl(e){if(-1!==String(e).indexOf("yuba.douyu.com"))if(-1!==String(e).indexOf("?exRestore"))jn();else if(-1!==String(e).indexOf("?exClean")){let e=v(window.location.href,"domain=","&");re(()=>{window.parent.postMessage("yubaCleanOver",decodeURIComponent(e))})}else document.domain="douyu.com",Pn();else if(-1!==String(e).indexOf("passport.douyu.com")&&-1!==String(e).indexOf("exid=chun")){let e=v(window.location.href,"cmd=","&"),t=v(window.location.href,"uid=","&"),o=v(window.location.href,"domain=","&");if("clean"!==e){var i=t;let e=JSON.parse(GM_getValue("Ex_accountListPassport")||"{}"),o=[],n=[];GM_cookie("list",{path:"/"},function(t){if(null!=t){for(let e=0;e<t.length;e++)("LTP0"==t[e].name?o:n).push(t[e]);""==i&&(i="null"),e.global=null,e.global=n,e[i]=o,e.update_time=String((new Date).getTime()),GM_setValue("Ex_accountListPassport",JSON.stringify(e))}})}switch(e){case"clean":re(()=>{window.parent.postMessage("cleanOver",decodeURIComponent(o))});break;case"switch":((e,o)=>{let n=JSON.parse(GM_getValue("Ex_accountListPassport"))[e],i=0;GM_cookie("list",{path:"/"},function(t){for(let e=0;e<t.length;e++)GM_cookie("delete",{name:t[e].name},function(e){if(++i>=t.length){let t=0;for(let e=0;e<n.length;e++)GM_cookie("set",{name:n[e].name,value:n[e].value,domain:n[e].domain,path:n[e].path,secure:n[e].secure,httpOnly:n[e].httpOnly,sameSite:n[e].sameSite,expirationDate:n[e].expirationDate,hostOnly:n[e].hostOnly},function(e){++t>=n.length&&o()})}})})})(t,()=>{window.parent.postMessage("switchOver",decodeURIComponent(o))});break;case"delete":((e,t)=>{var o=JSON.parse(GM_getValue("Ex_accountListPassport")||"{}");delete o[e],GM_setValue("Ex_accountListPassport",JSON.stringify(o)),t()})(t,()=>{window.parent.postMessage("deleteOver",decodeURIComponent(o))})}return}else if(-1!==String(e).indexOf("msg.douyu.com"))if(-1!==e.indexOf("?exClean")){let e=v(window.location.href,"domain=","&");re(()=>{window.parent.postMessage("msgCleanOver",decodeURIComponent(e))})}else"chun"==(e=>{var e=new RegExp("(^|&)"+e+"=([^&]*)(&|$)","i");return!(window.location.hash.indexOf("?")<0)&&null!=(e=window.location.hash.split("?")[1].match(e))?decodeURIComponent(e[2]):null})("exid")&&pi();else if(-1!==String(e).indexOf("v.douyu.com")){if(-1!==String(e).indexOf("?exClean")){let e=v(window.location.href,"domain=","&");re(()=>{window.parent.postMessage("videoCleanOver",decodeURIComponent(e))})}else if(-1!==String(e).indexOf("show/")&&unsafeWindow.$DATA&&"ROOM"in unsafeWindow.$DATA){f();{let n=setInterval(()=>{var e,t,o=document.getElementsByTagName("demand-video")[0];o&&o.shadowRoot&&(e=o.shadowRoot.getElementById("__video"),o=o.shadowRoot.getElementById("demandcontroller-bar").shadowRoot.querySelector("demand-video-controller-progress").shadowRoot.querySelector("demand-video-controller-preview"),t=document.getElementsByTagName("demand-video-toolbar")[0].shadowRoot.querySelector("share-hover"),null!=e)&&o&&t&&(clearInterval(n),Di(),(Ti=new MutationObserver(function(e){Di()})).observe(e,{attributes:!0,childList:!0,subtree:!1}),(Mi=new MutationObserver(function(t){for(let e=0;e<t.length;e++)if("hashid"===t[e].attributeName){Di();break}})).observe(t,{attributes:!0,childList:!1,subtree:!1}),(Ni=new MutationObserver(function(t){for(let e=0;e<t.length;e++){var o=t[e];if("showtime"==o.attributeName){var n=Number(ji());Pi(String(_("yyyy-MM-dd hh:mm:ss",new Date(Number(Ci+1e3*n))))+"<br/>"+W(n));break}if("isshow"==o.attributeName){clearTimeout(Li);let e=Number(ji());Li=setTimeout(()=>{Pi(String(_("yyyy-MM-dd hh:mm:ss",new Date(Number(Ci+1e3*e))))+"<br/>"+W(e))},0);break}}})).observe(o,{attributes:!0,childList:!0,subtree:!1}))},1e3)}Oi(),Xe(),Je()}}else if(-1!==String(e).indexOf("cz.douyu.com")){if(-1!==String(e).indexOf("?exClean")){let e=v(window.location.href,"domain=","&");re(()=>{window.parent.postMessage("czCleanOver",decodeURIComponent(e))})}}else if(-1!==String(e).indexOf("getFansBadgeList")){var t=(new Date).getTime(),o=document.querySelectorAll(".fans-badge-list tr");if(!(o.length<=1))for(let e=1;e<o.length;e++){var n=o[e],a=1e3*Number(n.getAttribute("data-fans-gbdgts")),r=_("yyyy-MM-dd hh:mm:ss",new Date(a)),a=Math.floor((t-a)/864e5),l=300<=a?"font-weight:600;color:red;":"";n.getElementsByTagName("td")[1].innerHTML+=`
        已获取 <span style="${l}">${a}</span> 天<br/>
        `+r}return}else if(-1!==String(e).indexOf("exid=chun")){Ln();let t=setInterval(()=>{var e;void 0!==document.querySelector("div.wfs-2a8e83")&&(document.querySelector("div.wfs-2a8e83").click(),document.querySelector("label.layout-Player-asidetoggleButton").click(),e=document.querySelectorAll(".tip-e3420a > ul > li").length,document.querySelectorAll(".tip-e3420a > ul > li")[e-1].click(),clearInterval(t))},1e3);return}else if(-1===String(e).indexOf("template/")&&-1===String(e).indexOf("h5/")){document.domain="douyu.com",s();let n=setInterval(()=>{var e=document.getElementsByClassName("BackpackButton")[0],t=document.getElementsByClassName("Barrage-main")[0],o=document.querySelector("#js-backpack-enter");t&&(e||o)&&(setTimeout(()=>{f(),d(),c()},1500),clearInterval(n))},1e3)}}(async()=>{Bl(window.location.href)})();